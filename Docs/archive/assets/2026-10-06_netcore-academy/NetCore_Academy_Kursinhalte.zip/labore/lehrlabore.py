#!/usr/bin/env python3
"""NetCore Academy: isolierte Lehrlabore ohne Netz- oder Hardwarezugriff.

Aufruf: python3 lehrlabore.py all
Einzelne Labore: bits, sync, mac, sds, dqpsk, floor, rf, coding.
SYNC und die Headerpraefixe beziehen sich auf EN 300 392-2 V3.8.1.
MAC und SDS sind begrenzte Praefixparser; keine vollstaendigen RF-Decoder.
"""
import argparse
import cmath
import json
import math
from dataclasses import dataclass


class DecodeError(ValueError):
    pass


class Bits:
    def __init__(self, value):
        if not isinstance(value, str) or any(c not in '01' for c in value):
            raise DecodeError('Eingabe muss eine Bitzeichenfolge ohne Trennzeichen sein')
        self.value = value
        self.pos = 0
        self.fields = []

    def take(self, width, name):
        if not isinstance(width, int) or width <= 0:
            raise DecodeError('Feldbreite muss eine positive ganze Zahl sein')
        remaining = len(self.value) - self.pos
        if width > remaining:
            raise DecodeError(f'{name}: Offset {self.pos}, benoetigt {width}, Rest {remaining}')
        start = self.pos
        raw = self.value[start:start + width]
        result = int(raw, 2)
        self.pos += width
        self.fields.append(dict(name=name, start=start, end=self.pos, bits=raw, value=result))
        return result

    def end(self):
        if self.pos != len(self.value):
            raise DecodeError(f'Unerwartete Restbits: {len(self.value)-self.pos}')


def emit(value, width):
    if not isinstance(value, int) or not 0 <= value < (1 << width):
        raise DecodeError(f'Wert {value} passt nicht in {width} Bits')
    return format(value, f'0{width}b')


def pack_msb(value):
    pad = (-len(value)) % 8
    packed = int(value + '0' * pad, 2).to_bytes((len(value) + pad) // 8, 'big')
    return dict(hex=packed.hex().upper(), valid_bits=len(value), right_padding_bits=pad)


SYNC_LAYOUT = [
    ('system_code', 4), ('colour_code', 6), ('timeslot_raw', 2),
    ('frame', 5), ('multiframe', 6), ('sharing_mode', 2),
    ('ts_reserved_frames_raw', 3), ('u_plane_dtx', 1), ('frame18_extension', 1),
    ('reserved', 1), ('mcc', 10), ('mnc', 14),
    ('neighbour_broadcast', 2), ('cell_load_ca', 2), ('late_entry', 1),
]
SYNC_VALUES = dict(system_code=3, colour_code=1, timeslot_raw=0, frame=17,
    multiframe=7, sharing_mode=0, ts_reserved_frames_raw=0, u_plane_dtx=0,
    frame18_extension=0, reserved=0, mcc=901, mnc=1510,
    neighbour_broadcast=1, cell_load_ca=2, late_entry=1)


def sync_bits(values=SYNC_VALUES):
    return ''.join(emit(values[k], n) for k, n in SYNC_LAYOUT)


def read_sync(value):
    if len(value) != 60:
        raise DecodeError(f'SYNC erwartet genau 60 Bits, bekommen: {len(value)}')
    reader = Bits(value)
    result = {k: reader.take(n, k) for k, n in SYNC_LAYOUT}
    reader.end()
    if not 1 <= result['frame'] <= 18:
        raise DecodeError('Frame ist in dieser Ausgabe reserviert')
    if not 1 <= result['multiframe'] <= 60:
        raise DecodeError('Multiframe ist in dieser Ausgabe reserviert')
    if result['reserved'] != 0:
        raise DecodeError('Reserviertes Feld muss in dieser Ausgabe 0 sein')
    result['timeslot'] = result['timeslot_raw'] + 1
    return result, reader.fields


def mac_prefix(address_type=1, address=4010001):
    widths = {1: 24, 2: 10}
    if address_type not in widths:
        raise DecodeError('Lehrencoder unterstuetzt nur SSI oder Event Label')
    # Laengenrohwert 7 dient nur der Praefixanalyse. Keine komplette 7-Oktett-PDU.
    return ''.join([emit(0, 2), '0', '0', emit(0, 2), '0', emit(7, 6),
        emit(address_type, 3), emit(address, widths[address_type]), '0', '0', '0'])


def read_mac_prefix(value, modulation='pi4dqpsk'):
    if modulation != 'pi4dqpsk':
        raise DecodeError('Dieser Lehrparser unterstuetzt ausschliesslich pi/4-DQPSK')
    r = Bits(value)
    out = {k: r.take(n, k) for k,n in [
        ('pdu_type',2),('fill',1),('grant_position',1),('encryption_mode',2),
        ('random_access',1),('length_raw',6),('address_type',3)]}
    if out['pdu_type'] != 0:
        raise DecodeError('Kein MAC-RESOURCE-Typ')
    if out['encryption_mode'] != 0:
        raise DecodeError('Verschluesselter Lehrzweig wird nicht verarbeitet')
    if out['address_type'] == 1:
        out['ssi'] = r.take(24, 'ssi')
    elif out['address_type'] == 2:
        out['event_label'] = r.take(10, 'event_label')
    else:
        raise DecodeError('Nicht unterstuetzter Adresszweig')
    # Immediate Napping Permission ist fuer pi/4-DQPSK NICHT vorhanden.
    for name in ['power_control', 'slot_grant', 'channel_allocation']:
        out[name] = r.take(1, name)
        if out[name]:
            raise DecodeError(f'Optionaler Zweig {name} wird im Lehrparser nicht verarbeitet')
    r.end()
    out['prefix_bits'] = r.pos
    return out, r.fields


def sds_prefix():
    # D-SDS-DATA ab CMCE-PDU-Typ, CPTI=1, SDTI=0. Ende vor optionalen Schlussfeldern.
    return emit(15, 5) + emit(1, 2) + emit(4010001, 24) + emit(0, 2) + emit(0x1234, 16)


def read_sds_prefix(value, direction='downlink'):
    if direction != 'downlink':
        raise DecodeError('Dieser Lehrparser erwartet den Downlinkkontext')
    r = Bits(value)
    out = dict(pdu_type=r.take(5,'pdu_type'), calling_party_type=r.take(2,'calling_party_type'))
    if out['pdu_type'] != 15 or out['calling_party_type'] != 1:
        raise DecodeError('Nicht unterstuetzter D-SDS-DATA-Lehrzweig')
    out['calling_ssi'] = r.take(24,'calling_ssi')
    out['sdti'] = r.take(2,'sdti')
    if out['sdti'] != 0:
        raise DecodeError('Lehrparser erwartet ausschliesslich SDTI=0')
    out['user_data'] = r.take(16,'user_data')
    r.end()
    return out, r.fields


PHASES = {'00': math.pi/4, '01': 3*math.pi/4, '10': -math.pi/4, '11': -3*math.pi/4}


def differential_symbols(pairs):
    symbols = [1+0j]
    for pair in pairs:
        symbols.append(symbols[-1] * cmath.exp(1j * PHASES[pair]))
    return symbols


def differential_decisions(symbols):
    answer = []
    for previous,current in zip(symbols,symbols[1:]):
        angle = cmath.phase(current * previous.conjugate())
        distance = lambda target: abs(cmath.phase(cmath.exp(1j*(angle-target))))
        answer.append(min(PHASES, key=lambda bits: distance(PHASES[bits])))
    return answer


@dataclass
class FloorModel:
    """Serialisiertes Lehrmodell; kein konkurrierender produktiver Rufhandler."""
    owner: str | None = None
    generation: int = 0
    uplink_watch: bool = False

    def restore_grant(self, who, group=False):
        if self.owner not in (None, who):
            return False
        self.owner = who
        self.generation += 1
        self.uplink_watch = group
        return True

    def timeout(self, generation):
        if generation != self.generation or not self.uplink_watch:
            return False
        self.owner = None
        self.uplink_watch = False
        return True


def crc_teaching(data):
    """CRC-Lehrvektor: width=16 poly=0x1021 init=0xffff refin/refout=False xorout=0.
    Eigenstaendiges Lehrverfahren; keine pauschale TETRA-CRC-Definition.
    """
    value = 0xffff
    for byte in data:
        value ^= byte << 8
        for _ in range(8):
            value = ((value << 1) ^ 0x1021) & 0xffff if value & 0x8000 else (value << 1) & 0xffff
    return value


def expect_error(fn):
    try:
        fn()
    except DecodeError as exc:
        return str(exc)
    raise AssertionError('Der erwartete Fehler blieb aus')


def lab_bits():
    r=Bits('101101')
    assert r.take(3,'first') == 5 and r.take(3,'second') == 5
    error=expect_error(lambda: r.take(1,'third'))
    assert r.pos == 6
    assert int('101100',2) == 44
    expect_error(lambda: emit(64,6))
    expect_error(lambda: Bits('101x'))
    return dict(fields=r.fields, error=error, position_after_error=r.pos)


def lab_sync():
    value=sync_bits()
    assert value=='001100000100100010001110000000011100001010001011110011001101'
    out,fields=read_sync(value)
    assert len(value)==60 and out['mcc']==901 and out['mnc']==1510 and out['timeslot']==1
    # Unabhaengige Offseterwartungen aus Tabellen 21.76 und 18.17.
    assert next(f for f in fields if f['name']=='mcc')['start']==31
    assert next(f for f in fields if f['name']=='mnc')['start']==41
    assert int(value[31:41],2)==901 and int(value[41:55],2)==1510
    errors=[expect_error(lambda: read_sync(value[:-1]))]
    invalid=dict(SYNC_VALUES,frame=0)
    errors.append(expect_error(lambda: read_sync(sync_bits(invalid))))
    invalid=dict(SYNC_VALUES,reserved=1)
    errors.append(expect_error(lambda: read_sync(sync_bits(invalid))))
    return dict(bits=value, packed_msb=pack_msb(value), decoded=out, fields=fields, negative_cases=errors)


def lab_mac():
    value=mac_prefix()
    out,fields=read_mac_prefix(value)
    assert len(value)==43 and out['ssi']==4010001
    assert next(f for f in fields if f['name']=='power_control')['start']==40
    other=mac_prefix(2,17)
    other_out,other_fields=read_mac_prefix(other)
    assert len(other)==29 and other_out['event_label']==17
    assert next(f for f in other_fields if f['name']=='power_control')['start']==26
    errors=[expect_error(lambda: read_mac_prefix(value[:-1])),
        expect_error(lambda: read_mac_prefix(value,'qam')),
        expect_error(lambda: read_mac_prefix(value[:-3]+'100'))]
    return dict(scope='Headerpraefix ohne TM-SDU und Laengenvalidierung der vollen PDU',
        ssi=dict(bits=value, decoded=out, fields=fields),
        event_label=dict(bits=other, decoded=other_out, fields=other_fields),negative_cases=errors)


def lab_sds():
    value=sds_prefix()
    out,fields=read_sds_prefix(value)
    assert len(value)==49 and out['user_data']==0x1234 and out['calling_ssi']==4010001
    payload=next(f for f in fields if f['name']=='user_data')
    assert (payload['start'],payload['end'])==(33,49)
    errors=[expect_error(lambda: read_sds_prefix(value[:-1])),
        expect_error(lambda: read_sds_prefix(value,'uplink'))]
    return dict(scope='D-SDS-DATA-Kernpraefix; keine optionalen Schlussfelder und kein aeusserer Protokolldiskriminator',
        bits=value, packed_msb=pack_msb(value),decoded=out,fields=fields,negative_cases=errors)


def lab_dqpsk():
    pairs=['00','01','10','11']
    symbols=differential_symbols(pairs)
    result=differential_decisions(symbols)
    assert result==pairs
    # Ein gemeinsamer fester Phasenoffset darf das Ergebnis nicht aendern.
    rotated=[s*cmath.exp(0.71j) for s in symbols]
    assert differential_decisions(rotated)==pairs
    return dict(scope='Ideale bereits symbolgetaktete Werte; keine komplette IQ-Decoderkette',
        input=pairs, output=result, phases_degrees=[45,135,-45,-135],
        symbols=[dict(real=round(s.real,8),imag=round(s.imag,8)) for s in symbols])


def lab_floor():
    f=FloorModel(owner='A')
    assert not f.restore_grant('B') and f.owner=='A'
    assert f.restore_grant('A') and f.owner=='A'
    g=FloorModel()
    assert g.restore_grant('B',group=True) and g.uplink_watch
    old=g.generation
    assert g.restore_grant('B',group=True)
    assert not g.timeout(old) and g.owner=='B'
    assert g.timeout(g.generation) and g.owner is None
    assert g.restore_grant('C',group=True)
    return dict(individual='B erhaelt bei Floor A keinen Grant',
        group='Uplinkueberwachung aktiv; alter Timer ignoriert; aktueller Timeout gibt frei; C kann uebernehmen',
        final_owner=g.owner, generation=g.generation)


def lab_rf():
    down=30-2+6-105+3-1
    up=20-1+0-105+6-2
    gamma=(2-1)/(2+1)
    reflected=gamma**2
    return dict(downlink_dbm=down,downlink_margin_db=down-(-95),uplink_dbm=up,
        uplink_margin_db=up-(-95),quarter_wave_m=299792458/418000000/4,
        vswr=2,reflected_percent=100*reflected,return_loss_db=-20*math.log10(gamma),
        samples_per_symbol=144000/18000,fft_bin_hz=144000/2048,ber_percent=100*250/100000)


def lab_coding():
    original=[1,0,1,1]
    perm=[2,0,3,1]
    sent=[original[i] for i in perm]
    restored=[None]*4
    for j,i in enumerate(perm): restored[i]=sent[j]
    assert sent==[1,1,1,0] and restored==original
    check=crc_teaching(b'123456789')
    assert check==0x29B1
    return dict(scope='Eigene Interleaving- und CRC-Lehrverfahren; keine TETRA-Kanalkette',
        original=original,permutation=perm,transmitted=sent,restored=restored,
        crc_input='123456789',crc_hex=format(check,'04X'),
        crc_parameters=dict(width=16,poly='1021',init='FFFF',refin=False,refout=False,xorout='0000'))


LABS=dict(bits=lab_bits,sync=lab_sync,mac=lab_mac,sds=lab_sds,dqpsk=lab_dqpsk,
    floor=lab_floor,rf=lab_rf,coding=lab_coding)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lab',choices=['all',*LABS],nargs='?',default='all')
    args=parser.parse_args()
    output={name:fn() for name,fn in LABS.items() if args.lab in ('all',name)}
    print(json.dumps(output,ensure_ascii=False,indent=2))
