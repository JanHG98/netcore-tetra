#!/usr/bin/env python3
"""NetCore-TETRA 2U RF / I/O panel: exact meshes and multipart 3MF.

All geometry in mm. No slicer-specific G-code is generated.
Dependencies: numpy, shapely >=2.1 (GEOS >=3.10), trimesh, matplotlib, cairosvg.
The system font is NOT redistributed; text is exported as closed mesh geometry.
"""
from __future__ import annotations
import argparse, csv, json, math, shutil, zipfile
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPolygon, GeometryCollection, Point, LineString, box
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from shapely import constrained_delaunay_triangles, affinity
import trimesh
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties, findfont

OUT=Path('/mnt/data/NetCore_Tetra_Patchpanel_v1')
WORK=Path('/mnt/data/netcore_panel_work')
W=482.6
H_NOMINAL=88.9
EDGE_CLEARANCE=0.4
H=H_NOMINAL-2*EDGE_CLEARANCE
THICKNESS=3.0
INLAY=0.6
RIB_HEIGHT=6.0
HOLE_D=24.2                  # 24.0 mm etherCON minimum + 0.2 mm diametral FDM allowance
SCREW_D=3.3
COLS=[48.0,94.0,158.0,204.0,274.0,320.0,366.0,430.0]
ROWS=[22.5-EDGE_CLEARANCE,63.5-EDGE_CLEARANCE]
SPLIT=W/2
SEAM=0.2
JOIN_X=[SPLIT-8,SPLIT+8]
JOIN_Y=[14.,44.,74.]
FONT=findfont(FontProperties(family='DejaVu Sans',weight='bold',stretch='condensed'))
TEXTS=[]
PALETTE=[('Platte', '#242931'), ('Schrift','#F2F4F7'), ('Logo_und_Linien','#147FC1')]


def clean(g):
    if not g.is_valid:
        g=shapely.make_valid(g)
    return g

def polys(g):
    if g.is_empty: return []
    if isinstance(g,Polygon): return [orient(g,sign=1.0)]
    ans=[]
    if hasattr(g,'geoms'):
        for x in g.geoms: ans.extend(polys(x))
    return ans

def merged(gs):
    return clean(unary_union([g for g in gs if not g.is_empty]))

def rr(x0,y0,x1,y1,r=1.):
    return box(x0+r,y0+r,x1-r,y1-r).buffer(r,quad_segs=12,join_style=1)

def circle(x,y,d):
    return Point(x,y).buffer(d/2,quad_segs=64)

def line(coords,width=.55):
    return LineString(coords).buffer(width/2,cap_style=1,join_style=1,quad_segs=8)

def text_shape(text,x,y,h,align='center',maxwidth=None,record=True):
    """Bottom of actual glyph bounds is y; h is actual glyph height, not font size."""
    tp=TextPath((0,0),text,size=10,prop=FontProperties(fname=FONT))
    rings=[]
    for arr in tp.to_polygons():
        if len(arr)>=4:
            p=Polygon(arr)
            if p.area>1e-8: rings.append(clean(p))
    # Even-odd fill handles counters (O, A, R...) and isolated glyphs.
    g=GeometryCollection()
    for p in rings: g=g.symmetric_difference(p)
    g=clean(g)
    minx,miny,maxx,maxy=g.bounds
    scale=h/(maxy-miny)
    g=affinity.translate(g,-minx,-miny)
    g=affinity.scale(g,xfact=scale,yfact=scale,origin=(0,0))
    width=g.bounds[2]
    if maxwidth is not None and width>maxwidth:
        g=affinity.scale(g,xfact=maxwidth/width,yfact=1,origin=(0,0)); width=maxwidth
    x0=x-width/2 if align=='center' else (x-width if align=='right' else x)
    g=affinity.translate(g,x0,y)
    if record: TEXTS.append({'text':text,'x':x,'y_bottom':y,'height':h,'width':width,'bounds':list(g.bounds)})
    return clean(g)

def frame(x0,y0,x1,y1,title=None,title_center=None):
    outer=rr(x0,y0,x1,y1,1.4)
    inner=rr(x0+.55,y0+.55,x1-.55,y1-.55,.85)
    g=outer.difference(inner)
    t=GeometryCollection()
    if title:
        tc=(x0+x1)/2 if title_center is None else title_center
        t=text_shape(title,tc,y1-1.3,2.6)
        bx=t.bounds
        g=g.difference(box(bx[0]-1,y1-2,bx[2]+1,y1+2))
    return merged([g,t])


def logo_shape(x,y):
    # Simplified radio tower mark, developed from the approved concept.
    gs=[line([(x+1.7,y),(x+3.5,y+4.3),(x+5.3,y)],.5),
        line([(x+2.2,y+1.0),(x+4.8,y+1.0)],.45),
        line([(x+2.6,y+2.2),(x+4.4,y+2.2)],.45),
        line([(x+2.2,y+1.),(x+4.4,y+2.2)],.42),
        Point(x+3.5,y+4.8).buffer(.38,quad_segs=16)]
    for radius in (1.8,3.0):
        for start,end in ((-60,60),(120,240)):
            angles=np.radians(np.linspace(start,end,30))
            gs.append(line([(x+3.5+radius*math.cos(a),y+4.8+radius*math.sin(a)) for a in angles],.45))
    return merged(gs)


def panel_plan(include_join=True):
    outline=rr(0,0,W,H,1.2)
    holes=[]
    for y in ROWS:
        for x in COLS:
            holes.extend([circle(x,y,HOLE_D),circle(x-9.5,y+12,SCREW_D),circle(x+9.5,y-12,SCREW_D)])
    # 465.1 mm horizontal rack mounting centres. 76.2 mm vertical.
    rack=[]
    for x in (8.75,W-8.75):
        for y in (5.95,H-5.95):
            slot=LineString([(x-1.7,y),(x+1.7,y)]).buffer(3.3,cap_style=1,quad_segs=32)
            holes.append(slot); rack.append((x,y))
    if include_join:
        holes += [circle(x,y,3.3) for x in JOIN_X for y in JOIN_Y]
    p=outline.difference(merged(holes))
    flanges=merged([box(x-13.1,y-15.6,x+13.1,y+15.6) for x in COLS for y in ROWS])
    return clean(p),outline,flanges,rack


def decorations():
    txt=[]; acc=[]
    # The header is intentionally divided at the assembly seam: no bisected letters.
    acc.append(logo_shape(28.,80.0))
    txt.append(text_shape('NetCore TETRA',42.,83.6,3.9,'left',maxwidth=71.))
    txt.append(text_shape('DUAL RADIO',181.,83.6,3.9,maxwidth=80.))
    txt.append(text_shape('RF / I/O PATCH PANEL',351.,83.6,3.9,maxwidth=179.))
    acc.append(frame(28.,.6,114.,80.7,'RADIO 1'))
    acc.append(frame(138.,.6,224.,80.7,'RADIO 2'))
    acc.append(line([(28.6,40.8),(113.4,40.8)],.5))
    acc.append(line([(138.6,40.8),(223.4,40.8)],.5))
    acc.append(frame(254.,42.0,450.,80.7,'DUPLEXER',320.))
    acc.append(line([(398.,42.5),(398.,80.15)],.5))
    acc.append(frame(254.,.6,294.,40.0))
    acc.append(frame(300.,.6,386.,40.0,'POWER'))
    acc.append(frame(410.,.6,450.,40.0))
    top=['TX','RX','TX','RX','TX','RX','ANT','AUX RF']
    bottom=['USB','LAN','USB','LAN','RESERVE','PWR 1','PWR 2','AUX']
    for x,label in zip(COLS,top): txt.append(text_shape(label,x,44.1,3.1,maxwidth=32.))
    for x,label in zip(COLS,bottom): txt.append(text_shape(label,x,1.9,3.2,maxwidth=32.))
    return merged(txt),merged(acc)


class MeshBuilder:
    """Closed 2.5D boundary mesh, not overlapping stacked extrusions."""
    def __init__(self): self.v=[]; self.f=[]; self.idx={}
    def vertex(self,x,y,z):
        key=(round(float(x),7),round(float(y),7),round(float(z),7))
        if key not in self.idx: self.idx[key]=len(self.v); self.v.append(key)
        return self.idx[key]
    def surface(self,g,z,up=True):
        for p in polys(g):
            tris=constrained_delaunay_triangles(p)
            area=0
            for tri in tris.geoms:
                co=np.asarray(tri.exterior.coords)[:3]
                area+=tri.area
                ids=[self.vertex(a,b,z) for a,b in co]
                sign=np.cross(np.r_[co[1]-co[0],0.],np.r_[co[2]-co[0],0.])[2]
                if (sign>0) != up: ids[1],ids[2]=ids[2],ids[1]
                self.f.append(ids)
            if abs(area-p.area)>1e-5*max(p.area,1):
                raise ValueError(f'Triangulation area mismatch: {area} vs {p.area}')
    def walls(self,g,z0,z1,reverse=False):
        for p in polys(g):
            for ring in [p.exterior,*p.interiors]:
                co=list(ring.coords)
                for (x0,y0),(x1,y1) in zip(co[:-1],co[1:]):
                    a=self.vertex(x0,y0,z0); b=self.vertex(x1,y1,z0)
                    c=self.vertex(x1,y1,z1); d=self.vertex(x0,y0,z1)
                    fs=[[a,b,c],[a,c,d]]
                    if reverse: fs=[f[::-1] for f in fs]
                    self.f.extend(fs)
    def result(self,name):
        m=trimesh.Trimesh(vertices=self.v,faces=self.f,process=False)
        m.remove_unreferenced_vertices()
        if not m.is_watertight:
            edges=m.edges_sorted
            unique,counts=np.unique(edges,axis=0,return_counts=True)
            bad=unique[counts!=2]
            np.save(WORK/f'{name}_bad_edges.npy',m.vertices[bad])
            raise ValueError(f'{name}: not watertight ({len(bad)} bad edges)')
        if not m.is_winding_consistent or m.volume<=0:
            raise ValueError(f'{name}: invalid winding/volume {m.volume}')
        m.metadata['name']=name
        return m


def extrusion(g,z0,z1,name):
    mb=MeshBuilder(); mb.surface(g,z0,False); mb.surface(g,z1,True); mb.walls(g,z0,z1)
    return mb.result(name)


def ribs_for(p,x0,x1):
    r=merged([box(max(18.,x0+.8),.8,min(W-18.,x1-.8),3.8),
              box(max(18.,x0+.8),H-3.8,min(W-18.,x1-.8),H-.8),
              box(max(18.,x0+.8),41.7,min(W-18.,x1-.8),44.7),
              box(123.,3.3,126.,H-3.3), box(398.5,3.3,401.5,H-3.3)])
    r=r.intersection(box(x0+.8,.8,x1-.8,H-.8))
    # Leave a clear flat rear mounting area for the splice plate.
    r=r.difference(box(SPLIT-19.,7.,SPLIT+19.,81.))
    # Keep every rib away from the perimeter/cutouts to ensure mesh topology and cable clearance.
    return clean(r.intersection(p.buffer(-.65)))


def panel_parts(p,t,a,ribs,name):
    g=merged([t,a])
    assert p.covers(g),f'{name}: decoration outside panel'
    assert t.intersection(a).area<1e-6,f'{name}: materials overlap'
    mb=MeshBuilder()
    mb.surface(p.difference(ribs),0.,False)
    if not ribs.is_empty:
        mb.surface(ribs,-RIB_HEIGHT,False); mb.walls(ribs,-RIB_HEIGHT,0.)
    mb.surface(p.difference(g),THICKNESS,True)
    mb.surface(g,THICKNESS-INLAY,True)
    mb.walls(p,0.,THICKNESS)
    mb.walls(g,THICKNESS-INLAY,THICKNESS,reverse=True)
    base=mb.result(name+'_Platte')
    text=extrusion(t,THICKNESS-INLAY,THICKNESS,name+'_Schrift')
    accent=extrusion(a,THICKNESS-INLAY,THICKNESS,name+'_Logo_Linien') if not a.is_empty else None
    expected=p.area*THICKNESS+ribs.area*RIB_HEIGHT-g.area*INLAY
    assert abs(base.volume-expected)<.005,f'Wrong volume: {base.volume} vs {expected}'
    return [(base,0),(text,1)]+([(accent,2)] if accent is not None else [])


def print_transform(mesh,xorigin=0.,xplace=0.,yplace=0.):
    """Rotate 180 deg about X, so the correct front is flat on the bed at z=0."""
    m=mesh.copy()
    m.apply_transform(np.array([[1,0,0,xplace-xorigin],[0,-1,0,H+yplace],[0,0,-1,THICKNESS],[0,0,0,1]],float))
    return m


def fmt(x): return f'{float(x):.7f}'.rstrip('0').rstrip('.') or '0'

def write3mf(path,objects,title):
    """3MF core assemblies plus Bambu/Prusa part metadata. No printer preset is forced."""
    ns='http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
    lines=['<?xml version="1.0" encoding="UTF-8"?>',f'<model unit="millimeter" xml:lang="en-US" xmlns="{ns}">',
           f'<metadata name="Title">{escape(title)}</metadata>',
           '<metadata name="Application">NetCore-TETRA Parametric CAD</metadata>',
           '<metadata name="CreationDate">2026-10-03</metadata>',
           '<metadata name="Description">Multipart model. Plate, lettering and accents are independent material bodies. Unsliced; select printer and filaments before printing.</metadata>',
           '<resources>', '<basematerials id="1">']
    for n,c in PALETTE: lines.append(f'<base name={quoteattr(n)} displaycolor="{c}"/>')
    lines.append('</basematerials>')
    oid=2; build=[]; modelcfg=['<?xml version="1.0" encoding="UTF-8"?>','<config>']; prusa=['<?xml version="1.0" encoding="UTF-8"?>','<config>']
    for name,parts in objects:
        child=[]
        for mesh,color in parts:
            cid=oid; oid+=1; child.append((cid,mesh,color))
            lines.append(f'<object id="{cid}" type="model" name={quoteattr(mesh.metadata.get("name",PALETTE[color][0]))} pid="1" pindex="{color}"><mesh><vertices>')
            lines.extend(f'<vertex x="{fmt(x)}" y="{fmt(y)}" z="{fmt(z)}"/>' for x,y,z in mesh.vertices)
            lines.append('</vertices><triangles>')
            lines.extend(f'<triangle v1="{v1}" v2="{v2}" v3="{v3}"/>' for v1,v2,v3 in mesh.faces)
            lines.append('</triangles></mesh></object>')
        root=oid; oid+=1
        lines.append(f'<object id="{root}" type="model" name={quoteattr(name)}><components>')
        lines.extend(f'<component objectid="{cid}"/>' for cid,_,_ in child)
        lines.append('</components></object>'); build.append(root)
        modelcfg.extend([f'<object id="{root}">',f'<metadata key="name" value={quoteattr(name)}/>', '<metadata key="extruder" value="1"/>'])
        prusa.extend([f'<object id="{root}" instances_count="1">',f'<metadata type="object" key="name" value={quoteattr(name)}/>'])
        first=0
        for cid,m,c in child:
            nm=m.metadata.get('name',PALETTE[c][0])
            modelcfg.extend([f'<part id="{cid}" subtype="normal_part">',f'<metadata key="name" value={quoteattr(nm)}/>',f'<metadata key="extruder" value="{c+1}"/>','<metadata key="matrix" value="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1"/>','</part>'])
            prusa.extend([f'<volume firstid="{first}" lastid="{first+len(m.faces)-1}">',f'<metadata type="volume" key="name" value={quoteattr(nm)}/>',f'<metadata type="volume" key="extruder" value="{c+1}"/>','</volume>']); first+=len(m.faces)
        modelcfg.append('</object>'); prusa.append('</object>')
    modelcfg.append('</config>'); prusa.append('</config>')
    lines.extend(['</resources>','<build>'])
    lines.extend(f'<item objectid="{i}"/>' for i in build)
    lines.append('</build></model>')
    ct='''<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/><Default Extension="config" ContentType="application/xml"/></Types>'''
    rel='''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'''
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        z.writestr('[Content_Types].xml',ct); z.writestr('_rels/.rels',rel)
        z.writestr('3D/3dmodel.model','\n'.join(lines))
        z.writestr('Metadata/model_settings.config','\n'.join(modelcfg))
        z.writestr('Metadata/Slic3r_PE_model.config','\n'.join(prusa))
    # Independent import by trimesh validates resource and component references.
    reloaded=trimesh.load(path,force='scene')
    assert len(reloaded.geometry)==sum(len(ps) for _,ps in objects)
    print('3MF:',path.name,'bytes',path.stat().st_size,flush=True)


def validate_parts(parts):
    return [{'name':m.metadata.get('name'),'vertices':len(m.vertices),'triangles':len(m.faces),
             'watertight':bool(m.is_watertight),'winding_consistent':bool(m.is_winding_consistent),
             'bounds_mm':m.bounds.tolist(),'volume_mm3':float(m.volume),'color_slot':c+1} for m,c in parts]


def make_svg(path,p,t,a,flanges=None):
    def geom(g,fill,opacity=1):
        s=[]
        for pol in polys(g):
            paths=[]
            for ring in [pol.exterior,*pol.interiors]:
                co=list(ring.coords)
                paths.append('M '+' L '.join(f'{x:.5f},{y:.5f}' for x,y in co)+' Z')
            s.append(f'<path d="{" ".join(paths)}" fill="{fill}" opacity="{opacity}" fill-rule="evenodd"/>')
        return ''.join(s)
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="1930" height="353" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" fill="#eceff3"/><g transform="translate(0 {H}) scale(1 -1)">{geom(p,PALETTE[0][1])}{geom(t,PALETTE[1][1])}{geom(a,PALETTE[2][1])}'
    if flanges is not None: svg+=geom(flanges,'#999999',.6)
    svg+='</g></svg>';path.write_text(svg)


def main():
    OUT.mkdir(parents=True,exist_ok=True); WORK.mkdir(parents=True,exist_ok=True)
    p,outline,flanges,rack=panel_plan(True)
    txt,accent=decorations()
    assert txt.intersection(accent).area<1e-7,'Text and accents overlap'
    for name,g in [('text',txt),('accent',accent)]:
        print(name,'area',g.area,'flange intersection',g.intersection(flanges).area,flush=True)
        assert g.intersection(flanges).area<1e-6,'Graphics would be hidden by flanges'
        assert p.covers(g),'Graphics exceed available panel'
    make_svg(WORK/'front_actual.svg',p,txt,accent)
    make_svg(WORK/'front_flanges.svg',p,txt,accent,flanges)
    import cairosvg
    cairosvg.svg2png(url=str(WORK/'front_actual.svg'),write_to=str(WORK/'front_actual.png'))
    cairosvg.svg2png(url=str(WORK/'front_flanges.svg'),write_to=str(WORK/'front_flanges.png'))
    allprint=[]; assembly=[]; records=[]
    for name,x0,x1,yp in [('Links_RADIO',0.,SPLIT-SEAM/2,10.),('Rechts_DUP_POWER',SPLIT+SEAM/2,W,108.)]:
        clip=box(x0,-1,x1,H+1)
        pp=clean(p.intersection(clip)); tt=clean(txt.intersection(clip)); aa=clean(accent.intersection(clip))
        rrib=ribs_for(pp,x0,x1)
        parts=panel_parts(pp,tt,aa,rrib,name)
        records+=validate_parts(parts)
        assembly.append((name,parts))
        moved=[(print_transform(m,x0,7.4,yp),c) for m,c in parts]
        allprint.append((name,moved))
        individual=[(print_transform(m,x0,7.4,60.),c) for m,c in parts]
        write3mf(OUT/f'{name}_A1.3mf',[(name,individual)],f'NetCore-TETRA {name} - face down')
        for m,c in parts:
            mp=print_transform(m,x0)
            (OUT/'STL_Fallback').mkdir(exist_ok=True)
            mp.export(OUT/'STL_Fallback'/f'{m.metadata["name"]}.stl')
    write3mf(OUT/'NetCore_Tetra_Patchpanel_A1_Mehrfarbig.3mf',allprint,'NetCore-TETRA 2U - A1 print layout, two halves')
    # Rear splice strap, matching the six front mounting holes.
    strap=rr(SPLIT-18,8,SPLIT+18,80,2).difference(merged([circle(x,y,3.3) for x in JOIN_X for y in JOIN_Y]))
    sm=extrusion(strap,0,4,'Verbindungsplatte_36x72x4')
    sm.apply_translation([-(SPLIT-18),-8,0])
    sp=sm.copy(); sp.apply_translation([10,10,0])
    accessory=[('Verbindungsplatte',[(sp,0)])]
    for i in range(3):
        d=rr(-13,-15.5,13,15.5,3.0).difference(merged([circle(-9.5,12,3.3),circle(9.5,-12,3.3)]))
        b=extrusion(d,0,2,f'D_Blindplatte_{i+1}')
        b.apply_translation([75+i*36,32,0]); accessory.append((f'Blindplatte_{i+1}',[(b,0)]))
    write3mf(OUT/'Zubehoer_Verbindung_und_3_Blindplatten.3mf',accessory,'NetCore-TETRA rear splice and three D blank covers')
    sm.export(OUT/'STL_Fallback'/'Verbindungsplatte.stl')
    # Functional fitting coupon including two rows at the actual 41 mm pitch.
    pw=136.; qp=rr(0,0,pw,H,1.2); qh=[]; qt=[]
    for x,d in zip([24.,68.,112.],[23.6,24.0,24.2]):
        for y in ROWS:
            qh += [circle(x,y,d),circle(x-9.5,y+12,SCREW_D),circle(x+9.5,y-12,SCREW_D)]
        qt.append(text_shape(f'{d:.1f}',x,44.1,3.1,record=False))
        qt.append(text_shape('M3  3.3',x,1.9,3.0,record=False))
    qt.append(text_shape('NEUTRIK D - PASSFORMTEST',pw/2,83.6,3.1,maxwidth=125,record=False))
    qp=qp.difference(merged(qh)); qt=merged(qt)
    qparts=panel_parts(qp,qt,GeometryCollection(),GeometryCollection(),'Passformtest')
    qprint=[(print_transform(m,0,30,40),c) for m,c in qparts]
    write3mf(OUT/'ZUERST_DRUCKEN_Neutrik_Passformtest.3mf',[('Passformtest',qprint)],'NetCore-TETRA D cutout fitting test')
    records+=validate_parts(qparts)
    # Full width CAD assembly (not an A1 print layout) with the splice in assembly position.
    sas=sm.copy();sas.apply_translation([SPLIT-18,8,-4])
    assembly.append(('Verbindungsplatte_hinten',[(sas,0)]))
    write3mf(OUT/'Montageansicht_482mm_NICHT_A1_Drucklayout.3mf',assembly,'NetCore-TETRA assembled panel - not an A1 bed layout')
    (OUT/'Geometriepruefung.json').write_text(json.dumps({'note':'Computational mesh and layout checks only; no physical fit/load test and no Bambu Studio GUI slice validation.',
       'panel_width_mm':W,'panel_actual_height_mm':H,'nominal_2U_height_mm':H_NOMINAL,
       'edge_clearance_mm':EDGE_CLEARANCE,'body_mm':THICKNESS,'inlay_mm':INLAY,'overall_depth_with_ribs_mm':THICKNESS+RIB_HEIGHT,
       'seam_gap_mm':SEAM,'half_width_mm':SPLIT-SEAM/2,'rack_pitch_x_mm':465.1,'rack_pitch_y_mm':76.2,
       'centers_x_mm':COLS,'centers_y_from_actual_bottom_mm':ROWS,'d_cutout_mm':HOLE_D,'screw_hole_mm':SCREW_D,
       'texts':TEXTS,'meshes':records},indent=2),encoding='utf-8')
    with (OUT/'Lochkoordinaten_mm.csv').open('w',newline='',encoding='utf-8-sig') as f:
        cw=csv.writer(f,delimiter=';');cw.writerow(['Position','Funktion','X ab linker Kante','Y ab realer Unterkante','Durchmesser mm','Ansicht'])
        top=['RADIO1 TX','RADIO1 RX','RADIO2 TX','RADIO2 RX','DUP TX','DUP RX','DUP ANT','AUX RF']
        bot=['RADIO1 USB','RADIO1 LAN','RADIO2 USB','RADIO2 LAN','RESERVE','PWR1','PWR2','AUX']
        for row,y,names in [('unten',ROWS[0],bot),('oben',ROWS[1],top)]:
            for i,(x,n) in enumerate(zip(COLS,names),1):
                cw.writerow([f'{row}_{i}',n,x,y,HOLE_D,'Vorderansicht'])
                cw.writerow([f'{row}_{i}_M3_links_oben',n,x-9.5,y+12,SCREW_D,'Vorderansicht'])
                cw.writerow([f'{row}_{i}_M3_rechts_unten',n,x+9.5,y-12,SCREW_D,'Vorderansicht'])
        for x,y in rack: cw.writerow(['Rack','Langloch 10 x 6.6',x,y,'','Vorderansicht'])
        for x in JOIN_X:
            for y in JOIN_Y: cw.writerow(['Verbindung','M3',x,y,3.3,'Vorderansicht'])
    if Path(__file__).resolve() != (OUT/'build_panel.py').resolve():
        shutil.copy2(__file__,OUT/'build_panel.py')
    print('FINISHED',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path.cwd()/'NetCore_Tetra_Patchpanel_v1')
    parser.add_argument('--workdir',type=Path,default=None)
    parser.add_argument('--hole-d',type=float,default=24.2,help='Main D cutout diameter in mm; choose after coupon test.')
    parser.add_argument('--screw-d',type=float,default=3.3,help='D connector mounting hole diameter in mm.')
    args=parser.parse_args()
    if not 23.0<=args.hole_d<=24.5: parser.error('--hole-d must be between 23.0 and 24.5 mm')
    if not 3.0<=args.screw_d<=3.5: parser.error('--screw-d must be between 3.0 and 3.5 mm')
    OUT=args.output.resolve()
    WORK=args.workdir.resolve() if args.workdir else OUT.parent/'.netcore_panel_work'
    HOLE_D=args.hole_d; SCREW_D=args.screw_d
    main()
