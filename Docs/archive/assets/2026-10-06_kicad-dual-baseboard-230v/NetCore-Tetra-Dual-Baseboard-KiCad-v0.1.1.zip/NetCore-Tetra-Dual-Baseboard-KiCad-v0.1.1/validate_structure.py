#!/usr/bin/env python3
"""Static format checks for this specific legacy KiCad project.

This is NOT KiCad's parser, ERC, DRC, or a circuit-safety check.
No files are changed. Run: python validate_structure.py [PROJECT_DIRECTORY]
"""
from __future__ import annotations
import collections
import json
from pathlib import Path
import re
import shlex
import sys

LABEL_TYPES = {'Input', 'Output', 'BiDi', '3State', 'UnSpc'}
PIN_TYPES = {'I', 'O', 'B', 'T', 'P', 'U', 'W', 'w', 'C', 'E', 'N'}
ROOT_NAME = 'NetCore-Tetra-Dual-Baseboard.sch'


def sexpr_check(text: str) -> None:
    """Check nesting/strings; not a KiCad grammar validator."""
    depth = 0
    quoted = escaped = False
    for c in text:
        if quoted:
            if escaped:
                escaped = False
            elif c == '\\':
                escaped = True
            elif c == '"':
                quoted = False
        elif c == '"':
            quoted = True
        elif c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth < 0:
                raise ValueError('Unmatched closing parenthesis')
    if depth or quoted:
        raise ValueError('Unclosed parenthesis or string')


def read_library(path: Path) -> dict:
    symbols = {}
    current = None
    in_draw = False
    for number, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(), 1):
        if not line or line.startswith('#'):
            continue
        t = shlex.split(line)
        if t[0] == 'EESchema-LIBRARY':
            continue
        if t[0] == 'DEF':
            assert current is None and len(t) == 10, f'{path.name}:{number}: invalid DEF'
            assert t[1] not in symbols, f'{path.name}:{number}: duplicate symbol'
            current = {'name': t[1], 'pins': {}}
        elif t[0] == 'DRAW':
            assert current is not None and not in_draw
            in_draw = True
        elif t[0] == 'ENDDRAW':
            assert in_draw
            in_draw = False
        elif t[0] == 'ENDDEF':
            assert current is not None and not in_draw
            symbols[current['name']] = current
            current = None
        elif re.fullmatch(r'F\d+', t[0]):
            assert current is not None and len(t) == 9, f'{path.name}:{number}: invalid field'
            for v in t[2:5]:
                int(v)
        elif t[0] == 'S':
            assert in_draw and len(t) == 9
            for v in t[1:8]:
                int(v)
            assert t[8] in ('F', 'f', 'N')
        elif t[0] == 'X':
            assert in_draw and len(t) in (12, 13)
            assert t[2] not in current['pins'], f'{path.name}:{number}: duplicate pin'
            assert t[6] in ('U', 'D', 'L', 'R')
            assert t[11] in PIN_TYPES
            for i in (3, 4, 5, 7, 8, 9, 10):
                int(t[i])
            current['pins'][t[2]] = {'name': t[1], 'type': t[11]}
        else:
            raise ValueError(f'{path.name}:{number}: unsupported library record {t[0]}')
    assert current is None and not in_draw, f'{path.name}: truncated library'
    return symbols


def read_sheet(path: Path, symbols: dict) -> dict:
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    assert lines[0] == 'EESchema Schematic File Version 4'
    assert lines[-1] == '$EndSCHEMATC'
    end_header = lines.index('EELAYER END')
    assert all(x.startswith(('LIBS:', 'EELAYER ')) for x in lines[1:end_header+1])
    i = end_header + 1
    refs, ids, sheets = [], [], []
    counts = collections.Counter()
    shape_counts = collections.Counter()
    while i < len(lines):
        l = lines[i]
        t = l.split()
        where = f'{path.name}:{i+1}'
        if l == '$EndSCHEMATC':
            assert i == len(lines)-1
            break
        if l.startswith('$Descr '):
            assert t[1] == 'A3' and len(t) == 4
            int(t[2]); int(t[3])
            j = lines.index('$EndDescr', i+1)
            for h in lines[i+1:j]:
                ht = shlex.split(h)
                assert ht[0] in ('encoding', 'Sheet', 'Title', 'Date', 'Rev', 'Comp',
                                  'Comment1', 'Comment2', 'Comment3', 'Comment4'), where
            i = j+1
        elif l in ('$Comp', '$Sheet'):
            end = '$EndComp' if l == '$Comp' else '$EndSheet'
            j = lines.index(end, i+1)
            block = lines[i+1:j]
            if l == '$Comp':
                bt = [shlex.split(b) for b in block]
                assert bt[0][0] == 'L' and len(bt[0]) == 3, where
                lib, name = bt[0][1].split(':', 1)
                assert lib == 'NetCore_Tetra' and name in symbols, where+' unresolved symbol'
                refs.append(bt[0][2])
                assert bt[1][0] == 'U' and len(bt[1]) == 4, where
                int(bt[1][1]); int(bt[1][2]); int(bt[1][3],16)
                ids.append(bt[1][3])
                assert bt[2][0] == 'P' and len(bt[2]) == 3, where
                int(bt[2][1]); int(bt[2][2])
                for f in bt[3:-2]:
                    assert f[0] == 'F' and len(f) == 10, where+' malformed field'
                    assert f[3] in ('H','V') and f[8] in ('L','C','R'), where
                    for v in f[4:7]:int(v)
                assert len(bt[-2]) == 3 and len(bt[-1]) == 4, where
                a,b,c,d = map(int,bt[-1])
                assert abs(a*d-b*c) == 1, where+' bad transform'
                counts['components'] += 1
            else:
                assert len(block) == 4, where
                st = shlex.split(block[0]); assert st[0] == 'S' and len(st) == 5
                for v in st[1:]:int(v)
                ut = block[1].split(); assert ut[0] == 'U'; int(ut[1],16)
                ids.append(ut[1])
                assert shlex.split(block[2])[0] == 'F0'
                ft = shlex.split(block[3]); assert ft[0] == 'F1'
                target = ft[1]
                assert (path.parent/target).is_file(), where+' missing subsheet'
                sheets.append(target)
                counts['subsheet_references'] += 1
            i = j+1
        elif l.startswith('Text '):
            kind = t[1]
            assert kind in ('GLabel','HLabel','Label','Notes'), where
            for n in t[2:6]:int(n)
            assert int(t[4]) in (0,1,2,3), where
            assert int(t[5]) > 0
            if kind in ('GLabel','HLabel'):
                assert len(t) == 9, where
                assert t[6] in LABEL_TYPES, where+f': invalid label type {t[6]}'
                assert t[7] in ('~','Italic')
                int(t[8]); shape_counts[t[6]] += 1
            else:
                assert len(t) == 8, where
                assert t[6] in ('~','Italic')
                int(t[7])
            assert i+1 < len(lines) and lines[i+1] and not lines[i+1].startswith('$'), where
            counts[kind] += 1
            i += 2
        elif l in ('Wire Wire Line', 'Wire Notes Line'):
            xy = lines[i+1].split()
            assert len(xy) == 4, where
            for n in xy:int(n)
            counts['electrical_wires' if l == 'Wire Wire Line' else 'graphic_lines'] += 1
            i += 2
        elif l.startswith(('Connection ~ ','NoConn ~ ')):
            assert len(t) == 4
            int(t[2]);int(t[3])
            counts[t[0]] += 1
            i += 1
        else:
            raise ValueError(where+': unsupported schematic record '+l)
    assert len(refs) == len(set(refs)), path.name+': duplicate reference'
    assert len(ids) == len(set(ids)), path.name+': duplicate timestamp'
    return {'file':path.name, 'checks_passed':True, 'counts':dict(counts),
            'label_type_counts':dict(shape_counts),'subsheet_files':sheets,
            'references':refs, 'legacy_timestamps':ids}


def main() -> int:
    base = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
    symbols = read_library(base/'NetCore_Tetra.lib')
    sheets = [read_sheet(p,symbols) for p in sorted(base.glob('*.sch'))]
    by_name = {x['file']:x for x in sheets}
    visited = set()
    def visit(name):
        assert name not in visited, 'Unexpected repeated/cyclic sheet in this project'
        visited.add(name)
        for child in by_name[name]['subsheet_files']:visit(child)
    visit(ROOT_NAME)
    assert visited == set(by_name), 'Orphan schematic file'
    refs = [r for s in sheets for r in s['references']]
    assert len(refs) == len(set(refs)), 'Duplicate reference across hierarchy'
    ids = [r for s in sheets for r in s['legacy_timestamps']]
    assert len(ids) == len(set(ids)), 'Duplicate legacy timestamp across hierarchy'
    json.load((base/'NetCore-Tetra-Dual-Baseboard.kicad_pro').open(encoding='utf-8'))
    for p in (base/'sym-lib-table',base/'fp-lib-table',base/'NetCore-Tetra-Dual-Baseboard.kicad_pcb'):
        sexpr_check(p.read_text(encoding='utf-8'))
    for p in (base/'NetCore_Tetra.pretty').glob('*.kicad_mod'):sexpr_check(p.read_text(encoding='utf-8'))
    print(json.dumps({'validation':'static checks of implemented record subset ONLY',
        'kicad_parser_run':False,'erc_run':False,'drc_run':False,
        'all_implemented_checks_passed':True,'schematic_files':len(sheets),
        'components':len(refs),'library_symbols':len(symbols),
        'global_labels':sum(s['counts'].get('GLabel',0) for s in sheets),
        'electrical_wires':sum(s['counts'].get('electrical_wires',0) for s in sheets),
        'hierarchy_complete':True,'sheets':sheets},indent=2,ensure_ascii=False))
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (AssertionError,ValueError,IndexError,KeyError,OSError) as e:
        print(f'CHECK FAILED: {e}',file=sys.stderr)
        raise SystemExit(1)
