EESchema Schematic File Version 4
LIBS:NetCore_Tetra
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
encoding utf-8
Sheet 6 6
Title "Local UI, Mode Switches, Fans, PA Power and Protected External I/O"
Date "2026-09-17"
Rev "0.1.1-format-fix"
Comp "NetCore-Tetra / Jan Hoffmeister"
Comment1 "Engineering concept - not released for mains or production"
Comment2 "Dual Pi + dual SXceiver compact baseboard"
Comment3 "Default power path: external 12 VDC"
Comment4 "Run ERC/DRC and component/footprint lock before fabrication"
$EndDescr
Text Notes 650 600 0    100   ~ 0
LOCAL UI, COOLING AND INDUSTRIAL I/O
Wire Notes Line
	600 1050 5400 1050
Wire Notes Line
	5400 1050 5400 5300
Wire Notes Line
	5400 5300 600 5300
Wire Notes Line
	600 5300 600 1050
Text Notes 680 1170 0    70   ~ 0
MODE / NODE-ID / STATUS LEDS
$Comp
L NetCore_Tetra:DIPSW_8 SW611
U 1 1 65000045
P 1700 2500
F 0 "SW611" H 1700 1790 50  0000 C CNN
F 1 "A MODE + ID" H 1700 1890 50  0000 C CNN
F 2 "Button_Switch_SMD:SW_DIP_SPSTx08_Slide_Copal_CHS-08TA" H 1700 2500 50  0001 C CNN
F 3 "" H 1700 2500 50  0001 C CNN
	1    1700 2500
	1    0    0    -1  
$EndComp
Wire Wire Line
	1150 2150 890 2150
Text GLabel 890 2150 2    42   Input ~ 0
A_MODE0
Wire Wire Line
	1150 2250 890 2250
Text GLabel 890 2250 2    42   Input ~ 0
A_MODE1
Wire Wire Line
	1150 2350 890 2350
Text GLabel 890 2350 2    42   Input ~ 0
A_RF_INHIBIT
Wire Wire Line
	1150 2450 890 2450
Text GLabel 890 2450 2    42   Input ~ 0
A_CONFIG_LOCK
Wire Wire Line
	1150 2550 890 2550
Text GLabel 890 2550 2    42   Input ~ 0
A_ID0
Wire Wire Line
	1150 2650 890 2650
Text GLabel 890 2650 2    42   Input ~ 0
A_ID1
Wire Wire Line
	1150 2750 890 2750
Text GLabel 890 2750 2    42   Input ~ 0
A_ID2
Wire Wire Line
	1150 2850 890 2850
Text GLabel 890 2850 2    42   Input ~ 0
A_ID3
Wire Wire Line
	2250 2150 2510 2150
Text GLabel 2510 2150 0    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:LED D611
U 1 1 65000046
P 900 4300
F 0 "D611" H 900 3940 50  0000 C CNN
F 1 "A PWR" H 900 4040 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 900 4300 50  0001 C CNN
F 3 "" H 900 4300 50  0001 C CNN
	1    900 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	550 4300 290 4300
Text GLabel 290 4300 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	1250 4300 1510 4300
Text GLabel 1510 4300 0    42   Input ~ 0
A_LED_PWR
$Comp
L NetCore_Tetra:LED D612
U 1 1 65000047
P 1450 4300
F 0 "D612" H 1450 3940 50  0000 C CNN
F 1 "A RF" H 1450 4040 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 1450 4300 50  0001 C CNN
F 3 "" H 1450 4300 50  0001 C CNN
	1    1450 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	1100 4300 840 4300
Text GLabel 840 4300 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	1800 4300 2060 4300
Text GLabel 2060 4300 0    42   Input ~ 0
A_LED_RF
$Comp
L NetCore_Tetra:LED D613
U 1 1 65000048
P 2000 4300
F 0 "D613" H 2000 3940 50  0000 C CNN
F 1 "A FAULT" H 2000 4040 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 2000 4300 50  0001 C CNN
F 3 "" H 2000 4300 50  0001 C CNN
	1    2000 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	1650 4300 1390 4300
Text GLabel 1390 4300 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	2350 4300 2610 4300
Text GLabel 2610 4300 0    42   Input ~ 0
A_LED_FAULT
$Comp
L NetCore_Tetra:LED D614
U 1 1 65000049
P 2550 4300
F 0 "D614" H 2550 3940 50  0000 C CNN
F 1 "A SERVICE" H 2550 4040 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 2550 4300 50  0001 C CNN
F 3 "" H 2550 4300 50  0001 C CNN
	1    2550 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	2200 4300 1940 4300
Text GLabel 1940 4300 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	2900 4300 3160 4300
Text GLabel 3160 4300 0    42   Input ~ 0
A_LED_SERVICE
$Comp
L NetCore_Tetra:DIPSW_8 SW621
U 1 1 6500004A
P 4000 2500
F 0 "SW621" H 4000 1790 50  0000 C CNN
F 1 "B MODE + ID" H 4000 1890 50  0000 C CNN
F 2 "Button_Switch_SMD:SW_DIP_SPSTx08_Slide_Copal_CHS-08TA" H 4000 2500 50  0001 C CNN
F 3 "" H 4000 2500 50  0001 C CNN
	1    4000 2500
	1    0    0    -1  
$EndComp
Wire Wire Line
	3450 2150 3190 2150
Text GLabel 3190 2150 2    42   Input ~ 0
B_MODE0
Wire Wire Line
	3450 2250 3190 2250
Text GLabel 3190 2250 2    42   Input ~ 0
B_MODE1
Wire Wire Line
	3450 2350 3190 2350
Text GLabel 3190 2350 2    42   Input ~ 0
B_RF_INHIBIT
Wire Wire Line
	3450 2450 3190 2450
Text GLabel 3190 2450 2    42   Input ~ 0
B_CONFIG_LOCK
Wire Wire Line
	3450 2550 3190 2550
Text GLabel 3190 2550 2    42   Input ~ 0
B_ID0
Wire Wire Line
	3450 2650 3190 2650
Text GLabel 3190 2650 2    42   Input ~ 0
B_ID1
Wire Wire Line
	3450 2750 3190 2750
Text GLabel 3190 2750 2    42   Input ~ 0
B_ID2
Wire Wire Line
	3450 2850 3190 2850
Text GLabel 3190 2850 2    42   Input ~ 0
B_ID3
Wire Wire Line
	4550 2150 4810 2150
Text GLabel 4810 2150 0    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:LED D621
U 1 1 6500004B
P 3200 4300
F 0 "D621" H 3200 3940 50  0000 C CNN
F 1 "B PWR" H 3200 4040 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 3200 4300 50  0001 C CNN
F 3 "" H 3200 4300 50  0001 C CNN
	1    3200 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	2850 4300 2590 4300
Text GLabel 2590 4300 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	3550 4300 3810 4300
Text GLabel 3810 4300 0    42   Input ~ 0
B_LED_PWR
$Comp
L NetCore_Tetra:LED D622
U 1 1 6500004C
P 3750 4300
F 0 "D622" H 3750 3940 50  0000 C CNN
F 1 "B RF" H 3750 4040 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 3750 4300 50  0001 C CNN
F 3 "" H 3750 4300 50  0001 C CNN
	1    3750 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	3400 4300 3140 4300
Text GLabel 3140 4300 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	4100 4300 4360 4300
Text GLabel 4360 4300 0    42   Input ~ 0
B_LED_RF
$Comp
L NetCore_Tetra:LED D623
U 1 1 6500004D
P 4300 4300
F 0 "D623" H 4300 3940 50  0000 C CNN
F 1 "B FAULT" H 4300 4040 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 4300 4300 50  0001 C CNN
F 3 "" H 4300 4300 50  0001 C CNN
	1    4300 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	3950 4300 3690 4300
Text GLabel 3690 4300 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	4650 4300 4910 4300
Text GLabel 4910 4300 0    42   Input ~ 0
B_LED_FAULT
$Comp
L NetCore_Tetra:LED D624
U 1 1 6500004E
P 4850 4300
F 0 "D624" H 4850 3940 50  0000 C CNN
F 1 "B SERVICE" H 4850 4040 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 4850 4300 50  0001 C CNN
F 3 "" H 4850 4300 50  0001 C CNN
	1    4850 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	4500 4300 4240 4300
Text GLabel 4240 4300 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	5200 4300 5460 4300
Text GLabel 5460 4300 0    42   Input ~ 0
B_LED_SERVICE
Text Notes 850 4900 0    42   ~ 0
DIP bits: [1:0] MODE 00 LOCAL / 01 HYBRID / 10 RECOVERY / 11 SERVICE; bit2 RF INHIBIT;
Text Notes 850 4962 0    42   ~ 0
bit3 CONFIG LOCK; bits [7:4] NODE ID. Switches close to GND; MCP23017 pull-ups/firmware debounce.
Wire Notes Line
	5700 1050 10500 1050
Wire Notes Line
	10500 1050 10500 5300
Wire Notes Line
	10500 5300 5700 5300
Wire Notes Line
	5700 5300 5700 1050
Text Notes 5780 1170 0    70   ~ 0
TFT / OLED / DEBUG
$Comp
L NetCore_Tetra:TFT_SPI_HEADER J601
U 1 1 6500004F
P 7000 2850
F 0 "J601" H 7000 1990 50  0000 C CNN
F 1 "SPI TFT + TOUCH" H 7000 2090 50  0000 C CNN
F 2 "NetCore_Tetra:TFT_Header_2x6" H 7000 2850 50  0001 C CNN
F 3 "" H 7000 2850 50  0001 C CNN
	1    7000 2850
	1    0    0    -1  
$EndComp
Wire Wire Line
	6375 2350 6115 2350
Text GLabel 6115 2350 2    42   Output ~ 0
3V3_AON
Wire Wire Line
	6375 2550 6115 2550
Text GLabel 6115 2550 2    42   Input ~ 0
GND
Wire Wire Line
	6375 2750 6115 2750
Text GLabel 6115 2750 2    42   Input ~ 0
UI_SPI_SCK
Wire Wire Line
	6375 2950 6115 2950
Text GLabel 6115 2950 2    42   Input ~ 0
UI_SPI_MOSI
Wire Wire Line
	6375 3150 6115 3150
Text GLabel 6115 3150 2    42   Output ~ 0
UI_SPI_MISO
Wire Wire Line
	6375 3350 6115 3350
Text GLabel 6115 3350 2    42   Input ~ 0
TFT_CS
Wire Wire Line
	7625 2350 7885 2350
Text GLabel 7885 2350 0    42   Input ~ 0
TFT_DC
Wire Wire Line
	7625 2550 7885 2550
Text GLabel 7885 2550 0    42   Input ~ 0
TFT_RST
Wire Wire Line
	7625 2750 7885 2750
Text GLabel 7885 2750 0    42   Input ~ 0
TFT_BL
Wire Wire Line
	7625 2950 7885 2950
Text GLabel 7885 2950 0    42   Input ~ 0
TOUCH_CS
Wire Wire Line
	7625 3150 7885 3150
Text GLabel 7885 3150 0    42   Output ~ 0
TOUCH_IRQ
Wire Wire Line
	7625 3350 7885 3350
Text GLabel 7885 3350 0    42   Input ~ 0
TFT_SD_CS_SPARE
$Comp
L NetCore_Tetra:OLED_I2C_HEADER J602
U 1 1 65000050
P 9200 2100
F 0 "J602" H 9200 1590 50  0000 C CNN
F 1 "I2C OLED" H 9200 1690 50  0000 C CNN
F 2 "NetCore_Tetra:JST_SH_4" H 9200 2100 50  0001 C CNN
F 3 "" H 9200 2100 50  0001 C CNN
	1    9200 2100
	1    0    0    -1  
$EndComp
Wire Wire Line
	8700 1950 8440 1950
Text GLabel 8440 1950 2    42   Output ~ 0
3V3_AON
Wire Wire Line
	8700 2250 8440 2250
Text GLabel 8440 2250 2    42   Input ~ 0
GND
Wire Wire Line
	9700 1950 9960 1950
Text GLabel 9960 1950 0    42   BiDi ~ 0
OLED_SDA
Wire Wire Line
	9700 2250 9960 2250
Text GLabel 9960 2250 0    42   Input ~ 0
OLED_SCL
$Comp
L NetCore_Tetra:USB_C_DEBUG J603
U 1 1 65000051
P 9200 3650
F 0 "J603" H 9200 3140 50  0000 C CNN
F 1 "SUPERVISOR USB-C" H 9200 3240 50  0000 C CNN
F 2 "Connector_USB:USB_C_Receptacle_USB2.0_16P" H 9200 3650 50  0001 C CNN
F 3 "" H 9200 3650 50  0001 C CNN
	1    9200 3650
	1    0    0    -1  
$EndComp
Wire Wire Line
	8675 3500 8415 3500
Text GLabel 8415 3500 2    42   Output ~ 0
USB_5V_DEBUG
Wire Wire Line
	8675 3800 8415 3800
Text GLabel 8415 3800 2    42   Input ~ 0
GND
Wire Wire Line
	9725 3500 9985 3500
Text GLabel 9985 3500 0    42   BiDi ~ 0
USB_D+
Wire Wire Line
	9725 3600 9985 3600
Text GLabel 9985 3600 0    42   BiDi ~ 0
USB_D-
Wire Wire Line
	9725 3700 9985 3700
Text GLabel 9985 3700 0    42   UnSpc ~ 0
USB_CC1
Wire Wire Line
	9725 3800 9985 3800
Text GLabel 9985 3800 0    42   UnSpc ~ 0
USB_CC2
$Comp
L NetCore_Tetra:SWD_HEADER J604
U 1 1 65000052
P 7800 4400
F 0 "J604" H 7800 3840 50  0000 C CNN
F 1 "SWD / RECOVERY" H 7800 3940 50  0000 C CNN
F 2 "Connector_PinHeader_1x06_P2.54mm_Vertical" H 7800 4400 50  0001 C CNN
F 3 "" H 7800 4400 50  0001 C CNN
	1    7800 4400
	1    0    0    -1  
$EndComp
Wire Wire Line
	7300 4200 7040 4200
Text GLabel 7040 4200 2    42   Output ~ 0
3V3_AON
Wire Wire Line
	7300 4400 7040 4400
Text GLabel 7040 4400 2    42   Input ~ 0
GND
Wire Wire Line
	7300 4600 7040 4600
Text GLabel 7040 4600 2    42   BiDi ~ 0
SUP_SWDIO
Wire Wire Line
	8300 4200 8560 4200
Text GLabel 8560 4200 0    42   Input ~ 0
SUP_SWCLK
Wire Wire Line
	8300 4400 8560 4400
Text GLabel 8560 4400 0    42   Input ~ 0
SUP_RUN_N
Wire Wire Line
	8300 4600 8560 4600
Text GLabel 8560 4600 0    42   Output ~ 0
SUP_UART_TX
Text Notes 5900 5000 0    42   ~ 0
TFT is driven by supervisor SPI, never by Pi SPI0/SXceiver bus.
Text Notes 5900 5062 0    42   ~ 0
Large display remains via Pi HDMI/DSI/USB cable; only local service display is on this board.
Wire Notes Line
	10800 1050 15500 1050
Wire Notes Line
	15500 1050 15500 5300
Wire Notes Line
	15500 5300 10800 5300
Wire Notes Line
	10800 5300 10800 1050
Text Notes 10880 1170 0    70   ~ 0
DUAL FAN CONTROL
$Comp
L NetCore_Tetra:EMC2302 U601
U 1 1 65000053
P 12100 2700
F 0 "U601" H 12100 2040 50  0000 C CNN
F 1 "DUAL PWM FAN CONTROLLER" H 12100 2140 50  0000 C CNN
F 2 "Package_SO:TSSOP-16_4.4x5mm_P0.65mm" H 12100 2700 50  0001 C CNN
F 3 "" H 12100 2700 50  0001 C CNN
	1    12100 2700
	1    0    0    -1  
$EndComp
Wire Wire Line
	11500 2400 11240 2400
Text GLabel 11240 2400 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	11500 2550 11240 2550
Text GLabel 11240 2550 2    42   Input ~ 0
GND
Wire Wire Line
	11500 2700 11240 2700
Text GLabel 11240 2700 2    42   BiDi ~ 0
SYS_SENS_SDA
Wire Wire Line
	11500 2850 11240 2850
Text GLabel 11240 2850 2    42   Input ~ 0
SYS_SENS_SCL
Wire Wire Line
	11500 3000 11240 3000
Text GLabel 11240 3000 2    42   Output ~ 0
FAN_ALERT_N
Wire Wire Line
	12700 2400 12960 2400
Text GLabel 12960 2400 0    42   Output ~ 0
FAN_A_PWM
Wire Wire Line
	12700 2600 12960 2600
Text GLabel 12960 2600 0    42   Input ~ 0
FAN_A_TACH
Wire Wire Line
	12700 2800 12960 2800
Text GLabel 12960 2800 0    42   Output ~ 0
FAN_B_PWM
Wire Wire Line
	12700 3000 12960 3000
Text GLabel 12960 3000 0    42   Input ~ 0
FAN_B_TACH
$Comp
L NetCore_Tetra:FAN_4PIN J605
U 1 1 65000054
P 14300 2200
F 0 "J605" H 14300 1690 50  0000 C CNN
F 1 "NODE A 12V PWM FAN" H 14300 1790 50  0000 C CNN
F 2 "NetCore_Tetra:Fan_4Pin_Molex_KK" H 14300 2200 50  0001 C CNN
F 3 "" H 14300 2200 50  0001 C CNN
	1    14300 2200
	1    0    0    -1  
$EndComp
$Comp
L NetCore_Tetra:FAN_4PIN J606
U 1 1 65000055
P 14300 3700
F 0 "J606" H 14300 3190 50  0000 C CNN
F 1 "NODE B 12V PWM FAN" H 14300 3290 50  0000 C CNN
F 2 "NetCore_Tetra:Fan_4Pin_Molex_KK" H 14300 3700 50  0001 C CNN
F 3 "" H 14300 3700 50  0001 C CNN
	1    14300 3700
	1    0    0    -1  
$EndComp
Wire Wire Line
	13800 2050 13540 2050
Text GLabel 13540 2050 2    42   Input ~ 0
GND
Wire Wire Line
	13800 2150 13540 2150
Text GLabel 13540 2150 2    42   Output ~ 0
12V_FAN
Wire Wire Line
	13800 2250 13540 2250
Text GLabel 13540 2250 2    42   Output ~ 0
FAN_A_TACH
Wire Wire Line
	13800 2350 13540 2350
Text GLabel 13540 2350 2    42   Input ~ 0
FAN_A_PWM
Wire Wire Line
	13800 3550 13540 3550
Text GLabel 13540 3550 2    42   Input ~ 0
GND
Wire Wire Line
	13800 3650 13540 3650
Text GLabel 13540 3650 2    42   Output ~ 0
12V_FAN
Wire Wire Line
	13800 3750 13540 3750
Text GLabel 13540 3750 2    42   Output ~ 0
FAN_B_TACH
Wire Wire Line
	13800 3850 13540 3850
Text GLabel 13540 3850 2    42   Input ~ 0
FAN_B_PWM
Text Notes 11100 4850 0    42   ~ 0
4-wire fan PWM uses open-drain 25 kHz output; tach pull-ups to 3V3_AON.
Text Notes 11100 4912 0    42   ~ 0
Place fan connectors at board edge and keep fan return current away from RF/ADC ground.
Wire Notes Line
	600 5700 5600 5700
Wire Notes Line
	5600 5700 5600 10900
Wire Notes Line
	5600 10900 600 10900
Wire Notes Line
	600 10900 600 5700
Text Notes 680 5820 0    70   ~ 0
PROTECTED DIGITAL INPUTS / OUTPUTS
$Comp
L NetCore_Tetra:OPTO_INPUT_4 U602
U 1 1 65000056
P 1900 7600
F 0 "U602" H 1900 6840 50  0000 C CNN
F 1 "4x 5–24V OPTICAL INPUT" H 1900 6940 50  0000 C CNN
F 2 "NetCore_Tetra:Opto_Input_4ch" H 1900 7600 50  0001 C CNN
F 3 "" H 1900 7600 50  0001 C CNN
	1    1900 7600
	1    0    0    -1  
$EndComp
Wire Wire Line
	1250 7200 990 7200
Text GLabel 990 7200 2    42   BiDi ~ 0
FIELD_IN_TERM_1
Wire Wire Line
	1250 7314 990 7314
Text GLabel 990 7314 2    42   BiDi ~ 0
FIELD_IN_TERM_2
Wire Wire Line
	1250 7429 990 7429
Text GLabel 990 7429 2    42   BiDi ~ 0
FIELD_IN_TERM_3
Wire Wire Line
	1250 7543 990 7543
Text GLabel 990 7543 2    42   BiDi ~ 0
FIELD_IN_TERM_4
Wire Wire Line
	1250 7657 990 7657
Text GLabel 990 7657 2    42   BiDi ~ 0
FIELD_IN_TERM_5
Wire Wire Line
	1250 7771 990 7771
Text GLabel 990 7771 2    42   BiDi ~ 0
FIELD_IN_TERM_6
Wire Wire Line
	1250 7886 990 7886
Text GLabel 990 7886 2    42   BiDi ~ 0
FIELD_IN_TERM_7
Wire Wire Line
	1250 8000 990 8000
Text GLabel 990 8000 2    42   BiDi ~ 0
FIELD_IN_TERM_8
Wire Wire Line
	2550 7200 2810 7200
Text GLabel 2810 7200 0    42   BiDi ~ 0
DIN1
Wire Wire Line
	2550 7360 2810 7360
Text GLabel 2810 7360 0    42   BiDi ~ 0
DIN2
Wire Wire Line
	2550 7520 2810 7520
Text GLabel 2810 7520 0    42   BiDi ~ 0
DIN3
Wire Wire Line
	2550 7680 2810 7680
Text GLabel 2810 7680 0    42   BiDi ~ 0
DIN4
Wire Wire Line
	2550 7840 2810 7840
Text GLabel 2810 7840 0    42   BiDi ~ 0
3V3_AON
Wire Wire Line
	2550 8000 2810 8000
Text GLabel 2810 8000 0    42   BiDi ~ 0
GND
$Comp
L NetCore_Tetra:MOSFET_OUTPUT_4 U603
U 1 1 65000057
P 4100 7600
F 0 "U603" H 4100 6840 50  0000 C CNN
F 1 "4x LOW-SIDE OUTPUT + FLYBACK" H 4100 6940 50  0000 C CNN
F 2 "NetCore_Tetra:MOSFET_Output_4ch" H 4100 7600 50  0001 C CNN
F 3 "" H 4100 7600 50  0001 C CNN
	1    4100 7600
	1    0    0    -1  
$EndComp
Wire Wire Line
	3450 7200 3190 7200
Text GLabel 3190 7200 2    42   BiDi ~ 0
DOUT1_CTRL
Wire Wire Line
	3450 7360 3190 7360
Text GLabel 3190 7360 2    42   BiDi ~ 0
DOUT2_CTRL
Wire Wire Line
	3450 7520 3190 7520
Text GLabel 3190 7520 2    42   BiDi ~ 0
DOUT3_CTRL
Wire Wire Line
	3450 7680 3190 7680
Text GLabel 3190 7680 2    42   BiDi ~ 0
DOUT4_CTRL
Wire Wire Line
	3450 7840 3190 7840
Text GLabel 3190 7840 2    42   BiDi ~ 0
3V3_AON
Wire Wire Line
	3450 8000 3190 8000
Text GLabel 3190 8000 2    42   BiDi ~ 0
GND
Wire Wire Line
	4750 7200 5010 7200
Text GLabel 5010 7200 0    42   BiDi ~ 0
FIELD_OUT1
Wire Wire Line
	4750 7360 5010 7360
Text GLabel 5010 7360 0    42   BiDi ~ 0
FIELD_OUT2
Wire Wire Line
	4750 7520 5010 7520
Text GLabel 5010 7520 0    42   BiDi ~ 0
FIELD_OUT3
Wire Wire Line
	4750 7680 5010 7680
Text GLabel 5010 7680 0    42   BiDi ~ 0
FIELD_OUT4
Wire Wire Line
	4750 7840 5010 7840
Text GLabel 5010 7840 0    42   BiDi ~ 0
FIELD_VEXT
Wire Wire Line
	4750 8000 5010 8000
Text GLabel 5010 8000 0    42   BiDi ~ 0
GND
$Comp
L NetCore_Tetra:TERM_16 J607
U 1 1 65000058
P 2900 9900
F 0 "J607" H 2900 8840 50  0000 C CNN
F 1 "FIELD I/O TERMINAL" H 2900 8940 50  0000 C CNN
F 2 "NetCore_Tetra:Terminal_16_3.5mm" H 2900 9900 50  0001 C CNN
F 3 "" H 2900 9900 50  0001 C CNN
	1    2900 9900
	1    0    0    -1  
$EndComp
Wire Wire Line
	2450 9200 2190 9200
Text GLabel 2190 9200 2    42   BiDi ~ 0
FIELD_IN1+
Wire Wire Line
	2450 9293 2190 9293
Text GLabel 2190 9293 2    42   BiDi ~ 0
FIELD_IN1-
Wire Wire Line
	2450 9387 2190 9387
Text GLabel 2190 9387 2    42   BiDi ~ 0
FIELD_IN2+
Wire Wire Line
	2450 9480 2190 9480
Text GLabel 2190 9480 2    42   BiDi ~ 0
FIELD_IN2-
Wire Wire Line
	2450 9573 2190 9573
Text GLabel 2190 9573 2    42   BiDi ~ 0
FIELD_IN3+
Wire Wire Line
	2450 9667 2190 9667
Text GLabel 2190 9667 2    42   BiDi ~ 0
FIELD_IN3-
Wire Wire Line
	2450 9760 2190 9760
Text GLabel 2190 9760 2    42   BiDi ~ 0
FIELD_IN4+
Wire Wire Line
	2450 9853 2190 9853
Text GLabel 2190 9853 2    42   BiDi ~ 0
FIELD_IN4-
Wire Wire Line
	2450 9947 2190 9947
Text GLabel 2190 9947 2    42   BiDi ~ 0
FIELD_VEXT
Wire Wire Line
	2450 10040 2190 10040
Text GLabel 2190 10040 2    42   BiDi ~ 0
FIELD_GND
Wire Wire Line
	2450 10133 2190 10133
Text GLabel 2190 10133 2    42   BiDi ~ 0
FIELD_OUT1
Wire Wire Line
	2450 10227 2190 10227
Text GLabel 2190 10227 2    42   BiDi ~ 0
FIELD_OUT2
Wire Wire Line
	2450 10320 2190 10320
Text GLabel 2190 10320 2    42   BiDi ~ 0
FIELD_OUT3
Wire Wire Line
	2450 10413 2190 10413
Text GLabel 2190 10413 2    42   BiDi ~ 0
FIELD_OUT4
Wire Wire Line
	2450 10507 2190 10507
Text GLabel 2190 10507 2    42   BiDi ~ 0
FIELD_TAMPER
Wire Wire Line
	2450 10600 2190 10600
Text GLabel 2190 10600 2    42   BiDi ~ 0
FIELD_GND
Text Notes 850 10600 0    40   ~ 0
Inputs: 5–24 V, polarity protection, 2.2 k / 0.5 W sizing to be verified.
Text Notes 850 10660 0    40   ~ 0
Outputs: logic-level 30 V MOSFETs, flyback path to FIELD_VEXT, 1 A design target each.
Text Notes 850 10720 0    40   ~ 0
Keep field returns separate until star point; add TVS and replaceable PTC where cables leave enclosure.
Wire Notes Line
	5900 5700 10300 5700
Wire Notes Line
	10300 5700 10300 10900
Wire Notes Line
	10300 10900 5900 10900
Wire Notes Line
	5900 10900 5900 5700
Text Notes 5980 5820 0    70   ~ 0
RS-485 / ALARM RELAY / LOCAL ALARM
$Comp
L NetCore_Tetra:RS485_XCVR U604
U 1 1 65000059
P 7000 7200
F 0 "U604" H 7000 6590 50  0000 C CNN
F 1 "3V3 RS-485 TRANSCEIVER" H 7000 6690 50  0000 C CNN
F 2 "Package_SO:SOIC-8_3.9x4.9mm_P1.27mm" H 7000 7200 50  0001 C CNN
F 3 "" H 7000 7200 50  0001 C CNN
	1    7000 7200
	1    0    0    -1  
$EndComp
Wire Wire Line
	6450 6950 6190 6950
Text GLabel 6190 6950 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	6450 7075 6190 7075
Text GLabel 6190 7075 2    42   Input ~ 0
GND
Wire Wire Line
	6450 7200 6190 7200
Text GLabel 6190 7200 2    42   Input ~ 0
RS485_TX
Wire Wire Line
	6450 7325 6190 7325
Text GLabel 6190 7325 2    42   Output ~ 0
RS485_RX
Wire Wire Line
	6450 7450 6190 7450
Text GLabel 6190 7450 2    42   Input ~ 0
RS485_DE
Wire Wire Line
	7550 6950 7810 6950
Text GLabel 7810 6950 0    42   BiDi ~ 0
RS485_A
Wire Wire Line
	7550 7450 7810 7450
Text GLabel 7810 7450 0    42   BiDi ~ 0
RS485_B
$Comp
L NetCore_Tetra:TERM_3 J608
U 1 1 6500005A
P 9100 7200
F 0 "J608" H 9100 6790 50  0000 C CNN
F 1 "RS-485 A/B/GND" H 9100 6890 50  0000 C CNN
F 2 "NetCore_Tetra:Terminal_3_3.5mm" H 9100 7200 50  0001 C CNN
F 3 "" H 9100 7200 50  0001 C CNN
	1    9100 7200
	1    0    0    -1  
$EndComp
Wire Wire Line
	8650 7150 8390 7150
Text GLabel 8390 7150 2    42   BiDi ~ 0
RS485_A
Wire Wire Line
	8650 7200 8390 7200
Text GLabel 8390 7200 2    42   BiDi ~ 0
RS485_B
Wire Wire Line
	8650 7250 8390 7250
Text GLabel 8390 7250 2    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:RELAY_SPDT K601
U 1 1 6500005B
P 7000 8800
F 0 "K601" H 7000 8190 50  0000 C CNN
F 1 "DRY ALARM CONTACT" H 7000 8290 50  0000 C CNN
F 2 "Relay_THT:Relay_SPDT_Omron_G5V-1" H 7000 8800 50  0001 C CNN
F 3 "" H 7000 8800 50  0001 C CNN
	1    7000 8800
	1    0    0    -1  
$EndComp
Wire Wire Line
	6450 8550 6190 8550
Text GLabel 6190 8550 2    42   Input ~ 0
12V_BUS
Wire Wire Line
	6450 9050 6190 9050
Text GLabel 6190 9050 2    42   Input ~ 0
RELAY_COIL_LOW
Wire Wire Line
	7550 8550 7810 8550
Text GLabel 7810 8550 0    42   UnSpc ~ 0
ALARM_COM
Wire Wire Line
	7550 8800 7810 8800
Text GLabel 7810 8800 0    42   UnSpc ~ 0
ALARM_NO
Wire Wire Line
	7550 9050 7810 9050
Text GLabel 7810 9050 0    42   UnSpc ~ 0
ALARM_NC
$Comp
L NetCore_Tetra:TERM_3 J609
U 1 1 6500005C
P 9100 8800
F 0 "J609" H 9100 8390 50  0000 C CNN
F 1 "ALARM COM/NO/NC" H 9100 8490 50  0000 C CNN
F 2 "NetCore_Tetra:Terminal_3_3.5mm" H 9100 8800 50  0001 C CNN
F 3 "" H 9100 8800 50  0001 C CNN
	1    9100 8800
	1    0    0    -1  
$EndComp
Wire Wire Line
	8650 8750 8390 8750
Text GLabel 8390 8750 2    42   UnSpc ~ 0
ALARM_COM
Wire Wire Line
	8650 8800 8390 8800
Text GLabel 8390 8800 2    42   UnSpc ~ 0
ALARM_NO
Wire Wire Line
	8650 8850 8390 8850
Text GLabel 8390 8850 2    42   UnSpc ~ 0
ALARM_NC
$Comp
L NetCore_Tetra:BUZZER BZ601
U 1 1 6500005D
P 7000 10000
F 0 "BZ601" H 7000 9590 50  0000 C CNN
F 1 "LOCAL PIEZO ALARM" H 7000 9690 50  0000 C CNN
F 2 "Buzzer_Beeper:Buzzer_12x9.5RM7.6" H 7000 10000 50  0001 C CNN
F 3 "" H 7000 10000 50  0001 C CNN
	1    7000 10000
	1    0    0    -1  
$EndComp
Wire Wire Line
	6575 9950 6315 9950
Text GLabel 6315 9950 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	7425 9950 7685 9950
Text GLabel 7685 9950 0    42   Input ~ 0
BUZZER_LOW
Text Notes 6100 10600 0    40   ~ 0
RS-485 termination/bias are jumper-selectable. Relay provides fail-safe dry contact.
Text Notes 6100 10660 0    40   ~ 0
Piezo can be omitted for silent installations.
Wire Notes Line
	10600 5700 15500 5700
Wire Notes Line
	15500 5700 15500 10900
Wire Notes Line
	15500 10900 10600 10900
Wire Notes Line
	10600 10900 10600 5700
Text Notes 10680 5820 0    70   ~ 0
EXTERNAL PA POWER / RF INHIBIT
$Comp
L NetCore_Tetra:HIGH_SIDE_12V_SWITCH U631
U 1 1 6500005E
P 11600 7400
F 0 "U631" H 11600 6840 50  0000 C CNN
F 1 "A PA 12V HIGH-SIDE SWITCH" H 11600 6940 50  0000 C CNN
F 2 "NetCore_Tetra:HighSide_12V_3A_TBD" H 11600 7400 50  0001 C CNN
F 3 "" H 11600 7400 50  0001 C CNN
	1    11600 7400
	1    0    0    -1  
$EndComp
Wire Wire Line
	11000 7200 10740 7200
Text GLabel 10740 7200 2    42   Input ~ 0
12V_PA_A
Wire Wire Line
	11000 7400 10740 7400
Text GLabel 10740 7400 2    42   Input ~ 0
A_RF_ENABLE
Wire Wire Line
	11000 7600 10740 7600
Text GLabel 10740 7600 2    42   Input ~ 0
GND
Wire Wire Line
	12200 7200 12460 7200
Text GLabel 12460 7200 0    42   Output ~ 0
PA_A_12V_OUT
Wire Wire Line
	12200 7400 12460 7400
Text GLabel 12460 7400 0    42   Output ~ 0
A_PA_FAULT_N
Wire Wire Line
	12200 7600 12460 7600
Text GLabel 12460 7600 0    42   Output ~ 0
PA_A_CURRENT
$Comp
L NetCore_Tetra:TERM_4 J631
U 1 1 6500005F
P 14100 7400
F 0 "J631" H 14100 6940 50  0000 C CNN
F 1 "PA A: 12V/GND/EN/FAULT" H 14100 7040 50  0000 C CNN
F 2 "NetCore_Tetra:Terminal_4_3.5mm" H 14100 7400 50  0001 C CNN
F 3 "" H 14100 7400 50  0001 C CNN
	1    14100 7400
	1    0    0    -1  
$EndComp
Wire Wire Line
	13650 7300 13390 7300
Text GLabel 13390 7300 2    42   Output ~ 0
PA_A_12V_OUT
Wire Wire Line
	13650 7367 13390 7367
Text GLabel 13390 7367 2    42   Input ~ 0
GND
Wire Wire Line
	13650 7433 13390 7433
Text GLabel 13390 7433 2    42   Output ~ 0
A_RF_ENABLE
Wire Wire Line
	13650 7500 13390 7500
Text GLabel 13390 7500 2    42   Input ~ 0
A_PA_FAULT_N
$Comp
L NetCore_Tetra:HIGH_SIDE_12V_SWITCH U911
U 1 1 65000060
P 11600 7400
F 0 "U911" H 11600 6840 50  0000 C CNN
F 1 "B PA 12V HIGH-SIDE SWITCH" H 11600 6940 50  0000 C CNN
F 2 "NetCore_Tetra:HighSide_12V_3A_TBD" H 11600 7400 50  0001 C CNN
F 3 "" H 11600 7400 50  0001 C CNN
	1    11600 7400
	1    0    0    -1  
$EndComp
Wire Wire Line
	11000 7200 10740 7200
Text GLabel 10740 7200 2    42   Input ~ 0
12V_PA_B
Wire Wire Line
	11000 7400 10740 7400
Text GLabel 10740 7400 2    42   Input ~ 0
B_RF_ENABLE
Wire Wire Line
	11000 7600 10740 7600
Text GLabel 10740 7600 2    42   Input ~ 0
GND
Wire Wire Line
	12200 7200 12460 7200
Text GLabel 12460 7200 0    42   Output ~ 0
PA_B_12V_OUT
Wire Wire Line
	12200 7400 12460 7400
Text GLabel 12460 7400 0    42   Output ~ 0
B_PA_FAULT_N
Wire Wire Line
	12200 7600 12460 7600
Text GLabel 12460 7600 0    42   Output ~ 0
PA_B_CURRENT
$Comp
L NetCore_Tetra:TERM_4 J911
U 1 1 65000061
P 14100 7400
F 0 "J911" H 14100 6940 50  0000 C CNN
F 1 "PA B: 12V/GND/EN/FAULT" H 14100 7040 50  0000 C CNN
F 2 "NetCore_Tetra:Terminal_4_3.5mm" H 14100 7400 50  0001 C CNN
F 3 "" H 14100 7400 50  0001 C CNN
	1    14100 7400
	1    0    0    -1  
$EndComp
Wire Wire Line
	13650 7300 13390 7300
Text GLabel 13390 7300 2    42   Output ~ 0
PA_B_12V_OUT
Wire Wire Line
	13650 7367 13390 7367
Text GLabel 13390 7367 2    42   Input ~ 0
GND
Wire Wire Line
	13650 7433 13390 7433
Text GLabel 13390 7433 2    42   Output ~ 0
B_RF_ENABLE
Wire Wire Line
	13650 7500 13390 7500
Text GLabel 13390 7500 2    42   Input ~ 0
B_PA_FAULT_N
Text Notes 10900 10000 0    42   ~ 0
RF INHIBIT is fail-safe at supervisor/PA power level; it does not clamp SXceiver GPIO22 directly.
Text Notes 10900 10062 0    42   ~ 0
External PA rail defaults OFF until supervisor has valid mode, node ID and health state.
Text Notes 10900 10124 0    42   ~ 0
Add RF detector inputs RF_FWD/REF from directional coupler detector outputs to ADS1115.
$EndSCHEMATC
