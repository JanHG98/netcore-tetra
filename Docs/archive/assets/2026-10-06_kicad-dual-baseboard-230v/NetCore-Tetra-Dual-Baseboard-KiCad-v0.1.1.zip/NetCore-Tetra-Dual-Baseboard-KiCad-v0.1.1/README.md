# NetCore-Tetra Dual Baseboard — v0.1.1 Formatkorrektur

**Dieses Update repariert die gemeldeten Legacy-Schaltplan-Ladefehler. Es ist keine elektrische Überarbeitung oder Fertigungsfreigabe.**

## Öffnen

1. KiCad schließen und das ZIP vollständig in einen **neuen Ordner** entpacken. Eigene Änderungen im alten Ordner behalten. Nicht mit schon teilweise konvertierten `.kicad_sch`-Dateien aus v0.1 mischen.
2. Im KiCad-Schaltplan-Editor direkt `NetCore-Tetra-Dual-Baseboard.sch` öffnen. Das ist die Hauptseite mit den fünf Unterseiten. Zum Erstimport nicht die noch leere `.kicad_pro`-Projektvorlage verwenden.
3. Nach erfolgreichem vollständigem Laden speichern. Moderne KiCad-Versionen schreiben das Legacy-Projekt dabei in `.kicad_sch` um. Danach mit dieser modernen Hauptdatei weiterarbeiten.

Die Dateien `NetCore_Tetra.lib`, `sym-lib-table` und `NetCore-Tetra-Dual-Baseboard-cache.lib` müssen im entpackten Projektordner bleiben. Die Cache-Datei enthält alle 49 projektspezifischen Symbole unter den für den Legacy-Import erwarteten Namen.

## Behobene Ursache

Im ursprünglichen Generator wurden Pin-Eigenschaften und Label-Formen verwechselt. Für `Text GLabel` bzw. `Text HLabel` akzeptiert der KiCad-Legacy-Importer die Typen `Input`, `Output`, `BiDi`, `3State`, `UnSpc`.

Die ungültigen Einträge wurden nur an dieser Stelle korrigiert:

| Vorher | Nachher | Anzahl |
|---|---|---:|
| `PowerInput` | `Input` | 109 |
| `PowerOutput` | `Output` | 35 |
| `Passive` | `UnSpc` | 10 |

Das sind **154 Korrekturen**. Netznamen, Leitungen, Pins, Bauteilwerte und Positionen wurden nicht geändert. Die tatsächlichen elektrischen Pin-Typen in der Symbolbibliothek sind ebenfalls unverändert.

| Datei | Korrekturen |
|---|---:|
| `01_POWER_INPUTS.sch` | 32 |
| `02_NODE_A.sch` | 21 |
| `03_NODE_B.sch` | 21 |
| `04_SUPERVISOR_SENSORS.sch` | 31 |
| `05_UI_FANS_IO.sch` | 49 |

Zusätzlich wurde die vorher fehlende Cache-Bibliothek ergänzt. `LABEL_FIXES.json` protokolliert jede geänderte Zeile; `format_fix.patch` zeigt den vollständigen Schaltplan-Diff. Die Revision im Titelblock lautet `0.1.1-format-fix`.

## Tatsächlich geprüfter Umfang

Statische Prüfung der verwendeten Legacy-Datensätze: **6 Schaltplanseiten, 92 Komponenten/Funktionsblöcke, 49 Bibliothekssymbole, 514 globale Labels, 609 elektrische Leitungssegmente.** Alle fünf Unterseiten existieren und werden von der Hauptseite referenziert. Symbolreferenzen sind in der mitgelieferten Bibliothek vorhanden; Bauteilreferenzen und Legacy-IDs sind projektweit eindeutig. Die Cache-Pin-Definitionen stimmen mit der Bibliothek überein. Der Diff bestätigt, dass nur Label-Typen und Titelblock-Revisionen geändert wurden.

**Kein echter KiCad-Ladetest, kein ERC, kein DRC.** In dieser Laufzeitumgebung war KiCad nicht installiert; der Installationsversuch scheiterte am fehlenden Netzwerk-/DNS-Zugriff. `validate_structure.py` ist ein eigener statischer Prüfer für die verwendeten Datensätze, kein Ersatz für den KiCad-Importer. Seine Prüfungen laufen ohne zusätzliche Python-Pakete:

```text
python validate_structure.py
```

Die alten v0.1-Angaben sind in `README_v0.1_original.md` und `VALIDATION_REPORT_v0.1_original.json` als Historie erhalten. Maßgeblich für diese Korrektur ist `VALIDATION_REPORT.json`.

## Unverändert offene Designfragen

Das Projekt enthält weiterhin funktionale Platzhaltersymbole und vorläufige Footprints. Manche gezeichneten Funktionen sind noch keine ausdimensionierten, bestückbaren Schaltungen. Das `.kicad_pcb` bleibt die unveränderte Platzierungsstudie; es ist nicht geroutet und nicht mit dem Schaltplan synchronisiert.

**Nicht fertigen oder an 230 VAC anschließen.** Die Netzspannungsoption ist ein ungeprüfter Entwurfsbereich. Ein funktionsfähiger und sicherer Prototyp erfordert weiterhin Bauteilauswahl, korrekte Datenblatt-Pinouts, vollständige Beschaltung, ERC/DRC und elektrische/mechanische Sicherheitsprüfung. Ein behobener Importfehler ersetzt diese Schritte nicht.

## Formatquellen

KiCad-Legacy-Importer, `sheetLabelNames` und `loadText`:
https://docs.kicad.org/doxygen/sch__io__kicad__legacy_8cpp_source.html

KiCad-Handbuch, „Opening legacy schematics“:
https://docs.kicad.org/9.0/en/eeschema/eeschema.html#opening_legacy_schematics

Cache-Namensabbildung (Doppelpunkt zu Unterstrich):
https://docs.kicad.org/doxygen/sch__screen_8cpp_source.html
