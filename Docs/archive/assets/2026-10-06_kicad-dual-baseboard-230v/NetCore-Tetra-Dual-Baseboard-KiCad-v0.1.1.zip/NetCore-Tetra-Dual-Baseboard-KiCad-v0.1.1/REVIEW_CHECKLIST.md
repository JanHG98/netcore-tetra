# ERC-/DRC-/Bring-up-Checkliste

## Vor dem Schaltplan-Freeze

- [ ] Exaktes Raspberry-Pi-Modell, Leistungsbudget und Orientierung des 40-Pin-Headers bestätigen.
- [ ] SXceiver-Hardwareversion bestätigen; GPIO22/23 gegen ältere GPIO12/13-Belegung prüfen.
- [ ] Exakten Stacking-Steckverbinder und die Z-Höhen festlegen.
- [ ] Jedes funktionale Platzhaltersymbol durch finalen Datenblatt-Pinout und Footprint ersetzen.
- [ ] Enable-Polarität und Trim-Netzwerk des DC/DC-Wandlers bestätigen; 5,10–5,15 V am Pi-Header unter Last einstellen.
- [ ] eFuse-Stromlimit, Softstart und Rückstromverhalten prüfen.
- [ ] I2C-Pull-ups, Multiplexer-Buskapazität und mögliche Backpower-Pfade prüfen.
- [ ] Open-Drain-Polarität für Shutdown/Alert gegen die Pi-Softwarekonfiguration prüfen.
- [ ] Festlegen, ob RF-Inhibit nur softwareseitig wirkt oder zusätzlich die externe PA-Spannung trennt.
- [ ] Watchdog-Zeit erst nach Messung von Boot-, Update- und Recovery-Zeiten festlegen.

## PCB

- [ ] Nach der Konvertierung auf aktuelles KiCad das PCB aus dem Schaltplan aktualisieren.
- [ ] In1 als geschlossene GND-Fläche; keinerlei Netzspannungs-Kupfer in SELV-Bereichen.
- [ ] 12-V-/5-V-Leiterbreiten und Via-Felder für Maximalstrom und Temperaturanstieg berechnen.
- [ ] Kelvin-Leitungen vom Shunt direkt und symmetrisch zum INA226 führen.
- [ ] DC/DC-Schaltknoten, Lüfterströme und TFT-Flanken von SXceiver und RF-ADC-Eingängen fernhalten.
- [ ] SHT45 auf thermischer Insel an der Boardkante; TMP117 am Stack, aber weg von Wandlern.
- [ ] Pi-Port-Überstände und Kabelzugang für USB/Ethernet/HDMI mechanisch prüfen.
- [ ] DRC mit getrennten Netzklassen für Netzspannung, 12 V, 5 V und Signale.

## Netzspannungsbereich — nur bei Bestückung

- [ ] Zertifiziertes AC/DC-Modul mit exakten Zulassungen und Footprint festgelegt.
- [ ] Kriech-/Luftstrecken und Frässlots für Verschmutzungsgrad, Materialgruppe und Überspannungskategorie geprüft.
- [ ] Sicherung, MOV, NTC, CMC und X2-Kondensator mit Modul und Installation koordiniert.
- [ ] PE-/Chassiskonzept geprüft; keine unbeabsichtigte Verbindung zu Logic-GND.
- [ ] Berührungsschutz, Zugentlastung, Finger-Safe-Klemmen und Kennzeichnung umgesetzt.
- [ ] Hochspannungs-, Ableitstrom-, Thermik- und Fehlerfalltests durch qualifiziertes Personal.

## Bring-up

- [ ] Zuerst nur den 12-V-Pfad bestücken; AC- und PA-Zweige DNP lassen.
- [ ] Labornetzteil strombegrenzen; 3V3_AON ohne eingesetzte Pis prüfen.
- [ ] Supervisor, Watchdog und I2C-Mux in Betrieb nehmen; jeden Mux-Kanal einzeln scannen.
- [ ] Node-Zweige unbelastet, mit elektronischer Last, dann mit Pi und zuletzt mit SXceiver testen.
- [ ] USB-C-/Backfeed-Szenarien ausschließen.
- [ ] Geordnetes Herunterfahren und anschließenden eFuse-Power-Cycle pro Node testen.
- [ ] Lüfterausfall, Sensoralarme, RF-Inhibit und Feld-I/O subsystemweise prüfen.
