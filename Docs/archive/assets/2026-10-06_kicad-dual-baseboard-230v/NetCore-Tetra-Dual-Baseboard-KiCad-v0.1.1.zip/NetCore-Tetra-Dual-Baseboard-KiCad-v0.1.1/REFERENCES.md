# Referenzen für den nächsten Design-Pass

- SXceiver / SoapySX: https://github.com/tejeez/sxxcvr
- Raspberry Pi GPIO: https://www.raspberrypi.com/documentation/computers/raspberry-pi.html#gpio
- Raspberry Pi HAT mechanical guidance: https://github.com/raspberrypi/hats
- TI TPS3431 watchdog: https://www.ti.com/product/TPS3431
- TI TCA9548A I2C multiplexer: https://www.ti.com/product/TCA9548A
- TI INA226 current monitor: https://www.ti.com/product/INA226
- Microchip EMC2302 fan controller: https://www.microchip.com/en-us/product/emc2302

Die URLs sind nur Startpunkte. Für Fertigung ausschließlich die zum gewählten Bestellcode passende aktuelle Datenblattrevision verwenden.
