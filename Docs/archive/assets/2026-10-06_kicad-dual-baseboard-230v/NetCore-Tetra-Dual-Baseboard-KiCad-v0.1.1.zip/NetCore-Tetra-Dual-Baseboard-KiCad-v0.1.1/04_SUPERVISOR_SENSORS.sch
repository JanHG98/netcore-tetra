EESchema Schematic File Version 4
LIBS:NetCore_Tetra
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
encoding utf-8
Sheet 5 6
Title "Always-On Supervisor, I2C Multiplexer and Per-Node Sensors"
Date "2026-09-17"
Rev "0.1.1-format-fix"
Comp "NetCore-Tetra / Jan Hoffmeister"
Comment1 "Engineering concept - not released for mains or production"
Comment2 "Dual Pi + dual SXceiver compact baseboard"
Comment3 "Default power path: external 12 VDC"
Comment4 "Run ERC/DRC and component/footprint lock before fabrication"
$EndDescr
Text Notes 650 600 0    100   ~ 0
ALWAYS-ON SUPERVISOR AND SENSOR FABRIC
Wire Notes Line
	600 1050 5200 1050
Wire Notes Line
	5200 1050 5200 10400
Wire Notes Line
	5200 10400 600 10400
Wire Notes Line
	600 10400 600 1050
Text Notes 680 1170 0    70   ~ 0
RP2040 SUPERVISOR / HARDWARE WATCHDOG
$Comp
L NetCore_Tetra:RP2040_SUPERVISOR_MODULE U501
U 1 1 65000036
P 2750 5000
F 0 "U501" H 2750 3640 50  0000 C CNN
F 1 "RP2040 SUPERVISOR MODULE" H 2750 3740 50  0000 C CNN
F 2 "NetCore_Tetra:RP2040_Zero_Provisional" H 2750 5000 50  0001 C CNN
F 3 "" H 2750 5000 50  0001 C CNN
	1    2750 5000
	1    0    0    -1  
$EndComp
Wire Wire Line
	1900 4000 1710 4000
Text GLabel 1710 4000 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	1900 4143 1710 4143
Text GLabel 1710 4143 2    42   Input ~ 0
GND
Wire Wire Line
	1900 4286 1710 4286
Text GLabel 1710 4286 2    42   Input ~ 0
USB_5V_DEBUG
Wire Wire Line
	1900 4429 1710 4429
Text GLabel 1710 4429 2    42   Input ~ 0
SUP_RUN_N
Wire Wire Line
	1900 4571 1710 4571
Text GLabel 1710 4571 2    42   Output ~ 0
SUP_WDI
Wire Wire Line
	1900 4714 1710 4714
Text GLabel 1710 4714 2    42   BiDi ~ 0
SUP_I2C_SDA
Wire Wire Line
	1900 4857 1710 4857
Text GLabel 1710 4857 2    42   Output ~ 0
SUP_I2C_SCL
Wire Wire Line
	1900 5000 1710 5000
Text GLabel 1710 5000 2    42   Input ~ 0
A_UART_TX
Wire Wire Line
	1900 5143 1710 5143
Text GLabel 1710 5143 2    42   Output ~ 0
A_UART_RX
Wire Wire Line
	1900 5286 1710 5286
Text GLabel 1710 5286 2    42   Input ~ 0
B_UART_TX
Wire Wire Line
	1900 5429 1710 5429
Text GLabel 1710 5429 2    42   Output ~ 0
B_UART_RX
Wire Wire Line
	1900 5571 1710 5571
Text GLabel 1710 5571 2    42   Input ~ 0
A_HEARTBEAT
Wire Wire Line
	1900 5714 1710 5714
Text GLabel 1710 5714 2    42   Input ~ 0
B_HEARTBEAT
Wire Wire Line
	1900 5857 1710 5857
Text GLabel 1710 5857 2    42   Input ~ 0
A_PWR_FAULT_N
Wire Wire Line
	1900 6000 1710 6000
Text GLabel 1710 6000 2    42   Input ~ 0
B_PWR_FAULT_N
Wire Wire Line
	3600 4000 3790 4000
Text GLabel 3790 4000 0    42   Output ~ 0
A_SHUTDOWN_CMD
Wire Wire Line
	3600 4091 3790 4091
Text GLabel 3790 4091 0    42   Output ~ 0
B_SHUTDOWN_CMD
Wire Wire Line
	3600 4182 3790 4182
Text GLabel 3790 4182 0    42   Output ~ 0
A_PWR_EN
Wire Wire Line
	3600 4273 3790 4273
Text GLabel 3790 4273 0    42   Output ~ 0
B_PWR_EN
Wire Wire Line
	3600 4364 3790 4364
Text GLabel 3790 4364 0    42   Output ~ 0
A_RF_ENABLE
Wire Wire Line
	3600 4455 3790 4455
Text GLabel 3790 4455 0    42   Output ~ 0
B_RF_ENABLE
Wire Wire Line
	3600 4545 3790 4545
Text GLabel 3790 4545 0    42   Output ~ 0
UI_SPI_SCK
Wire Wire Line
	3600 4636 3790 4636
Text GLabel 3790 4636 0    42   Output ~ 0
UI_SPI_MOSI
Wire Wire Line
	3600 4727 3790 4727
Text GLabel 3790 4727 0    42   Input ~ 0
UI_SPI_MISO
Wire Wire Line
	3600 4818 3790 4818
Text GLabel 3790 4818 0    42   Output ~ 0
TFT_CS
Wire Wire Line
	3600 4909 3790 4909
Text GLabel 3790 4909 0    42   Output ~ 0
TFT_DC
Wire Wire Line
	3600 5000 3790 5000
Text GLabel 3790 5000 0    42   Output ~ 0
TFT_RST
Wire Wire Line
	3600 5091 3790 5091
Text GLabel 3790 5091 0    42   Output ~ 0
TFT_BL
Wire Wire Line
	3600 5182 3790 5182
Text GLabel 3790 5182 0    42   Output ~ 0
TOUCH_CS
Wire Wire Line
	3600 5273 3790 5273
Text GLabel 3790 5273 0    42   Input ~ 0
TOUCH_IRQ
Wire Wire Line
	3600 5364 3790 5364
Text GLabel 3790 5364 0    42   Output ~ 0
RS485_TX
Wire Wire Line
	3600 5455 3790 5455
Text GLabel 3790 5455 0    42   Input ~ 0
RS485_RX
Wire Wire Line
	3600 5545 3790 5545
Text GLabel 3790 5545 0    42   Output ~ 0
RS485_DE
Wire Wire Line
	3600 5636 3790 5636
Text GLabel 3790 5636 0    42   Input ~ 0
IO_INT_N
Wire Wire Line
	3600 5727 3790 5727
Text GLabel 3790 5727 0    42   Output ~ 0
BUZZER_CTRL
Wire Wire Line
	3600 5818 3790 5818
Text GLabel 3790 5818 0    42   Input ~ 0
USER_BTN_N
Wire Wire Line
	3600 5909 3790 5909
Text GLabel 3790 5909 0    42   Input ~ 0
ADC_12V_MON
Wire Wire Line
	3600 6000 3790 6000
Text GLabel 3790 6000 0    42   Input ~ 0
ADC_3V3_MON
$Comp
L NetCore_Tetra:TPS3431_WATCHDOG U502
U 1 1 65000037
P 1200 2300
F 0 "U502" H 1200 1690 50  0000 C CNN
F 1 "INDEPENDENT SUPERVISOR WATCHDOG" H 1200 1790 50  0000 C CNN
F 2 "Package_DFN_QFN:VSON-8-1EP_3x3mm_P0.65mm" H 1200 2300 50  0001 C CNN
F 3 "" H 1200 2300 50  0001 C CNN
	1    1200 2300
	1    0    0    -1  
$EndComp
Wire Wire Line
	650 2050 390 2050
Text GLabel 390 2050 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	650 2217 390 2217
Text GLabel 390 2217 2    42   Input ~ 0
GND
Wire Wire Line
	650 2383 390 2383
Text GLabel 390 2383 2    42   Input ~ 0
SUP_WDI
Wire Wire Line
	650 2550 390 2550
Text GLabel 390 2550 2    42   Input ~ 0
WDG_ENABLE
Wire Wire Line
	1750 2050 2010 2050
Text GLabel 2010 2050 0    42   Output ~ 0
SUP_RUN_N
Wire Wire Line
	1750 2217 2010 2217
Text GLabel 2010 2217 0    42   Output ~ 0
WDG_ENOUT
Wire Wire Line
	1750 2383 2010 2383
Text GLabel 2010 2383 0    42   Input ~ 0
WDG_SET0
Wire Wire Line
	1750 2550 2010 2550
Text GLabel 2010 2550 0    42   Input ~ 0
WDG_SET1
Text Notes 750 3300 0    42   ~ 0
TPS3431: programmable watchdog, active-low open-drain output.
Text Notes 750 3362 0    42   ~ 0
Timeout parts and SET strapping are DNP/TBD until supervisor firmware timing is frozen.
Text Notes 750 3424 0    42   ~ 0
Development bypass jumper must be clearly labelled and normally open.
Wire Notes Line
	5500 1050 8600 1050
Wire Notes Line
	8600 1050 8600 10400
Wire Notes Line
	8600 10400 5500 10400
Wire Notes Line
	5500 10400 5500 1050
Text Notes 5580 1170 0    70   ~ 0
I2C MUX / BUS SEGMENTATION
$Comp
L NetCore_Tetra:TCA9548A U503
U 1 1 65000038
P 7000 5000
F 0 "U503" H 7000 3790 50  0000 C CNN
F 1 "8-CHANNEL I2C MULTIPLEXER" H 7000 3890 50  0000 C CNN
F 2 "Package_SO:TSSOP-24_4.4x7.8mm_P0.65mm" H 7000 5000 50  0001 C CNN
F 3 "" H 7000 5000 50  0001 C CNN
	1    7000 5000
	1    0    0    -1  
$EndComp
Wire Wire Line
	6300 4150 6120 4150
Text GLabel 6120 4150 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	6300 4393 6120 4393
Text GLabel 6120 4393 2    42   Input ~ 0
GND
Wire Wire Line
	6300 4636 6120 4636
Text GLabel 6120 4636 2    42   BiDi ~ 0
SUP_I2C_SDA
Wire Wire Line
	6300 4879 6120 4879
Text GLabel 6120 4879 2    42   Input ~ 0
SUP_I2C_SCL
Wire Wire Line
	6300 5121 6120 5121
Text GLabel 6120 5121 2    42   Input ~ 0
I2C_MUX_RESET_N
Wire Wire Line
	6300 5364 6120 5364
Text GLabel 6120 5364 2    42   Input ~ 0
GND
Wire Wire Line
	6300 5607 6120 5607
Text GLabel 6120 5607 2    42   Input ~ 0
GND
Wire Wire Line
	6300 5850 6120 5850
Text GLabel 6120 5850 2    42   Input ~ 0
GND
Wire Wire Line
	7700 4150 7880 4150
Text GLabel 7880 4150 0    42   BiDi ~ 0
A_SENS_SDA
Wire Wire Line
	7700 4263 7880 4263
Text GLabel 7880 4263 0    42   Output ~ 0
A_SENS_SCL
Wire Wire Line
	7700 4377 7880 4377
Text GLabel 7880 4377 0    42   BiDi ~ 0
B_SENS_SDA
Wire Wire Line
	7700 4490 7880 4490
Text GLabel 7880 4490 0    42   Output ~ 0
B_SENS_SCL
Wire Wire Line
	7700 4603 7880 4603
Text GLabel 7880 4603 0    42   BiDi ~ 0
SYS_SENS_SDA
Wire Wire Line
	7700 4717 7880 4717
Text GLabel 7880 4717 0    42   Output ~ 0
SYS_SENS_SCL
Wire Wire Line
	7700 4830 7880 4830
Text GLabel 7880 4830 0    42   BiDi ~ 0
EXT_I2C_SDA
Wire Wire Line
	7700 4943 7880 4943
Text GLabel 7880 4943 0    42   Output ~ 0
EXT_I2C_SCL
Wire Wire Line
	7700 5057 7880 5057
Text GLabel 7880 5057 0    42   BiDi ~ 0
OLED_SDA
Wire Wire Line
	7700 5170 7880 5170
Text GLabel 7880 5170 0    42   Output ~ 0
OLED_SCL
Wire Wire Line
	7700 5283 7880 5283
Text GLabel 7880 5283 0    42   BiDi ~ 0
SPARE_I2C5_SDA
Wire Wire Line
	7700 5397 7880 5397
Text GLabel 7880 5397 0    42   Output ~ 0
SPARE_I2C5_SCL
Wire Wire Line
	7700 5510 7880 5510
Text GLabel 7880 5510 0    42   BiDi ~ 0
SPARE_I2C6_SDA
Wire Wire Line
	7700 5623 7880 5623
Text GLabel 7880 5623 0    42   Output ~ 0
SPARE_I2C6_SCL
Wire Wire Line
	7700 5737 7880 5737
Text GLabel 7880 5737 0    42   BiDi ~ 0
SPARE_I2C7_SDA
Wire Wire Line
	7700 5850 7880 5850
Text GLabel 7880 5850 0    42   Output ~ 0
SPARE_I2C7_SCL
Text Notes 5800 9300 0    42   ~ 0
CH0 Node A sensors | CH1 Node B sensors | CH2 total/system sensors
Text Notes 5800 9362 0    42   ~ 0
CH3 protected external I2C | CH4 OLED | CH5–7 spare.
Text Notes 5800 9424 0    42   ~ 0
Each channel gets its own pull-ups; this also solves duplicate fixed SHT45 addresses.
Wire Notes Line
	8650 850 15200 850
Wire Notes Line
	15200 850 15200 5100
Wire Notes Line
	15200 5100 8650 5100
Wire Notes Line
	8650 5100 8650 850
Text Notes 8730 970 0    70   ~ 0
NODE A SENSOR CLUSTER
$Comp
L NetCore_Tetra:INA226 U511
U 1 1 65000039
P 9500 2250
F 0 "U511" H 9500 1640 50  0000 C CNN
F 1 "INA226 A 5V RAIL" H 9500 1740 50  0000 C CNN
F 2 "Package_SO:VSSOP-10_3x3mm_P0.5mm" H 9500 2250 50  0001 C CNN
F 3 "" H 9500 2250 50  0001 C CNN
	1    9500 2250
	1    0    0    -1  
$EndComp
Wire Wire Line
	8950 2000 8820 2000
Text GLabel 8820 2000 2    42   Input ~ 0
A_SHUNT_P
Wire Wire Line
	8950 2125 8820 2125
Text GLabel 8820 2125 2    42   Input ~ 0
A_SHUNT_N
Wire Wire Line
	8950 2250 8820 2250
Text GLabel 8820 2250 2    42   Input ~ 0
5V_A
Wire Wire Line
	8950 2375 8820 2375
Text GLabel 8820 2375 2    42   Input ~ 0
GND
Wire Wire Line
	8950 2500 8820 2500
Text GLabel 8820 2500 2    42   Input ~ 0
GND
Wire Wire Line
	10050 2000 10180 2000
Text GLabel 10180 2000 0    42   BiDi ~ 0
A_SENS_SDA
Wire Wire Line
	10050 2125 10180 2125
Text GLabel 10180 2125 0    42   Input ~ 0
A_SENS_SCL
Wire Wire Line
	10050 2250 10180 2250
Text GLabel 10180 2250 0    42   Output ~ 0
A_INA_ALERT_N
Wire Wire Line
	10050 2375 10180 2375
Text GLabel 10180 2375 0    42   Input ~ 0
3V3_AON
Wire Wire Line
	10050 2500 10180 2500
Text GLabel 10180 2500 0    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:TMP117 U512
U 1 1 6500003A
P 11350 1950
F 0 "U512" H 11350 1440 50  0000 C CNN
F 1 "TMP117 A PI/SDR TEMP" H 11350 1540 50  0000 C CNN
F 2 "Package_DFN_QFN:WSON-6_2x2mm_P0.65mm" H 11350 1950 50  0001 C CNN
F 3 "" H 11350 1950 50  0001 C CNN
	1    11350 1950
	1    0    0    -1  
$EndComp
Wire Wire Line
	10850 1800 10720 1800
Text GLabel 10720 1800 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	10850 1950 10720 1950
Text GLabel 10720 1950 2    42   Input ~ 0
GND
Wire Wire Line
	10850 2100 10720 2100
Text GLabel 10720 2100 2    42   Input ~ 0
GND
Wire Wire Line
	11850 1800 11980 1800
Text GLabel 11980 1800 0    42   BiDi ~ 0
A_SENS_SDA
Wire Wire Line
	11850 1950 11980 1950
Text GLabel 11980 1950 0    42   Input ~ 0
A_SENS_SCL
Wire Wire Line
	11850 2100 11980 2100
Text GLabel 11980 2100 0    42   Output ~ 0
A_TEMP_ALERT_N
$Comp
L NetCore_Tetra:SHT45 U513
U 1 1 6500003B
P 11350 3200
F 0 "U513" H 11350 2740 50  0000 C CNN
F 1 "SHT45 A AMBIENT" H 11350 2840 50  0000 C CNN
F 2 "NetCore_Tetra:SHT45_Thermal_Island" H 11350 3200 50  0001 C CNN
F 3 "" H 11350 3200 50  0001 C CNN
	1    11350 3200
	1    0    0    -1  
$EndComp
Wire Wire Line
	10850 3100 10720 3100
Text GLabel 10720 3100 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	10850 3300 10720 3300
Text GLabel 10720 3300 2    42   Input ~ 0
GND
Wire Wire Line
	11850 3100 11980 3100
Text GLabel 11980 3100 0    42   BiDi ~ 0
A_SENS_SDA
Wire Wire Line
	11850 3300 11980 3300
Text GLabel 11980 3300 0    42   Input ~ 0
A_SENS_SCL
$Comp
L NetCore_Tetra:ADS1115 U514
U 1 1 6500003C
P 13200 2100
F 0 "U514" H 13200 1440 50  0000 C CNN
F 1 "ADS1115 A RF/ANALOG" H 13200 1540 50  0000 C CNN
F 2 "Package_SO:VSSOP-10_3x3mm_P0.5mm" H 13200 2100 50  0001 C CNN
F 3 "" H 13200 2100 50  0001 C CNN
	1    13200 2100
	1    0    0    -1  
$EndComp
Wire Wire Line
	12600 1800 12470 1800
Text GLabel 12470 1800 2    42   Input ~ 0
RF_FWD_A
Wire Wire Line
	12600 1950 12470 1950
Text GLabel 12470 1950 2    42   Input ~ 0
RF_REF_A
Wire Wire Line
	12600 2100 12470 2100
Text GLabel 12470 2100 2    42   Input ~ 0
SDR_NTC_A
Wire Wire Line
	12600 2250 12470 2250
Text GLabel 12470 2250 2    42   Input ~ 0
EXT_ADC_A
Wire Wire Line
	12600 2400 12470 2400
Text GLabel 12470 2400 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	13800 1800 13930 1800
Text GLabel 13930 1800 0    42   BiDi ~ 0
A_SENS_SDA
Wire Wire Line
	13800 1950 13930 1950
Text GLabel 13930 1950 0    42   Input ~ 0
A_SENS_SCL
Wire Wire Line
	13800 2100 13930 2100
Text GLabel 13930 2100 0    42   Output ~ 0
A_ADC_ALERT_N
Wire Wire Line
	13800 2250 13930 2250
Text GLabel 13930 2250 0    42   Input ~ 0
3V3_AON
Wire Wire Line
	13800 2400 13930 2400
Text GLabel 13930 2400 0    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:MCP23017 U515
U 1 1 6500003D
P 13300 3900
F 0 "U515" H 13300 2890 50  0000 C CNN
F 1 "MCP23017 A MODE/LED/IO" H 13300 2990 50  0000 C CNN
F 2 "Package_SO:SSOP-28_5.3x10.2mm_P0.65mm" H 13300 3900 50  0001 C CNN
F 3 "" H 13300 3900 50  0001 C CNN
	1    13300 3900
	1    0    0    -1  
$EndComp
Wire Wire Line
	12600 3250 12480 3250
Text GLabel 12480 3250 2    42   BiDi ~ 0
A_SENS_SDA
Wire Wire Line
	12600 3394 12480 3394
Text GLabel 12480 3394 2    42   Input ~ 0
A_SENS_SCL
Wire Wire Line
	12600 3539 12480 3539
Text GLabel 12480 3539 2    42   Input ~ 0
IO_RESET_N
Wire Wire Line
	12600 3683 12480 3683
Text GLabel 12480 3683 2    42   Input ~ 0
GND
Wire Wire Line
	12600 3828 12480 3828
Text GLabel 12480 3828 2    42   Input ~ 0
GND
Wire Wire Line
	12600 3972 12480 3972
Text GLabel 12480 3972 2    42   Input ~ 0
GND
Wire Wire Line
	12600 4117 12480 4117
Text GLabel 12480 4117 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	12600 4261 12480 4261
Text GLabel 12480 4261 2    42   Input ~ 0
GND
Wire Wire Line
	12600 4406 12480 4406
Text GLabel 12480 4406 2    42   Output ~ 0
A_IO_INTA
Wire Wire Line
	12600 4550 12480 4550
Text GLabel 12480 4550 2    42   Output ~ 0
A_IO_INTB
Wire Wire Line
	14000 3250 14120 3250
Text GLabel 14120 3250 0    42   BiDi ~ 0
A_MODE0
Wire Wire Line
	14000 3337 14120 3337
Text GLabel 14120 3337 0    42   BiDi ~ 0
A_MODE1
Wire Wire Line
	14000 3423 14120 3423
Text GLabel 14120 3423 0    42   BiDi ~ 0
A_RF_INHIBIT
Wire Wire Line
	14000 3510 14120 3510
Text GLabel 14120 3510 0    42   BiDi ~ 0
A_CONFIG_LOCK
Wire Wire Line
	14000 3597 14120 3597
Text GLabel 14120 3597 0    42   BiDi ~ 0
A_ID0
Wire Wire Line
	14000 3683 14120 3683
Text GLabel 14120 3683 0    42   BiDi ~ 0
A_ID1
Wire Wire Line
	14000 3770 14120 3770
Text GLabel 14120 3770 0    42   BiDi ~ 0
A_ID2
Wire Wire Line
	14000 3857 14120 3857
Text GLabel 14120 3857 0    42   BiDi ~ 0
A_ID3
Wire Wire Line
	14000 3943 14120 3943
Text GLabel 14120 3943 0    42   BiDi ~ 0
A_LED_PWR
Wire Wire Line
	14000 4030 14120 4030
Text GLabel 14120 4030 0    42   BiDi ~ 0
A_LED_RF
Wire Wire Line
	14000 4117 14120 4117
Text GLabel 14120 4117 0    42   BiDi ~ 0
A_LED_FAULT
Wire Wire Line
	14000 4203 14120 4203
Text GLabel 14120 4203 0    42   BiDi ~ 0
A_LED_SERVICE
Wire Wire Line
	14000 4290 14120 4290
Text GLabel 14120 4290 0    42   BiDi ~ 0
A_BTN_PWR
Wire Wire Line
	14000 4377 14120 4377
Text GLabel 14120 4377 0    42   BiDi ~ 0
A_BTN_RESET
Wire Wire Line
	14000 4463 14120 4463
Text GLabel 14120 4463 0    42   BiDi ~ 0
A_PA_FAULT_N
Wire Wire Line
	14000 4550 14120 4550
Text GLabel 14120 4550 0    42   BiDi ~ 0
A_SPARE_IO
Text Notes 9000 4800 0    40   ~ 0
SHT45 at board edge on thermal island/cut-outs. TMP117 close to stack but away from DC/DC.
Text Notes 9000 4860 0    40   ~ 0
ADS1115 inputs get RC filters, 3.3 V clamps and selectable dividers. RF FWD/REF expects external detector outputs, not raw RF.
Wire Notes Line
	8650 5650 15200 5650
Wire Notes Line
	15200 5650 15200 9900
Wire Notes Line
	15200 9900 8650 9900
Wire Notes Line
	8650 9900 8650 5650
Text Notes 8730 5770 0    70   ~ 0
NODE B SENSOR CLUSTER
$Comp
L NetCore_Tetra:INA226 U521
U 1 1 6500003E
P 9500 7050
F 0 "U521" H 9500 6440 50  0000 C CNN
F 1 "INA226 B 5V RAIL" H 9500 6540 50  0000 C CNN
F 2 "Package_SO:VSSOP-10_3x3mm_P0.5mm" H 9500 7050 50  0001 C CNN
F 3 "" H 9500 7050 50  0001 C CNN
	1    9500 7050
	1    0    0    -1  
$EndComp
Wire Wire Line
	8950 6800 8820 6800
Text GLabel 8820 6800 2    42   Input ~ 0
B_SHUNT_P
Wire Wire Line
	8950 6925 8820 6925
Text GLabel 8820 6925 2    42   Input ~ 0
B_SHUNT_N
Wire Wire Line
	8950 7050 8820 7050
Text GLabel 8820 7050 2    42   Input ~ 0
5V_B
Wire Wire Line
	8950 7175 8820 7175
Text GLabel 8820 7175 2    42   Input ~ 0
GND
Wire Wire Line
	8950 7300 8820 7300
Text GLabel 8820 7300 2    42   Input ~ 0
GND
Wire Wire Line
	10050 6800 10180 6800
Text GLabel 10180 6800 0    42   BiDi ~ 0
B_SENS_SDA
Wire Wire Line
	10050 6925 10180 6925
Text GLabel 10180 6925 0    42   Input ~ 0
B_SENS_SCL
Wire Wire Line
	10050 7050 10180 7050
Text GLabel 10180 7050 0    42   Output ~ 0
B_INA_ALERT_N
Wire Wire Line
	10050 7175 10180 7175
Text GLabel 10180 7175 0    42   Input ~ 0
3V3_AON
Wire Wire Line
	10050 7300 10180 7300
Text GLabel 10180 7300 0    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:TMP117 U522
U 1 1 6500003F
P 11350 6750
F 0 "U522" H 11350 6240 50  0000 C CNN
F 1 "TMP117 B PI/SDR TEMP" H 11350 6340 50  0000 C CNN
F 2 "Package_DFN_QFN:WSON-6_2x2mm_P0.65mm" H 11350 6750 50  0001 C CNN
F 3 "" H 11350 6750 50  0001 C CNN
	1    11350 6750
	1    0    0    -1  
$EndComp
Wire Wire Line
	10850 6600 10720 6600
Text GLabel 10720 6600 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	10850 6750 10720 6750
Text GLabel 10720 6750 2    42   Input ~ 0
GND
Wire Wire Line
	10850 6900 10720 6900
Text GLabel 10720 6900 2    42   Input ~ 0
GND
Wire Wire Line
	11850 6600 11980 6600
Text GLabel 11980 6600 0    42   BiDi ~ 0
B_SENS_SDA
Wire Wire Line
	11850 6750 11980 6750
Text GLabel 11980 6750 0    42   Input ~ 0
B_SENS_SCL
Wire Wire Line
	11850 6900 11980 6900
Text GLabel 11980 6900 0    42   Output ~ 0
B_TEMP_ALERT_N
$Comp
L NetCore_Tetra:SHT45 U523
U 1 1 65000040
P 11350 8000
F 0 "U523" H 11350 7540 50  0000 C CNN
F 1 "SHT45 B AMBIENT" H 11350 7640 50  0000 C CNN
F 2 "NetCore_Tetra:SHT45_Thermal_Island" H 11350 8000 50  0001 C CNN
F 3 "" H 11350 8000 50  0001 C CNN
	1    11350 8000
	1    0    0    -1  
$EndComp
Wire Wire Line
	10850 7900 10720 7900
Text GLabel 10720 7900 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	10850 8100 10720 8100
Text GLabel 10720 8100 2    42   Input ~ 0
GND
Wire Wire Line
	11850 7900 11980 7900
Text GLabel 11980 7900 0    42   BiDi ~ 0
B_SENS_SDA
Wire Wire Line
	11850 8100 11980 8100
Text GLabel 11980 8100 0    42   Input ~ 0
B_SENS_SCL
$Comp
L NetCore_Tetra:ADS1115 U524
U 1 1 65000041
P 13200 6900
F 0 "U524" H 13200 6240 50  0000 C CNN
F 1 "ADS1115 B RF/ANALOG" H 13200 6340 50  0000 C CNN
F 2 "Package_SO:VSSOP-10_3x3mm_P0.5mm" H 13200 6900 50  0001 C CNN
F 3 "" H 13200 6900 50  0001 C CNN
	1    13200 6900
	1    0    0    -1  
$EndComp
Wire Wire Line
	12600 6600 12470 6600
Text GLabel 12470 6600 2    42   Input ~ 0
RF_FWD_B
Wire Wire Line
	12600 6750 12470 6750
Text GLabel 12470 6750 2    42   Input ~ 0
RF_REF_B
Wire Wire Line
	12600 6900 12470 6900
Text GLabel 12470 6900 2    42   Input ~ 0
SDR_NTC_B
Wire Wire Line
	12600 7050 12470 7050
Text GLabel 12470 7050 2    42   Input ~ 0
EXT_ADC_B
Wire Wire Line
	12600 7200 12470 7200
Text GLabel 12470 7200 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	13800 6600 13930 6600
Text GLabel 13930 6600 0    42   BiDi ~ 0
B_SENS_SDA
Wire Wire Line
	13800 6750 13930 6750
Text GLabel 13930 6750 0    42   Input ~ 0
B_SENS_SCL
Wire Wire Line
	13800 6900 13930 6900
Text GLabel 13930 6900 0    42   Output ~ 0
B_ADC_ALERT_N
Wire Wire Line
	13800 7050 13930 7050
Text GLabel 13930 7050 0    42   Input ~ 0
3V3_AON
Wire Wire Line
	13800 7200 13930 7200
Text GLabel 13930 7200 0    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:MCP23017 U525
U 1 1 65000042
P 13300 8700
F 0 "U525" H 13300 7690 50  0000 C CNN
F 1 "MCP23017 B MODE/LED/IO" H 13300 7790 50  0000 C CNN
F 2 "Package_SO:SSOP-28_5.3x10.2mm_P0.65mm" H 13300 8700 50  0001 C CNN
F 3 "" H 13300 8700 50  0001 C CNN
	1    13300 8700
	1    0    0    -1  
$EndComp
Wire Wire Line
	12600 8050 12480 8050
Text GLabel 12480 8050 2    42   BiDi ~ 0
B_SENS_SDA
Wire Wire Line
	12600 8194 12480 8194
Text GLabel 12480 8194 2    42   Input ~ 0
B_SENS_SCL
Wire Wire Line
	12600 8339 12480 8339
Text GLabel 12480 8339 2    42   Input ~ 0
IO_RESET_N
Wire Wire Line
	12600 8483 12480 8483
Text GLabel 12480 8483 2    42   Input ~ 0
GND
Wire Wire Line
	12600 8628 12480 8628
Text GLabel 12480 8628 2    42   Input ~ 0
GND
Wire Wire Line
	12600 8772 12480 8772
Text GLabel 12480 8772 2    42   Input ~ 0
GND
Wire Wire Line
	12600 8917 12480 8917
Text GLabel 12480 8917 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	12600 9061 12480 9061
Text GLabel 12480 9061 2    42   Input ~ 0
GND
Wire Wire Line
	12600 9206 12480 9206
Text GLabel 12480 9206 2    42   Output ~ 0
B_IO_INTA
Wire Wire Line
	12600 9350 12480 9350
Text GLabel 12480 9350 2    42   Output ~ 0
B_IO_INTB
Wire Wire Line
	14000 8050 14120 8050
Text GLabel 14120 8050 0    42   BiDi ~ 0
B_MODE0
Wire Wire Line
	14000 8137 14120 8137
Text GLabel 14120 8137 0    42   BiDi ~ 0
B_MODE1
Wire Wire Line
	14000 8223 14120 8223
Text GLabel 14120 8223 0    42   BiDi ~ 0
B_RF_INHIBIT
Wire Wire Line
	14000 8310 14120 8310
Text GLabel 14120 8310 0    42   BiDi ~ 0
B_CONFIG_LOCK
Wire Wire Line
	14000 8397 14120 8397
Text GLabel 14120 8397 0    42   BiDi ~ 0
B_ID0
Wire Wire Line
	14000 8483 14120 8483
Text GLabel 14120 8483 0    42   BiDi ~ 0
B_ID1
Wire Wire Line
	14000 8570 14120 8570
Text GLabel 14120 8570 0    42   BiDi ~ 0
B_ID2
Wire Wire Line
	14000 8657 14120 8657
Text GLabel 14120 8657 0    42   BiDi ~ 0
B_ID3
Wire Wire Line
	14000 8743 14120 8743
Text GLabel 14120 8743 0    42   BiDi ~ 0
B_LED_PWR
Wire Wire Line
	14000 8830 14120 8830
Text GLabel 14120 8830 0    42   BiDi ~ 0
B_LED_RF
Wire Wire Line
	14000 8917 14120 8917
Text GLabel 14120 8917 0    42   BiDi ~ 0
B_LED_FAULT
Wire Wire Line
	14000 9003 14120 9003
Text GLabel 14120 9003 0    42   BiDi ~ 0
B_LED_SERVICE
Wire Wire Line
	14000 9090 14120 9090
Text GLabel 14120 9090 0    42   BiDi ~ 0
B_BTN_PWR
Wire Wire Line
	14000 9177 14120 9177
Text GLabel 14120 9177 0    42   BiDi ~ 0
B_BTN_RESET
Wire Wire Line
	14000 9263 14120 9263
Text GLabel 14120 9263 0    42   BiDi ~ 0
B_PA_FAULT_N
Wire Wire Line
	14000 9350 14120 9350
Text GLabel 14120 9350 0    42   BiDi ~ 0
B_SPARE_IO
Text Notes 9000 9600 0    40   ~ 0
SHT45 at board edge on thermal island/cut-outs. TMP117 close to stack but away from DC/DC.
Text Notes 9000 9660 0    40   ~ 0
ADS1115 inputs get RC filters, 3.3 V clamps and selectable dividers. RF FWD/REF expects external detector outputs, not raw RF.
Wire Notes Line
	5500 10100 15500 10100
Wire Notes Line
	15500 10100 15500 11550
Wire Notes Line
	15500 11550 5500 11550
Wire Notes Line
	5500 11550 5500 10100
Text Notes 5580 10220 0    70   ~ 0
SYSTEM / TOTAL-BUS SENSOR CLUSTER
$Comp
L NetCore_Tetra:INA226 U531
U 1 1 65000043
P 7200 10850
F 0 "U531" H 7200 10240 50  0000 C CNN
F 1 "INA226 TOTAL 12V BUS" H 7200 10340 50  0000 C CNN
F 2 "Package_SO:VSSOP-10_3x3mm_P0.5mm" H 7200 10850 50  0001 C CNN
F 3 "" H 7200 10850 50  0001 C CNN
	1    7200 10850
	1    0    0    -1  
$EndComp
Wire Wire Line
	6650 10600 6530 10600
Text GLabel 6530 10600 2    42   Input ~ 0
TOTAL_SHUNT_P
Wire Wire Line
	6650 10725 6530 10725
Text GLabel 6530 10725 2    42   Input ~ 0
TOTAL_SHUNT_N
Wire Wire Line
	6650 10850 6530 10850
Text GLabel 6530 10850 2    42   Input ~ 0
12V_BUS
Wire Wire Line
	6650 10975 6530 10975
Text GLabel 6530 10975 2    42   Input ~ 0
GND
Wire Wire Line
	6650 11100 6530 11100
Text GLabel 6530 11100 2    42   Input ~ 0
GND
Wire Wire Line
	7750 10600 7870 10600
Text GLabel 7870 10600 0    42   BiDi ~ 0
SYS_SENS_SDA
Wire Wire Line
	7750 10725 7870 10725
Text GLabel 7870 10725 0    42   Input ~ 0
SYS_SENS_SCL
Wire Wire Line
	7750 10850 7870 10850
Text GLabel 7870 10850 0    42   Output ~ 0
TOTAL_INA_ALERT_N
Wire Wire Line
	7750 10975 7870 10975
Text GLabel 7870 10975 0    42   Input ~ 0
3V3_AON
Wire Wire Line
	7750 11100 7870 11100
Text GLabel 7870 11100 0    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:TMP117 U532
U 1 1 65000044
P 11100 10850
F 0 "U532" H 11100 10340 50  0000 C CNN
F 1 "TMP117 BOARD TEMPERATURE" H 11100 10440 50  0000 C CNN
F 2 "Package_DFN_QFN:WSON-6_2x2mm_P0.65mm" H 11100 10850 50  0001 C CNN
F 3 "" H 11100 10850 50  0001 C CNN
	1    11100 10850
	1    0    0    -1  
$EndComp
Wire Wire Line
	10600 10700 10480 10700
Text GLabel 10480 10700 2    42   Input ~ 0
3V3_AON
Wire Wire Line
	10600 10850 10480 10850
Text GLabel 10480 10850 2    42   Input ~ 0
GND
Wire Wire Line
	10600 11000 10480 11000
Text GLabel 10480 11000 2    42   Input ~ 0
GND
Wire Wire Line
	11600 10700 11720 10700
Text GLabel 11720 10700 0    42   BiDi ~ 0
SYS_SENS_SDA
Wire Wire Line
	11600 10850 11720 10850
Text GLabel 11720 10850 0    42   Input ~ 0
SYS_SENS_SCL
Wire Wire Line
	11600 11000 11720 11000
Text GLabel 11720 11000 0    42   Output ~ 0
BOARD_TEMP_ALERT_N
Text Notes 5700 11420 0    40   ~ 0
CH2 also carries 12 V / 3.3 V divider monitors to supervisor ADC. Node A/B may reuse fixed sensor addresses because the mux isolates them.
$EndSCHEMATC
