EESchema Schematic File Version 4
LIBS:NetCore_Tetra
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
encoding utf-8
Sheet 4 6
Title "Node B: Raspberry Pi 40-pin to SXceiver Pass-through and GPIO Breakout"
Date "2026-09-17"
Rev "0.1.1-format-fix"
Comp "NetCore-Tetra / Jan Hoffmeister"
Comment1 "Engineering concept - not released for mains or production"
Comment2 "Dual Pi + dual SXceiver compact baseboard"
Comment3 "Default power path: external 12 VDC"
Comment4 "Run ERC/DRC and component/footprint lock before fabrication"
$EndDescr
Text Notes 650 600 0    100   ~ 0
NODE B — PI + SXCEIVER STACK AND SAFE GPIO TAPS
Wire Notes Line
	600 1050 6500 1050
Wire Notes Line
	6500 1050 6500 10400
Wire Notes Line
	6500 10400 600 10400
Wire Notes Line
	600 10400 600 1050
Text Notes 680 1170 0    70   ~ 0
40-PIN STACK B
Text Notes 680 1280 0    45   ~ 0
Single mechanical pass-through connector: Pi below, interposer board, SXceiver above.
$Comp
L NetCore_Tetra:RPI_SX_STACK_2X20 J401
U 1 1 65000029
P 3000 4800
F 0 "J401" H 3000 3390 50  0000 C CNN
F 1 "PI_B / SX_B PASS-THROUGH" H 3000 3490 50  0000 C CNN
F 2 "NetCore_Tetra:RPi_SX_Stack_2x20_Provisional" H 3000 4800 50  0001 C CNN
F 3 "" H 3000 4800 50  0001 C CNN
	1    3000 4800
	1    0    0    -1  
$EndComp
Wire Wire Line
	2300 3750 1970 3750
Text GLabel 1970 3750 2    36   Output ~ 0
B_PI_3V3
Wire Wire Line
	3700 3750 4030 3750
Text GLabel 4030 3750 0    36   Input ~ 0
5V_B
Wire Wire Line
	2300 3861 1970 3861
Text Label 1970 3861 2    36   ~ 0
B_GPIO2_SDA1
Wire Wire Line
	3700 3861 4030 3861
Text GLabel 4030 3861 0    36   Input ~ 0
5V_B
Wire Wire Line
	2300 3971 1970 3971
Text Label 1970 3971 2    36   ~ 0
B_GPIO3_SCL1
Wire Wire Line
	3700 3971 4030 3971
Text GLabel 4030 3971 0    36   Input ~ 0
GND
Wire Wire Line
	2300 4082 1970 4082
Text Label 1970 4082 2    36   ~ 0
B_GPIO4
Wire Wire Line
	3700 4082 4030 4082
Text Label 4030 4082 0    36   ~ 0
B_GPIO14_TXD
Wire Wire Line
	2300 4192 1970 4192
Text GLabel 1970 4192 2    36   Input ~ 0
GND
Wire Wire Line
	3700 4192 4030 4192
Text Label 4030 4192 0    36   ~ 0
B_GPIO15_RXD
Wire Wire Line
	2300 4303 1970 4303
Text Label 1970 4303 2    36   ~ 0
B_GPIO17
Wire Wire Line
	3700 4303 4030 4303
Text Label 4030 4303 0    36   ~ 0
B_GPIO18_PCM_CLK
Wire Wire Line
	2300 4413 1970 4413
Text Label 1970 4413 2    36   ~ 0
B_GPIO27
Wire Wire Line
	3700 4413 4030 4413
Text GLabel 4030 4413 0    36   Input ~ 0
GND
Wire Wire Line
	2300 4524 1970 4524
Text Label 1970 4524 2    36   ~ 0
B_GPIO22_SX_TX
Wire Wire Line
	3700 4524 4030 4524
Text Label 4030 4524 0    36   ~ 0
B_GPIO23_SX_RX
Wire Wire Line
	2300 4634 1970 4634
Text GLabel 1970 4634 2    36   Output ~ 0
B_PI_3V3
Wire Wire Line
	3700 4634 4030 4634
Text Label 4030 4634 0    36   ~ 0
B_GPIO24
Wire Wire Line
	2300 4745 1970 4745
Text Label 1970 4745 2    36   ~ 0
B_GPIO10_MOSI
Wire Wire Line
	3700 4745 4030 4745
Text GLabel 4030 4745 0    36   Input ~ 0
GND
Wire Wire Line
	2300 4855 1970 4855
Text Label 1970 4855 2    36   ~ 0
B_GPIO9_MISO
Wire Wire Line
	3700 4855 4030 4855
Text Label 4030 4855 0    36   ~ 0
B_GPIO25
Wire Wire Line
	2300 4966 1970 4966
Text Label 1970 4966 2    36   ~ 0
B_GPIO11_SCLK
Wire Wire Line
	3700 4966 4030 4966
Text Label 4030 4966 0    36   ~ 0
B_GPIO8_CE0
Wire Wire Line
	2300 5076 1970 5076
Text GLabel 1970 5076 2    36   Input ~ 0
GND
Wire Wire Line
	3700 5076 4030 5076
Text Label 4030 5076 0    36   ~ 0
B_GPIO7_CE1
Wire Wire Line
	2300 5187 1970 5187
Text Label 1970 5187 2    36   ~ 0
B_GPIO0_ID_SD
Wire Wire Line
	3700 5187 4030 5187
Text Label 4030 5187 0    36   ~ 0
B_GPIO1_ID_SC
Wire Wire Line
	2300 5297 1970 5297
Text Label 1970 5297 2    36   ~ 0
B_GPIO5_SX_RESET
Wire Wire Line
	3700 5297 4030 5297
Text GLabel 4030 5297 0    36   Input ~ 0
GND
Wire Wire Line
	2300 5408 1970 5408
Text Label 1970 5408 2    36   ~ 0
B_GPIO6
Wire Wire Line
	3700 5408 4030 5408
Text Label 4030 5408 0    36   ~ 0
B_GPIO12_LEGACY_TX
Wire Wire Line
	2300 5518 1970 5518
Text Label 1970 5518 2    36   ~ 0
B_GPIO13_LEGACY_RX
Wire Wire Line
	3700 5518 4030 5518
Text GLabel 4030 5518 0    36   Input ~ 0
GND
Wire Wire Line
	2300 5629 1970 5629
Text Label 1970 5629 2    36   ~ 0
B_GPIO19_PCM_FS
Wire Wire Line
	3700 5629 4030 5629
Text Label 4030 5629 0    36   ~ 0
B_GPIO16
Wire Wire Line
	2300 5739 1970 5739
Text Label 1970 5739 2    36   ~ 0
B_GPIO26
Wire Wire Line
	3700 5739 4030 5739
Text Label 4030 5739 0    36   ~ 0
B_GPIO20_PCM_DIN
Wire Wire Line
	2300 5850 1970 5850
Text GLabel 1970 5850 2    36   Input ~ 0
GND
Wire Wire Line
	3700 5850 4030 5850
Text Label 4030 5850 0    36   ~ 0
B_GPIO21_PCM_DOUT
Text Notes 750 8500 0    65   ~ 0
SXceiver-reserved / do not load
Text Notes 750 8650 0    44   ~ 0
GPIO5 reset; GPIO8/9/10/11 SPI0; GPIO18/19/20/21 I2S/PCM; GPIO22/23 TX/RX control.
Text Notes 750 8714 0    44   ~ 0
GPIO0/1 are HAT EEPROM. GPIO12/13 only via DNP compatibility links.
Text Notes 750 9300 0    44   ~ 0
All 5 V and GND header pins get wide copper / via arrays. Place 100 nF + 47 uF near stack.
Text Notes 750 9364 0    44   ~ 0
The pass-through itself does not power-limit the SXceiver separately from the Pi.
Wire Notes Line
	7000 1050 10100 1050
Wire Notes Line
	10100 1050 10100 3800
Wire Notes Line
	10100 3800 7000 3800
Wire Notes Line
	7000 3800 7000 1050
Text Notes 7080 1170 0    70   ~ 0
PI-LOCAL I2C / UART / SERVICE
$Comp
L NetCore_Tetra:TERM_4 J402
U 1 1 6500002A
P 7600 1900
F 0 "J402" H 7600 1440 50  0000 C CNN
F 1 "PI_B I2C" H 7600 1540 50  0000 C CNN
F 2 "NetCore_Tetra:JST_SH_4" H 7600 1900 50  0001 C CNN
F 3 "" H 7600 1900 50  0001 C CNN
	1    7600 1900
	1    0    0    -1  
$EndComp
Wire Wire Line
	7150 1800 6890 1800
Text GLabel 6890 1800 2    42   Output ~ 0
B_PI_3V3
Wire Wire Line
	7150 1867 6890 1867
Text GLabel 6890 1867 2    42   Input ~ 0
GND
Wire Wire Line
	7150 1933 6890 1933
Text Label 6890 1933 2    42   ~ 0
B_GPIO2_SDA1
Wire Wire Line
	7150 2000 6890 2000
Text Label 6890 2000 2    42   ~ 0
B_GPIO3_SCL1
Text Notes 7200 2750 0    42   ~ 0
Pi GPIO2/3 already have board pull-ups.
Text Notes 7200 2812 0    42   ~ 0
Optional 4.7 k pull-ups are DNP. Keep cable short or use an I2C buffer.
$Comp
L NetCore_Tetra:TERM_4 J403
U 1 1 6500002B
P 9200 1900
F 0 "J403" H 9200 1440 50  0000 C CNN
F 1 "PI_B UART/SERVICE" H 9200 1540 50  0000 C CNN
F 2 "NetCore_Tetra:JST_GH_4" H 9200 1900 50  0001 C CNN
F 3 "" H 9200 1900 50  0001 C CNN
	1    9200 1900
	1    0    0    -1  
$EndComp
Wire Wire Line
	8750 1800 8490 1800
Text GLabel 8490 1800 2    42   Output ~ 0
3V3_AON
Wire Wire Line
	8750 1867 8490 1867
Text GLabel 8490 1867 2    42   Input ~ 0
GND
Wire Wire Line
	8750 1933 8490 1933
Text GLabel 8490 1933 2    42   Output ~ 0
B_UART_TX
Wire Wire Line
	8750 2000 8490 2000
Text GLabel 8490 2000 2    42   Input ~ 0
B_UART_RX
Text Notes 7200 3300 0    42   ~ 0
GPIO14/15 connect to supervisor UART through 1 k series resistors.
Text Notes 7200 3362 0    42   ~ 0
No 5 V signaling. Supervisor remains powered when the Pi rail is off.
Wire Notes Line
	10600 1050 15500 1050
Wire Notes Line
	15500 1050 15500 4400
Wire Notes Line
	15500 4400 10600 4400
Wire Notes Line
	10600 4400 10600 1050
Text Notes 10680 1170 0    70   ~ 0
SUPERVISOR COUPLING / WATCHDOG
$Comp
L NetCore_Tetra:R R401
U 1 1 6500002C
P 11100 1750
F 0 "R401" H 11100 1410 50  0000 C CNN
F 1 "1k" H 11100 1510 50  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 11100 1750 50  0001 C CNN
F 3 "" H 11100 1750 50  0001 C CNN
	1    11100 1750
	1    0    0    -1  
$EndComp
Wire Wire Line
	10750 1750 10490 1750
Text Label 10490 1750 2    42   ~ 0
B_GPIO14_TXD
Wire Wire Line
	11450 1750 11710 1750
Text GLabel 11710 1750 0    42   Output ~ 0
B_UART_TX
$Comp
L NetCore_Tetra:R R402
U 1 1 6500002D
P 11100 2300
F 0 "R402" H 11100 1960 50  0000 C CNN
F 1 "1k" H 11100 2060 50  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 11100 2300 50  0001 C CNN
F 3 "" H 11100 2300 50  0001 C CNN
	1    11100 2300
	1    0    0    -1  
$EndComp
Wire Wire Line
	10750 2300 10490 2300
Text GLabel 10490 2300 2    42   Input ~ 0
B_UART_RX
Wire Wire Line
	11450 2300 11710 2300
Text Label 11710 2300 0    42   ~ 0
B_GPIO15_RXD
$Comp
L NetCore_Tetra:R R403
U 1 1 6500002E
P 11100 2850
F 0 "R403" H 11100 2510 50  0000 C CNN
F 1 "1k" H 11100 2610 50  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 11100 2850 50  0001 C CNN
F 3 "" H 11100 2850 50  0001 C CNN
	1    11100 2850
	1    0    0    -1  
$EndComp
Wire Wire Line
	10750 2850 10490 2850
Text Label 10490 2850 2    42   ~ 0
B_GPIO6
Wire Wire Line
	11450 2850 11710 2850
Text GLabel 11710 2850 0    42   Output ~ 0
B_HEARTBEAT
$Comp
L NetCore_Tetra:NMOS_OD Q401
U 1 1 6500002F
P 12600 1900
F 0 "Q401" H 12600 1450 50  0000 C CNN
F 1 "PI SHUTDOWN OPEN-DRAIN" H 12600 1550 50  0000 C CNN
F 2 "Package_TO_SOT_SMD:SOT-23" H 12600 1900 50  0001 C CNN
F 3 "" H 12600 1900 50  0001 C CNN
	1    12600 1900
	1    0    0    -1  
$EndComp
Wire Wire Line
	12210 1810 11950 1810
Text GLabel 11950 1810 2    42   Input ~ 0
B_SHUTDOWN_CMD
Wire Wire Line
	12990 1810 13250 1810
Text Label 13250 1810 0    42   ~ 0
B_GPIO16
Wire Wire Line
	12510 2290 12510 2550
Text GLabel 12510 2550 3    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:NMOS_OD Q402
U 1 1 65000030
P 12600 3000
F 0 "Q402" H 12600 2550 50  0000 C CNN
F 1 "PI ALERT OPEN-DRAIN" H 12600 2650 50  0000 C CNN
F 2 "Package_TO_SOT_SMD:SOT-23" H 12600 3000 50  0001 C CNN
F 3 "" H 12600 3000 50  0001 C CNN
	1    12600 3000
	1    0    0    -1  
$EndComp
Wire Wire Line
	12210 2910 11950 2910
Text GLabel 11950 2910 2    42   Input ~ 0
B_ALERT_CMD
Wire Wire Line
	12990 2910 13250 2910
Text Label 13250 2910 0    42   ~ 0
B_GPIO17
Wire Wire Line
	12510 3390 12510 3650
Text GLabel 12510 3650 3    42   Input ~ 0
GND
Text Notes 10800 3800 0    42   ~ 0
Heartbeat GPIO6 is monitored by supervisor.
Text Notes 10800 3862 0    42   ~ 0
GPIO16 requests orderly shutdown; after timeout the supervisor may drop the eFuse.
Text Notes 10800 3924 0    42   ~ 0
GPIO17 provides a separate alert/interrupt line.
Wire Notes Line
	7000 4800 12100 4800
Wire Notes Line
	12100 4800 12100 10400
Wire Notes Line
	12100 10400 7000 10400
Wire Notes Line
	7000 10400 7000 4800
Text Notes 7080 4920 0    70   ~ 0
FREE GPIO / EXTERNAL TERMINALS
$Comp
L NetCore_Tetra:ESD_ARRAY_8 D401
U 1 1 65000031
P 8200 7000
F 0 "D401" H 8200 6240 50  0000 C CNN
F 1 "8-LINE 3V3 ESD ARRAY" H 8200 6340 50  0000 C CNN
F 2 "Package_DFN_QFN:DFN-18-1EP_3x5mm_P0.5mm" H 8200 7000 50  0001 C CNN
F 3 "" H 8200 7000 50  0001 C CNN
	1    8200 7000
	1    0    0    -1  
$EndComp
Wire Wire Line
	7650 6600 7390 6600
Text Label 7390 6600 2    42   ~ 0
B_GPIO4
Wire Wire Line
	8750 6600 9010 6600
Text GLabel 9010 6600 0    42   BiDi ~ 0
B_EXT_GPIO4_1WIRE
Wire Wire Line
	7650 6714 7390 6714
Text Label 7390 6714 2    42   ~ 0
B_GPIO7_CE1
Wire Wire Line
	8750 6714 9010 6714
Text GLabel 9010 6714 0    42   BiDi ~ 0
B_EXT_GPIO7_CE1
Wire Wire Line
	7650 6829 7390 6829
Text Label 7390 6829 2    42   ~ 0
B_GPIO17
Wire Wire Line
	8750 6829 9010 6829
Text GLabel 9010 6829 0    42   BiDi ~ 0
B_EXT_GPIO17
Wire Wire Line
	7650 6943 7390 6943
Text Label 7390 6943 2    42   ~ 0
B_GPIO24
Wire Wire Line
	8750 6943 9010 6943
Text GLabel 9010 6943 0    42   BiDi ~ 0
B_EXT_GPIO24
Wire Wire Line
	7650 7057 7390 7057
Text Label 7390 7057 2    42   ~ 0
B_GPIO25
Wire Wire Line
	8750 7057 9010 7057
Text GLabel 9010 7057 0    42   BiDi ~ 0
B_EXT_GPIO25
Wire Wire Line
	7650 7171 7390 7171
Text Label 7390 7171 2    42   ~ 0
B_GPIO26
Wire Wire Line
	8750 7171 9010 7171
Text GLabel 9010 7171 0    42   BiDi ~ 0
B_EXT_GPIO26
Wire Wire Line
	7650 7286 7390 7286
Text Label 7390 7286 2    42   ~ 0
B_GPIO27
Wire Wire Line
	8750 7286 9010 7286
Text GLabel 9010 7286 0    42   BiDi ~ 0
B_EXT_GPIO27
Wire Wire Line
	7650 7400 7390 7400
Text GLabel 7390 7400 2    42   BiDi ~ 0
B_EXT_SPARE
Wire Wire Line
	8750 7400 9010 7400
Text GLabel 9010 7400 0    42   BiDi ~ 0
B_EXT_SPARE
Wire Wire Line
	7950 7700 7950 7960
Text GLabel 7950 7960 3    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:TERM_12 J404
U 1 1 65000032
P 10800 7000
F 0 "J404" H 10800 6140 50  0000 C CNN
F 1 "NODE B GPIO TERMINAL" H 10800 6240 50  0000 C CNN
F 2 "NetCore_Tetra:Terminal_12_3.5mm" H 10800 7000 50  0001 C CNN
F 3 "" H 10800 7000 50  0001 C CNN
	1    10800 7000
	1    0    0    -1  
$EndComp
Wire Wire Line
	10350 6500 10090 6500
Text GLabel 10090 6500 2    42   BiDi ~ 0
3V3_AON
Wire Wire Line
	10350 6591 10090 6591
Text GLabel 10090 6591 2    42   BiDi ~ 0
5V_B
Wire Wire Line
	10350 6682 10090 6682
Text GLabel 10090 6682 2    42   BiDi ~ 0
GND
Wire Wire Line
	10350 6773 10090 6773
Text GLabel 10090 6773 2    42   BiDi ~ 0
B_EXT_GPIO4_1WIRE
Wire Wire Line
	10350 6864 10090 6864
Text GLabel 10090 6864 2    42   BiDi ~ 0
B_EXT_GPIO7_CE1
Wire Wire Line
	10350 6955 10090 6955
Text GLabel 10090 6955 2    42   BiDi ~ 0
B_EXT_GPIO17
Wire Wire Line
	10350 7045 10090 7045
Text GLabel 10090 7045 2    42   BiDi ~ 0
B_EXT_GPIO24
Wire Wire Line
	10350 7136 10090 7136
Text GLabel 10090 7136 2    42   BiDi ~ 0
B_EXT_GPIO25
Wire Wire Line
	10350 7227 10090 7227
Text GLabel 10090 7227 2    42   BiDi ~ 0
B_EXT_GPIO26
Wire Wire Line
	10350 7318 10090 7318
Text GLabel 10090 7318 2    42   BiDi ~ 0
B_EXT_GPIO27
Wire Wire Line
	10350 7409 10090 7409
Text GLabel 10090 7409 2    42   BiDi ~ 0
B_UART_TX
Wire Wire Line
	10350 7500 10090 7500
Text GLabel 10090 7500 2    42   BiDi ~ 0
B_UART_RX
Text Notes 7200 9300 0    42   ~ 0
Each exposed GPIO gets 100 Ω series resistance plus low-capacitance ESD.
Text Notes 7200 9362 0    42   ~ 0
GPIO7 is CE1 on the same SPI0 bus as SXceiver: chip-select use only; no clock/MOSI/MISO breakout.
Text Notes 7200 9424 0    42   ~ 0
5V terminal output must be separately PTC-limited to 500 mA.
Wire Notes Line
	12400 4800 15500 4800
Wire Notes Line
	15500 4800 15500 10400
Wire Notes Line
	15500 10400 12400 10400
Wire Notes Line
	12400 10400 12400 4800
Text Notes 12480 4920 0    70   ~ 0
LEGACY / TEST / 1-WIRE
$Comp
L NetCore_Tetra:JUMPER JP401
U 1 1 65000033
P 13000 5850
F 0 "JP401" H 13000 5500 50  0000 C CNN
F 1 "DNP GPIO12" H 13000 5600 50  0000 C CNN
F 2 "Jumper:SolderJumper-2_Open" H 13000 5850 50  0001 C CNN
F 3 "" H 13000 5850 50  0001 C CNN
	1    13000 5850
	1    0    0    -1  
$EndComp
Wire Wire Line
	12650 5850 12390 5850
Text Label 12390 5850 2    42   ~ 0
B_GPIO12_LEGACY_TX
Wire Wire Line
	13350 5850 13610 5850
Text GLabel 13610 5850 0    42   BiDi ~ 0
B_GPIO12_TEST
$Comp
L NetCore_Tetra:JUMPER JP402
U 1 1 65000034
P 13000 6450
F 0 "JP402" H 13000 6100 50  0000 C CNN
F 1 "DNP GPIO13" H 13000 6200 50  0000 C CNN
F 2 "Jumper:SolderJumper-2_Open" H 13000 6450 50  0001 C CNN
F 3 "" H 13000 6450 50  0001 C CNN
	1    13000 6450
	1    0    0    -1  
$EndComp
Wire Wire Line
	12650 6450 12390 6450
Text Label 12390 6450 2    42   ~ 0
B_GPIO13_LEGACY_RX
Wire Wire Line
	13350 6450 13610 6450
Text GLabel 13610 6450 0    42   BiDi ~ 0
B_GPIO13_TEST
$Comp
L NetCore_Tetra:TERM_3 J405
U 1 1 65000035
P 14200 7600
F 0 "J405" H 14200 7190 50  0000 C CNN
F 1 "1-WIRE / SENSOR" H 14200 7290 50  0000 C CNN
F 2 "NetCore_Tetra:JST_XH_3" H 14200 7600 50  0001 C CNN
F 3 "" H 14200 7600 50  0001 C CNN
	1    14200 7600
	1    0    0    -1  
$EndComp
Wire Wire Line
	13750 7550 13490 7550
Text GLabel 13490 7550 2    42   Output ~ 0
3V3_AON
Wire Wire Line
	13750 7600 13490 7600
Text GLabel 13490 7600 2    42   Input ~ 0
GND
Wire Wire Line
	13750 7650 13490 7650
Text GLabel 13490 7650 2    42   BiDi ~ 0
B_EXT_GPIO4_1WIRE
Text Notes 12600 8600 0    42   ~ 0
GPIO12/13 may conflict with SXceiver hardware v1.0 and stay DNP.
Text Notes 12600 8662 0    42   ~ 0
Populate only after confirming board revision >=1.1/1.2 and software mapping.
Text Notes 12600 8724 0    42   ~ 0
1-Wire pull-up 4.7 k to 3V3_AON is DNP by default.
$EndSCHEMATC
