EESchema Schematic File Version 4
LIBS:NetCore_Tetra
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
encoding utf-8
Sheet 2 6
Title "Power Inputs, Protection and Dual Node Rails"
Date "2026-09-17"
Rev "0.1.1-format-fix"
Comp "NetCore-Tetra / Jan Hoffmeister"
Comment1 "Engineering concept - not released for mains or production"
Comment2 "Dual Pi + dual SXceiver compact baseboard"
Comment3 "Default power path: external 12 VDC"
Comment4 "Run ERC/DRC and component/footprint lock before fabrication"
$EndDescr
Text Notes 700 600 0    100   ~ 0
POWER INPUTS AND RAIL SEQUENCING
Wire Notes Line
	600 1050 4700 1050
Wire Notes Line
	4700 1050 4700 4100
Wire Notes Line
	4700 4100 600 4100
Wire Notes Line
	600 4100 600 1050
Text Notes 680 1170 0    70   ~ 0
A. DEFAULT 12 VDC INPUT
Text Notes 680 1280 0    45   ~ 0
External regulated 12 V supply; preferred build for prototypes and field service.
$Comp
L NetCore_Tetra:TERM_2 J201
U 1 1 65000006
P 1100 1900
F 0 "J201" H 1100 1490 50  0000 C CNN
F 1 "12VDC INPUT" H 1100 1590 50  0000 C CNN
F 2 "NetCore_Tetra:Terminal_2_7.62mm" H 1100 1900 50  0001 C CNN
F 3 "" H 1100 1900 50  0001 C CNN
	1    1100 1900
	1    0    0    -1  
$EndComp
Wire Wire Line
	650 1850 390 1850
Text GLabel 390 1850 2    42   Output ~ 0
DC_IN_12V
Wire Wire Line
	650 1950 390 1950
Text GLabel 390 1950 2    42   Output ~ 0
GND
$Comp
L NetCore_Tetra:FUSE F201
U 1 1 65000007
P 2100 1650
F 0 "F201" H 2100 1300 50  0000 C CNN
F 1 "8A TIME-DELAY" H 2100 1400 50  0000 C CNN
F 2 "Fuse:Fuse_Blade_Mini_Keystone_3568" H 2100 1650 50  0001 C CNN
F 3 "" H 2100 1650 50  0001 C CNN
	1    2100 1650
	1    0    0    -1  
$EndComp
Wire Wire Line
	650 1850 1720 1650
$Comp
L NetCore_Tetra:IDEAL_DIODE_REVERSE_PROTECT U201
U 1 1 65000008
P 3000 1900
F 0 "U201" H 3000 1390 50  0000 C CNN
F 1 "12V REVERSE/IDEAL DIODE" H 3000 1490 50  0000 C CNN
F 2 "NetCore_Tetra:Ideal_Diode_Controller_TBD" H 3000 1900 50  0001 C CNN
F 3 "" H 3000 1900 50  0001 C CNN
	1    3000 1900
	1    0    0    -1  
$EndComp
Wire Wire Line
	2480 1650 2400 1750
Wire Wire Line
	2400 2050 2140 2050
Text GLabel 2140 2050 2    42   Input ~ 0
GND
$Comp
L NetCore_Tetra:JUMPER LK201
U 1 1 65000009
P 4050 1650
F 0 "LK201" H 4050 1300 50  0000 C CNN
F 1 "FIT FOR DC INPUT" H 4050 1400 50  0000 C CNN
F 2 "NetCore_Tetra:Power_Link_10A" H 4050 1650 50  0001 C CNN
F 3 "" H 4050 1650 50  0001 C CNN
	1    4050 1650
	1    0    0    -1  
$EndComp
Wire Wire Line
	3600 1750 3700 1650
Wire Wire Line
	3600 1900 3860 1900
Text GLabel 3860 1900 0    42   Input ~ 0
GND
Wire Wire Line
	3600 2050 3860 2050
Text GLabel 3860 2050 0    42   Output ~ 0
DC_INPUT_FAULT_N
Wire Wire Line
	4400 1650 4660 1650
Text GLabel 4660 1650 0    42   Output ~ 0
PWR_12V_SOURCE
$Comp
L NetCore_Tetra:TVS D201
U 1 1 6500000A
P 2500 3000
F 0 "D201" H 2500 2630 50  0000 C CNN
F 1 "SMBJ18A" H 2500 2730 50  0000 C CNN
F 2 "Diode_SMD:D_SMB" H 2500 3000 50  0001 C CNN
F 3 "" H 2500 3000 50  0001 C CNN
	1    2500 3000
	1    0    0    -1  
$EndComp
Wire Wire Line
	2460 2690 2460 2430
Text GLabel 2460 2430 1    42   Input ~ 0
DC_AFTER_FUSE
Wire Wire Line
	2460 3310 2460 3570
Text GLabel 2460 3570 3    42   Input ~ 0
GND
Text Notes 900 3500 0    45   ~ 0
Add 470 uF / 25 V bulk + 1 uF + 100 nF at DC input.
Text Notes 900 3565 0    45   ~ 0
U201 candidate: LM74700-Q1 + low-RDS(on) MOSFET or equivalent.
Text Notes 900 3630 0    45   ~ 0
LK201 and LK202 are mutually exclusive population links.
Wire Notes Line
	5000 1050 10100 1050
Wire Notes Line
	10100 1050 10100 4100
Wire Notes Line
	10100 4100 5000 4100
Wire Notes Line
	5000 4100 5000 1050
Text Notes 5080 1170 0    70   ~ 0
B. OPTIONAL ON-BOARD 230 VAC INPUT - DNP BY DEFAULT
Text Notes 5080 1280 0    45   ~ 0
Qualified assembly only. Keep this entire island isolated and inaccessible in enclosure.
$Comp
L NetCore_Tetra:TERM_3 J202
U 1 1 6500000B
P 5550 1900
F 0 "J202" H 5550 1490 50  0000 C CNN
F 1 "230VAC L / N / PE" H 5550 1590 50  0000 C CNN
F 2 "NetCore_Tetra:Terminal_3_7.62mm" H 5550 1900 50  0001 C CNN
F 3 "" H 5550 1900 50  0001 C CNN
	1    5550 1900
	1    0    0    -1  
$EndComp
Wire Wire Line
	5100 1850 4840 1850
Text GLabel 4840 1850 2    42   Output ~ 0
AC_L_IN
Wire Wire Line
	5100 1900 4840 1900
Text GLabel 4840 1900 2    42   Output ~ 0
AC_N_IN
Wire Wire Line
	5100 1950 4840 1950
Text GLabel 4840 1950 2    42   Output ~ 0
CHASSIS_PE
$Comp
L NetCore_Tetra:FUSE F202
U 1 1 6500000C
P 6500 1500
F 0 "F202" H 6500 1150 50  0000 C CNN
F 1 "T2A / 250VAC" H 6500 1250 50  0000 C CNN
F 2 "Fuse:Fuseholder_5x20mm" H 6500 1500 50  0001 C CNN
F 3 "" H 6500 1500 50  0001 C CNN
	1    6500 1500
	1    0    0    -1  
$EndComp
$Comp
L NetCore_Tetra:NTC RT201
U 1 1 6500000D
P 7300 1500
F 0 "RT201" H 7300 1150 50  0000 C CNN
F 1 "INRUSH LIMITER" H 7300 1250 50  0000 C CNN
F 2 "NetCore_Tetra:NTC_Disc_TBD" H 7300 1500 50  0001 C CNN
F 3 "" H 7300 1500 50  0001 C CNN
	1    7300 1500
	1    0    0    -1  
$EndComp
$Comp
L NetCore_Tetra:CMC L201
U 1 1 6500000E
P 8200 1900
F 0 "L201" H 8200 1460 50  0000 C CNN
F 1 "2-LINE COMMON MODE CHOKE" H 8200 1560 50  0000 C CNN
F 2 "NetCore_Tetra:CMC_Mains_TBD" H 8200 1900 50  0001 C CNN
F 3 "" H 8200 1900 50  0001 C CNN
	1    8200 1900
	1    0    0    -1  
$EndComp
$Comp
L NetCore_Tetra:ACDC_230VAC_12V_80W PS201
U 1 1 6500000F
P 9400 1900
F 0 "PS201" H 9400 1290 50  0000 C CNN
F 1 "CERTIFIED 12V / >=80W MODULE" H 9400 1390 50  0000 C CNN
F 2 "NetCore_Tetra:ACDC_Module_90x55_DNP" H 9400 1900 50  0001 C CNN
F 3 "" H 9400 1900 50  0001 C CNN
	1    9400 1900
	1    0    0    -1  
$EndComp
Wire Wire Line
	5100 1850 6120 1500
Wire Wire Line
	6880 1500 6950 1500
Wire Wire Line
	7650 1500 7750 1820
Wire Wire Line
	5100 1900 7750 1980
Wire Wire Line
	8650 1820 8700 1650
Wire Wire Line
	8650 1980 8700 2150
$Comp
L NetCore_Tetra:MOV RV201
U 1 1 65000010
P 7000 2700
F 0 "RV201" H 7000 2330 50  0000 C CNN
F 1 "MOV 275VAC" H 7000 2430 50  0000 C CNN
F 2 "Varistor:RV_Disc_D10mm_W3.9mm_P7.5mm" H 7000 2700 50  0001 C CNN
F 3 "" H 7000 2700 50  0001 C CNN
	1    7000 2700
	1    0    0    -1  
$EndComp
Wire Wire Line
	6960 2390 6960 2130
Text GLabel 6960 2130 1    42   Input ~ 0
AC_L_FILTERED
Wire Wire Line
	6960 3010 6960 3270
Text GLabel 6960 3270 3    42   Input ~ 0
AC_N_FILTERED
$Comp
L NetCore_Tetra:JUMPER LK202
U 1 1 65000011
P 10800 1650
F 0 "LK202" H 10800 1300 50  0000 C CNN
F 1 "FIT FOR AC MODULE" H 10800 1400 50  0000 C CNN
F 2 "NetCore_Tetra:Power_Link_10A" H 10800 1650 50  0001 C CNN
F 3 "" H 10800 1650 50  0001 C CNN
	1    10800 1650
	1    0    0    -1  
$EndComp
Wire Wire Line
	10100 1650 10450 1650
Wire Wire Line
	10100 2150 10360 2150
Text GLabel 10360 2150 0    42   Output ~ 0
GND
Wire Wire Line
	11150 1650 11410 1650
Text GLabel 11410 1650 0    42   Output ~ 0
PWR_12V_SOURCE
Text Notes 5200 3500 0    45   ~ 0
Required before use: exact AC/DC module lock, datasheet footprint, agency approvals, creepage/clearance review,
Text Notes 5200 3565 0    45   ~ 0
slots/keep-out, fuse coordination, MOV/NTC energy rating, thermal test and touch-safe enclosure.
Text Notes 5200 3630 0    45   ~ 0
PE terminates at chassis only; do not bond PE to logic GND on this board.
Wire Notes Line
	600 4500 15500 4500
Wire Notes Line
	15500 4500 15500 10400
Wire Notes Line
	15500 10400 600 10400
Wire Notes Line
	600 10400 600 4500
Text Notes 680 4620 0    70   ~ 0
C. 12 V BUS, ALWAYS-ON SUPERVISOR AND TWO INDEPENDENT 5 V NODE RAILS
$Comp
L NetCore_Tetra:SHUNT RSH201
U 1 1 65000012
P 1600 5400
F 0 "RSH201" H 1600 5050 50  0000 C CNN
F 1 "2mR 3W KELVIN" H 1600 5150 50  0000 C CNN
F 2 "NetCore_Tetra:Shunt_4Terminal_2512" H 1600 5400 50  0001 C CNN
F 3 "" H 1600 5400 50  0001 C CNN
	1    1600 5400
	1    0    0    -1  
$EndComp
Wire Wire Line
	1200 5400 940 5400
Text GLabel 940 5400 2    42   Input ~ 0
PWR_12V_SOURCE
Wire Wire Line
	2000 5400 2260 5400
Text GLabel 2260 5400 0    42   Output ~ 0
12V_BUS
Text Notes 850 5850 0    45   ~ 0
Total 12 V shunt sense: TOTAL_SHUNT_P / TOTAL_SHUNT_N
Text Notes 850 5915 0    45   ~ 0
INA226 located on supervisor/sensor sheet.
Text GLabel 1350 5300 0    42   Input ~ 0
TOTAL_SHUNT_P
Text GLabel 1850 5300 0    42   Input ~ 0
TOTAL_SHUNT_N
$Comp
L NetCore_Tetra:AUX_BUCK_3V3 U202
U 1 1 65000013
P 3300 5500
F 0 "U202" H 3300 4990 50  0000 C CNN
F 1 "12V -> 3V3_AON / 2A" H 3300 5090 50  0000 C CNN
F 2 "NetCore_Tetra:Buck_12V_3V3_TBD" H 3300 5500 50  0001 C CNN
F 3 "" H 3300 5500 50  0001 C CNN
	1    3300 5500
	1    0    0    -1  
$EndComp
Wire Wire Line
	2750 5350 2490 5350
Text GLabel 2490 5350 2    42   Input ~ 0
12V_BUS
Wire Wire Line
	2750 5500 2490 5500
Text GLabel 2490 5500 2    42   Input ~ 0
AUX_BUCK_EN
Wire Wire Line
	2750 5650 2490 5650
Text GLabel 2490 5650 2    42   Input ~ 0
GND
Wire Wire Line
	3850 5350 4110 5350
Text GLabel 4110 5350 0    42   Output ~ 0
3V3_AON
Wire Wire Line
	3850 5650 4110 5650
Text GLabel 4110 5650 0    42   Output ~ 0
3V3_AON_PG
$Comp
L NetCore_Tetra:FUSE F203
U 1 1 65000014
P 700 6600
F 0 "F203" H 700 6250 50  0000 C CNN
F 1 "7.5A NODE FUSE" H 700 6350 50  0000 C CNN
F 2 "Fuse:Fuse_Blade_Mini_Keystone_3568" H 700 6600 50  0001 C CNN
F 3 "" H 700 6600 50  0001 C CNN
	1    700 6600
	1    0    0    -1  
$EndComp
Wire Wire Line
	320 6600 70 6600
Text GLabel 70 6600 2    42   Input ~ 0
12V_BUS
$Comp
L NetCore_Tetra:DCDC_5V10A U203
U 1 1 65000015
P 2200 6900
F 0 "U203" H 2200 6340 50  0000 C CNN
F 1 "A 5.15V / 10A-CLASS" H 2200 6440 50  0000 C CNN
F 2 "NetCore_Tetra:DCDC_10A_Module_TBD" H 2200 6900 50  0001 C CNN
F 3 "" H 2200 6900 50  0001 C CNN
	1    2200 6900
	1    0    0    -1  
$EndComp
Wire Wire Line
	1080 6600 1575 6700
Wire Wire Line
	1575 6900 1315 6900
Text GLabel 1315 6900 2    42   Input ~ 0
A_DCDC_EN
Wire Wire Line
	1575 7100 1315 7100
Text GLabel 1315 7100 2    42   Input ~ 0
GND
Wire Wire Line
	2825 6900 3085 6900
Text GLabel 3085 6900 0    42   UnSpc ~ 0
A_DCDC_TRIM
Wire Wire Line
	2825 7100 3085 7100
Text GLabel 3085 7100 0    42   Output ~ 0
A_DCDC_PG
$Comp
L NetCore_Tetra:SHUNT RSH202
U 1 1 65000016
P 3800 6600
F 0 "RSH202" H 3800 6250 50  0000 C CNN
F 1 "5mR 3W KELVIN" H 3800 6350 50  0000 C CNN
F 2 "NetCore_Tetra:Shunt_4Terminal_2512" H 3800 6600 50  0001 C CNN
F 3 "" H 3800 6600 50  0001 C CNN
	1    3800 6600
	1    0    0    -1  
$EndComp
Wire Wire Line
	2825 6700 3400 6600
Text GLabel 3400 6480 0    40   Input ~ 0
A_SHUNT_P
Text GLabel 4200 6480 0    40   Input ~ 0
A_SHUNT_N
$Comp
L NetCore_Tetra:EFUSE_5V_6A U204
U 1 1 65000017
P 5400 6900
F 0 "U204" H 5400 6340 50  0000 C CNN
F 1 "A 5V EFUSE / POWER CYCLE" H 5400 6440 50  0000 C CNN
F 2 "NetCore_Tetra:EFuse_5V_6A_TBD" H 5400 6900 50  0001 C CNN
F 3 "" H 5400 6900 50  0001 C CNN
	1    5400 6900
	1    0    0    -1  
$EndComp
Wire Wire Line
	4200 6600 4775 6700
Wire Wire Line
	4775 6900 4515 6900
Text GLabel 4515 6900 2    42   Input ~ 0
A_PWR_EN
Wire Wire Line
	4775 7100 4515 7100
Text GLabel 4515 7100 2    42   Input ~ 0
GND
Wire Wire Line
	6025 6700 6285 6700
Text GLabel 6285 6700 0    42   Output ~ 0
5V_A
Wire Wire Line
	6025 6900 6285 6900
Text GLabel 6285 6900 0    42   Output ~ 0
A_PWR_FAULT_N
Wire Wire Line
	6025 7100 6285 7100
Text GLabel 6285 7100 0    42   Output ~ 0
A_PWR_PG
Text Notes 700 8050 0    42   ~ 0
A: converter target 5.10–5.15 V at board output; verify at Pi header under load.
Text Notes 700 8112 0    42   ~ 0
Do not exceed Raspberry Pi supply limits. eFuse provides current limit, fault and supervisor power-cycle.
$Comp
L NetCore_Tetra:FUSE F204
U 1 1 65000018
P 8200 6600
F 0 "F204" H 8200 6250 50  0000 C CNN
F 1 "7.5A NODE FUSE" H 8200 6350 50  0000 C CNN
F 2 "Fuse:Fuse_Blade_Mini_Keystone_3568" H 8200 6600 50  0001 C CNN
F 3 "" H 8200 6600 50  0001 C CNN
	1    8200 6600
	1    0    0    -1  
$EndComp
Wire Wire Line
	7820 6600 7570 6600
Text GLabel 7570 6600 2    42   Input ~ 0
12V_BUS
$Comp
L NetCore_Tetra:DCDC_5V10A U205
U 1 1 65000019
P 9700 6900
F 0 "U205" H 9700 6340 50  0000 C CNN
F 1 "B 5.15V / 10A-CLASS" H 9700 6440 50  0000 C CNN
F 2 "NetCore_Tetra:DCDC_10A_Module_TBD" H 9700 6900 50  0001 C CNN
F 3 "" H 9700 6900 50  0001 C CNN
	1    9700 6900
	1    0    0    -1  
$EndComp
Wire Wire Line
	8580 6600 9075 6700
Wire Wire Line
	9075 6900 8815 6900
Text GLabel 8815 6900 2    42   Input ~ 0
B_DCDC_EN
Wire Wire Line
	9075 7100 8815 7100
Text GLabel 8815 7100 2    42   Input ~ 0
GND
Wire Wire Line
	10325 6900 10585 6900
Text GLabel 10585 6900 0    42   UnSpc ~ 0
B_DCDC_TRIM
Wire Wire Line
	10325 7100 10585 7100
Text GLabel 10585 7100 0    42   Output ~ 0
B_DCDC_PG
$Comp
L NetCore_Tetra:SHUNT RSH203
U 1 1 6500001A
P 11300 6600
F 0 "RSH203" H 11300 6250 50  0000 C CNN
F 1 "5mR 3W KELVIN" H 11300 6350 50  0000 C CNN
F 2 "NetCore_Tetra:Shunt_4Terminal_2512" H 11300 6600 50  0001 C CNN
F 3 "" H 11300 6600 50  0001 C CNN
	1    11300 6600
	1    0    0    -1  
$EndComp
Wire Wire Line
	10325 6700 10900 6600
Text GLabel 10900 6480 0    40   Input ~ 0
B_SHUNT_P
Text GLabel 11700 6480 0    40   Input ~ 0
B_SHUNT_N
$Comp
L NetCore_Tetra:EFUSE_5V_6A U206
U 1 1 6500001B
P 12900 6900
F 0 "U206" H 12900 6340 50  0000 C CNN
F 1 "B 5V EFUSE / POWER CYCLE" H 12900 6440 50  0000 C CNN
F 2 "NetCore_Tetra:EFuse_5V_6A_TBD" H 12900 6900 50  0001 C CNN
F 3 "" H 12900 6900 50  0001 C CNN
	1    12900 6900
	1    0    0    -1  
$EndComp
Wire Wire Line
	11700 6600 12275 6700
Wire Wire Line
	12275 6900 12015 6900
Text GLabel 12015 6900 2    42   Input ~ 0
B_PWR_EN
Wire Wire Line
	12275 7100 12015 7100
Text GLabel 12015 7100 2    42   Input ~ 0
GND
Wire Wire Line
	13525 6700 13785 6700
Text GLabel 13785 6700 0    42   Output ~ 0
5V_B
Wire Wire Line
	13525 6900 13785 6900
Text GLabel 13785 6900 0    42   Output ~ 0
B_PWR_FAULT_N
Wire Wire Line
	13525 7100 13785 7100
Text GLabel 13785 7100 0    42   Output ~ 0
B_PWR_PG
Text Notes 8200 8050 0    42   ~ 0
B: converter target 5.10–5.15 V at board output; verify at Pi header under load.
Text Notes 8200 8112 0    42   ~ 0
Do not exceed Raspberry Pi supply limits. eFuse provides current limit, fault and supervisor power-cycle.
Text GLabel 3500 9300 0    50   Output ~ 0
12V_FAN
Text GLabel 5000 9300 0    50   Output ~ 0
12V_PA_A
Text GLabel 6500 9300 0    50   Output ~ 0
12V_PA_B
Text Notes 900 9800 0    50   ~ 0
Assembly rule: populate exactly one source link (LK201 DC or LK202 AC).
Text Notes 900 9870 0    50   ~ 0
Both node rails are independently fused, sensed and switchable. Supervisor remains alive from 3V3_AON during Pi power cycles.
$EndSCHEMATC
