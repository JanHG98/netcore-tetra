# NetCore-Tetra Dual-Pi/SXceiver-Baseboard — KiCad-Konzept v0.1

Dieses Paket enthält einen **real editierbaren KiCad-Schaltplanentwurf** für ein kompaktes NetCore-Tetra-Dual-Node-Baseboard:

- zwei Raspberry-Pi-40-Pin-Stackplätze;
- zwei SXceiver-HAT-Pass-throughs;
- getrennte 5-V-Zweige mit Strommessung, eFuse und Power-Cycle;
- dauerhaft versorgter RP2040-Supervisor plus unabhängiger Hardware-Watchdog;
- Temperatur-, Feuchte-, Spannungs-/Strom- und RF-Detektoreingänge je Node;
- lokales TFT/OLED, Mode-/Node-ID-DIP-Schalter und Status-LEDs;
- Regelung von zwei 4-Draht-PWM-Lüftern;
- geschützte Feld-Ein-/Ausgänge, RS-485, Alarmrelais und externe PA-Stromschaltung;
- 12-VDC-Einspeisung als Standard;
- optional abgetrennter 230-VAC-zu-12-V-Modulbereich, **standardmäßig DNP**;
- vorläufiges 4-Lagen-PCB-Floorplan mit **280 × 100 mm**.

## In KiCad öffnen

Die Schaltplanseiten liegen im **KiCad-Legacy-Format `.sch`** vor. Dieses lässt sich von aktuellen KiCad-Versionen importieren. Öffne `NetCore-Tetra-Dual-Baseboard.pro` oder direkt die Root-Datei `NetCore-Tetra-Dual-Baseboard.sch`. KiCad 8/9 bietet die Konvertierung an; danach sofort als `.kicad_sch` / `.kicad_pro` speichern.

Das PCB-Floorplan liegt bereits als moderne `.kicad_pcb` vor. Es ist eine Platzierungs- und Mechanikstudie, **noch kein geroutetes Fertigungs-PCB**.

## Was v0.1 bewusst noch nicht behauptet

Das ist ein Engineering-Entwurf, keine freigegebene Produktionsversion. In der Erstellungsumgebung war kein `eeschema`/`pcbnew` vorhanden; daher konnte ich die Dateien nicht in KiCad öffnen und keinen echten ERC/DRC-Lauf durchführen. Mehrere Leistungs- und Schutzbauteile sind funktionale Platzhalter. Vor einer Bestellung müssen wir:

1. Pi-Modell, SXceiver-Hardwarestand und den exakten Stacking-Steckverbinder festlegen;
2. jedes Platzhaltersymbol auf den gewählten Datenblatt-Pinout und Footprint abbilden;
3. ERC, PCB-Update, DRC und 3D-Kollisionsprüfung in KiCad ausführen;
4. Leiterbreiten, Via-Felder, Sicherungskoordination, Temperaturanstieg und Spannungsabfall rechnen;
5. Start-/Backpower-Verhalten bei ausgeschaltetem Pi und weiterlaufendem Supervisor prüfen;
6. externe I/O gegen ESD/EFT/Surge testen;
7. den Netzspannungsbereich als eigenständiges Safety-Design qualifiziert prüfen lassen.

## Leistungsarchitektur

- **Bevorzugter Prototyp:** externes geregeltes 12-VDC-Netzteil.
- Jeder Pi erhält einen eigenen 5,10–5,15-V-/10-A-Klasse-Wandler, 5-mΩ-Kelvin-Shunt und Supervisor-gesteuerte eFuse.
- Supervisor und Sensorik laufen über eine Always-on-3,3-V-Schiene. Dadurch kann der Supervisor einen Pi geordnet herunterfahren und anschließend dessen 5-V-Zweig hart zyklieren.
- Einen Pi niemals gleichzeitig über dieses Board und USB-C speisen.
- Die AC- und DC-Einspeisung sind über wechselseitig zu bestückende Source-Links ausgewählt; das ist absichtlich kein automatisches Dual-Input-ORing.

## 230-V-Bereich

Der 230-VAC-Bereich ist **nur ein DNP-Platzhalter**. Er verlangt ein zertifiziertes gekapseltes 12-V-Modul mit mindestens 80 W, einen finalen Footprint und nachgewiesene Zulassungen. Kriech-/Luftstrecken, Slots, Sicherung, MOV/NTC, Thermik, Berührungsschutz, Gehäuse und anwendbare Normen müssen qualifiziert geprüft werden. PE endet am Chassis und wird auf dieser Platine nicht mit Logic-GND verbunden.

## Mechanikkonzept

- Platinenkontur: **280 × 100 mm**, also unter den geforderten 300 mm Breite.
- Node A und B reservieren jeweils 85 × 56 mm für den Pi/SXceiver-Stack.
- Die optionale Netzspannungsinsel liegt ganz rechts und ist durch Keep-out und Frässlots getrennt.
- Lüfter-, Feld- und Stromanschlüsse liegen an den Boardkanten.
- Lagenempfehlung: F.Cu Signale/Leistung, In1 durchgehende GND-Fläche, In2 Leistungsverteilung, B.Cu Signale/Kleinleistung.

## SXceiver-Pinannahmen

Die aktuelle SoapySX-Implementierung nutzt SPI0, I2S/PCM, GPIO5 als Reset und bei aktueller Hardware GPIO22/23 als Steuerleitungen. GPIO12/13 bleiben hinter offenen DNP-Links, weil ältere Hardwarestände diese Leitungen verwendeten. Vor dem Layout `PINMAP.md` gegen die reale SXceiver-Revision prüfen.
