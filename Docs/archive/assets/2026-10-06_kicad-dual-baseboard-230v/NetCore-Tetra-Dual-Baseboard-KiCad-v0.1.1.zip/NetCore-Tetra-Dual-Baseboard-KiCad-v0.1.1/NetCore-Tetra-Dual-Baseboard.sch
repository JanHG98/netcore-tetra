EESchema Schematic File Version 4
LIBS:NetCore_Tetra
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
encoding utf-8
Sheet 1 6
Title "NetCore-Tetra Dual Pi/SXceiver Baseboard - System Overview"
Date "2026-09-17"
Rev "0.1.1-format-fix"
Comp "NetCore-Tetra / Jan Hoffmeister"
Comment1 "Engineering concept - not released for mains or production"
Comment2 "Dual Pi + dual SXceiver compact baseboard"
Comment3 "Default power path: external 12 VDC"
Comment4 "Run ERC/DRC and component/footprint lock before fabrication"
$EndDescr
Text Notes 800 700 0    120   ~ 0
NETCORE-TETRA DUAL BASEBOARD
Text Notes 800 900 0    55   ~ 0
Two Raspberry Pi nodes, two SXceiver HAT stacks, central supervisor, sensor and industrial I/O plane
$Sheet
S 900 1700 2600 1300
U 65000001
F0 "POWER / 12V + OPTIONAL 230VAC" 60
F1 "01_POWER_INPUTS.sch" 60
$EndSheet
$Sheet
S 4300 1700 2400 1300
U 65000002
F0 "NODE A / PI + SXCEIVER" 60
F1 "02_NODE_A.sch" 60
$EndSheet
$Sheet
S 7600 1700 2400 1300
U 65000003
F0 "NODE B / PI + SXCEIVER" 60
F1 "03_NODE_B.sch" 60
$EndSheet
$Sheet
S 4300 4300 3000 1500
U 65000004
F0 "SUPERVISOR + SENSOR FABRIC" 60
F1 "04_SUPERVISOR_SENSORS.sch" 60
$EndSheet
$Sheet
S 8500 4300 3100 1500
U 65000005
F0 "UI + FANS + PROTECTED I/O" 60
F1 "05_UI_FANS_IO.sch" 60
$EndSheet
Text Notes 900 3900 0    75   ~ 0
Mechanical target
Text Notes 900 4050 0    50   ~ 0
Board: 280 x 100 mm, 4-layer concept
Text Notes 900 4120 0    50   ~ 0
Width limit 300 mm respected
Text Notes 900 4190 0    50   ~ 0
Two mirrored 85 x 56 mm Pi envelopes
Text Notes 900 4260 0    50   ~ 0
Mains island physically isolated on right edge
Text Notes 900 4330 0    50   ~ 0
Default assembly: 12 VDC input; AC section DNP
Text Notes 900 5200 0    70   ~ 0
Verified SXceiver-reserved Raspberry Pi signals
Text Notes 900 5350 0    48   ~ 0
SPI0: GPIO8/9/10/11 | I2S/PCM: GPIO18/19/20/21 | RESET: GPIO5
Text Notes 900 5418 0    48   ~ 0
Current hardware: GPIO22 TX control, GPIO23 RX control | GPIO0/1 reserved for HAT EEPROM
Text Notes 900 5486 0    48   ~ 0
GPIO12/13 are routed only through DNP links because legacy SXceiver v1.0 used them.
Text Notes 900 6600 0    70   ~ 0
Power architecture
Text Notes 900 6750 0    48   ~ 0
12 V bus -> independent 5.15 V / 10 A-class converters -> shunt -> eFuse -> Pi pins 2+4
Text Notes 900 6818 0    48   ~ 0
Always-on 3.3 V rail powers supervisor/sensors; supervisor can orderly shut down and power-cycle either node.
Text Notes 900 6886 0    48   ~ 0
Never power a Pi simultaneously through this board and USB-C.
Text Notes 900 7800 0    55   ~ 0
IMPORTANT: 230 VAC area is an engineering placeholder, not a certified design. Use a qualified, encapsulated AC/DC module,
Text Notes 900 7875 0    55   ~ 0
validate creepage/clearance, fusing, thermal rise, enclosure and applicable standards before population.
$EndSCHEMATC
