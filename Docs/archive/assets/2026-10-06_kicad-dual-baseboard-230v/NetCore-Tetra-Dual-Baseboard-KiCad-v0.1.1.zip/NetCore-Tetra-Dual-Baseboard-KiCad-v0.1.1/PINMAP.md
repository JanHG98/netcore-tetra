# Raspberry-Pi-/SXceiver-40-Pin-Belegung

Legende: **SX** = durch aktuellen SXceiver/SoapySX belegt; **EEPROM** = HAT-ID-Bus; **SAFE TAP** = im Entwurf sinnvoll abgegriffen; **DNP** = nur nach Revisionsprüfung bestücken.

| Physisch | Signal | Einstufung | Nutzung auf dem Baseboard |
|---:|---|---|---|
| 1 | `3V3` | POWER — Pi 3.3 V | Pass-through only |
| 2 | `5V` | POWER — 5 V input | Independent node 5 V rail, wide copper |
| 3 | `GPIO2_SDA1` | SAFE TAP — Pi I2C | Short local I2C connector |
| 4 | `5V` | POWER — 5 V input | Independent node 5 V rail, wide copper |
| 5 | `GPIO3_SCL1` | SAFE TAP — Pi I2C | Short local I2C connector |
| 6 | `GND` | GROUND | Pass-through only |
| 7 | `GPIO4` | SAFE TAP / managed GPIO | 1-Wire / external GPIO |
| 8 | `GPIO14_TXD` | SAFE TAP / managed GPIO | Supervisor UART through 1 k |
| 9 | `GND` | GROUND | Pass-through only |
| 10 | `GPIO15_RXD` | SAFE TAP / managed GPIO | Supervisor UART through 1 k |
| 11 | `GPIO17` | SAFE TAP / managed GPIO | Open-drain alert |
| 12 | `GPIO18_PCM_CLK` | SX — I2S/PCM | Pass-through only |
| 13 | `GPIO27` | SAFE TAP / managed GPIO | Protected external GPIO |
| 14 | `GND` | GROUND | Pass-through only |
| 15 | `GPIO22_SX_TX` | SX — TX/RX control (current HW) | Pass-through only |
| 16 | `GPIO23_SX_RX` | SX — TX/RX control (current HW) | Pass-through only |
| 17 | `3V3` | POWER — Pi 3.3 V | Pass-through only |
| 18 | `GPIO24` | SAFE TAP / managed GPIO | Protected external GPIO |
| 19 | `GPIO10_MOSI` | SX — SPI0 | Pass-through only |
| 20 | `GND` | GROUND | Pass-through only |
| 21 | `GPIO9_MISO` | SX — SPI0 | Pass-through only |
| 22 | `GPIO25` | SAFE TAP / managed GPIO | Protected external GPIO |
| 23 | `GPIO11_SCLK` | SX — SPI0 | Pass-through only |
| 24 | `GPIO8_CE0` | SX — SPI0 | Pass-through only |
| 25 | `GND` | GROUND | Pass-through only |
| 26 | `GPIO7_CE1` | SAFE TAP / managed GPIO | CE1 only; shared SPI0 bus |
| 27 | `GPIO0_ID_SD` | EEPROM — reserve | Pass-through only |
| 28 | `GPIO1_ID_SC` | EEPROM — reserve | Pass-through only |
| 29 | `GPIO5_SX_RESET` | SX — reset | Pass-through only |
| 30 | `GND` | GROUND | Pass-through only |
| 31 | `GPIO6` | SAFE TAP / managed GPIO | Heartbeat to supervisor |
| 32 | `GPIO12_LEGACY_TX` | DNP — legacy SX conflict | Test pad behind open solder jumper |
| 33 | `GPIO13_LEGACY_RX` | DNP — legacy SX conflict | Test pad behind open solder jumper |
| 34 | `GND` | GROUND | Pass-through only |
| 35 | `GPIO19_PCM_FS` | SX — I2S/PCM | Pass-through only |
| 36 | `GPIO16` | SAFE TAP / managed GPIO | Open-drain shutdown request |
| 37 | `GPIO26` | SAFE TAP / managed GPIO | Protected external GPIO |
| 38 | `GPIO20_PCM_DIN` | SX — I2S/PCM | Pass-through only |
| 39 | `GND` | GROUND | Pass-through only |
| 40 | `GPIO21_PCM_DOUT` | SX — I2S/PCM | Pass-through only |

## Mode-Schalter je Node

| DIP-Bit | Funktion |
|---:|---|
| 1–2 | Modus: `00 LOCAL`, `01 HYBRID`, `10 RECOVERY`, `11 SERVICE` |
| 3 | RF-Inhibit |
| 4 | Konfigurationssperre |
| 5–8 | 4-Bit-Node-ID |

Die Schalter ziehen nach GND und werden über den jeweiligen MCP23017 hinter dem I2C-Multiplexer gelesen.
