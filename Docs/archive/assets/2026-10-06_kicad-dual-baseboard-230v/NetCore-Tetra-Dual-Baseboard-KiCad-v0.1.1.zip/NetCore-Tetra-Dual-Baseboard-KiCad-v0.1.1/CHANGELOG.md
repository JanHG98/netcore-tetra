# Änderungen v0.1.1 — 2026-09-17

Reine Format-/Importkorrektur auf Basis des ursprünglichen v0.1-ZIP.

- 109 globale Label-Typen `PowerInput` -> `Input`.
- 35 globale Label-Typen `PowerOutput` -> `Output`.
- 10 globale Label-Typen `Passive` -> `UnSpc`.
- 49 Symbole als projektbezogene Legacy-Cache-Bibliothek ergänzt.
- Alle Schaltplan-Titelblöcke auf `0.1.1-format-fix` gesetzt.
- Statisches Prüfskript, Prüfbericht, Änderungsprotokoll und Diff beigefügt.
- Manifest neu berechnet; das Manifest selbst ist nicht in seiner Hash-Liste enthalten.

Keine Leitungen, Netznamen, Pin-Definitionen, Bauteilwerte oder Footprints geändert. Keine Bestätigung elektrischer Richtigkeit. Kein KiCad-Importtest/ERC/DRC durchgeführt.
