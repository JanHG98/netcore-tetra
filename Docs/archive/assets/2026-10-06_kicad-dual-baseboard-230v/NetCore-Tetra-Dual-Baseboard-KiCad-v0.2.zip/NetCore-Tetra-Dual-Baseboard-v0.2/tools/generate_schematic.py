#!/usr/bin/env python3
"""Generate self-contained KiCad 8-format schematics and a vector review PDF.
Not a substitute for KiCad ERC, circuit simulation, PCB layout or safety testing.
Units in this generator: 1 grid unit = 2.54 mm; all electrical ends on 50-mil grid.
"""
from __future__ import annotations
import os, json, uuid, math, csv, re, hashlib, zipfile, pathlib, collections
from dataclasses import dataclass, field
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm

import sys
if len(sys.argv)!=2:
    raise SystemExit('Usage: python generate_schematic.py NEW_OUTPUT_DIRECTORY')
ROOT=pathlib.Path(sys.argv[1]).expanduser().resolve()
ROOT.mkdir(parents=True,exist_ok=True)
(ROOT/'docs').mkdir(exist_ok=True); (ROOT/'tools').mkdir(exist_ok=True)
PROJECT='NetCore-Tetra-Dual-Baseboard'
NS=uuid.UUID('130d1196-99e6-45f5-9033-e153c4ecdc21')
def uid(s): return str(uuid.uuid5(NS,str(s)))
def qs(s): return json.dumps(str(s),ensure_ascii=False)
def f(x): return f'{x*2.54:.5f}'.rstrip('0').rstrip('.')
def ef(size=.42,just=''): return f'(effects (font (size {f(size)} {f(size)}))'+(f' (justify {just})' if just else '')+')'
ROOTID=uid(PROJECT)
LIB='NetCore_Components'

@dataclass
class Pin:
    num:str; name:str; x:float; y:float; orient:int; typ:str='passive'
@dataclass
class Def:
    name:str; pins:list; w:float=8; h:float=8; kind:str='ic'; source:str=''; fp:str=''; extra:dict=field(default_factory=dict)
    def sx(self):
        # Symbol coordinates have an upward-positive y axis; internal geometry is downwards.
        a=[f'(symbol {qs(LIB+":"+self.name)} (pin_names (offset 0.508)) (in_bom yes) (on_board yes)',
           f'(property "Reference" "U" (at 0 {f(self.h/2+2)} 0) {ef()})',
           f'(property "Value" {qs(self.name)} (at 0 {f(self.h/2+1)} 0) {ef()})',
           f'(property "Footprint" {qs(self.fp)} (at 0 0 0) (effects (font (size 1.016 1.016)) hide))',
           f'(property "Datasheet" {qs(self.source)} (at 0 0 0) (effects (font (size 1.016 1.016)) hide))',
           f'(symbol {qs(self.name+"_0_1")}']
        for kind,points,opts in self.graphic():
            if kind=='line':
                p=' '.join(f'(xy {f(x)} {f(-y)})' for x,y in points)
                a.append(f'(polyline (pts {p}) (stroke (width 0.1524) (type default)) (fill (type none)))')
            if kind=='rect':
                (x,y),(xx,yy)=points
                a.append(f'(rectangle (start {f(x)} {f(-y)}) (end {f(xx)} {f(-yy)}) (stroke (width 0.1524) (type default)) (fill (type background)))')
            if kind=='circ':
                (x,y),r=points
                a.append(f'(circle (center {f(x)} {f(-y)}) (radius {f(r)}) (stroke (width 0.1524) (type default)) (fill (type {"outline" if opts else "none"})))')
            if kind=='text':
                (x,y),t=points
                a.append(f'(text {qs(t)} (at {f(x)} {f(-y)} 0) {ef(.38)})')
        a+=[')',f'(symbol {qs(self.name+"_1_1")}']
        for p in self.pins:
            # o = direction of pin pointing into component
            n='~' if self.kind in ['r','c','cp','l','d','z','fuse','sw','led','xtal'] else p.name
            length=1 if self.kind not in ['conn','header'] else 1.5
            a.append(f'(pin {p.typ} line (at {f(p.x)} {f(-p.y)} {p.orient}) (length {f(length)}) (name {qs(n)} {ef(.38)}) (number {qs(p.num)} {ef(.34)}))')
        a+=['))'];return '\n'.join(a)
    def graphic(self):
        w,h=self.w,self.h;k=self.kind
        if k=='r': return [('rect',[(-1,-.6),(1,.6)],0)]
        if k in ['c','cp']:
            o=[('line',[(-.3,-1),(-.3,1)],0),('line',[(.3,-1),(.3,1)],0),('line',[(-1,0),(-.3,0)],0),('line',[(.3,0),(1,0)],0)]
            if k=='cp':o.append(('text',[(-.8,-1.2),'+'],0))
            return o
        if k in ['d','z','led']:
            # Cathode = pin1 at right; anode = pin2 at left (standard diode convention).
            o=[('line',[(-.9,-.8),(-.9,.8),(.8,0),(-.9,-.8)],0),('line',[(.8,-.8),(.8,.8)],0)]
            if k=='z':o.extend([('line',[(.8,-.8),(1.2,-.8)],0),('line',[(.8,.8),(.4,.8)],0)])
            if k=='led':o.extend([('line',[(-.3,-1.0),(.5,-1.8),(.2,-1.8)],0),('line',[(.5,-1.0),(1.3,-1.8),(1,-1.8)],0)])
            return o
        if k=='l':return [('line',[(-1,0),(-.8,-.7),(-.4,.7),(0,-.7),(.4,.7),(.8,-.7),(1,0)],0)]
        if k=='fuse':return [('rect',[(-1,-.5),(1,.5)],0),('line',[(-1,0),(1,0)],0)]
        if k=='spdt':return [('line',[(1,0),(-.8,.2)],0),('circ',[(-1,0),.15],0),('circ',[(-1,2),.15],0),('circ',[(1,0),.15],0)]
        if k=='sw':return [('line',[(-1,0),(.8,-.8)],0),('circ',[(-1,0),.15],0),('circ',[(1,0),.15],0)]
        if k=='xtal':return [('rect',[(-.45,-1),(.45,1)],0),('line',[(-.8,-1),(-.8,1)],0),('line',[(.8,-1),(.8,1)],0)]
        if k=='nmos':
            return [('line',[(-2,0),(-.65,0)],0),('line',[(-.65,-1.2),(-.65,1.2)],0),('line',[(0,-1.2),(0,1.2)],0),('line',[(0,-1),(1,-1),(1,-2)],0),('line',[(0,1),(1,1),(1,2)],0),('line',[(1,1),(1,0),(.2,0)],0),('line',[(.2,0),(.6,-.3),(.6,.3),(.2,0)],0)]
        if k=='npn':return [('line',[(-2,0),(-.6,0)],0),('line',[(-.6,-1),(-.6,1)],0),('line',[(-.6,-.5),(1,-1.5),(1,-2)],0),('line',[(-.6,.5),(1,1.5),(1,2)],0),('line',[(1,1.5),(.4,1.35),(.7,.9),(1,1.5)],0)]
        if k=='transformer':
            return [('line',[(-.4,-6),(-.4,6)],0),('line',[(.4,-6),(.4,6)],0),
             ('line',[(-3,-5),(-2,-5),(-1,-4),(-2,-3),(-1,-2),(-2,-1),(-1,0),(-2,1),(-1,2),(-2,3),(-1,4),(-2,5),(-3,5)],0),
             ('line',[(3,-5),(2,-5),(1,-4),(2,-3),(1,-2),(2,-1),(1,0),(2,1),(1,2),(2,3),(1,4),(2,5),(3,5)],0),
             ('line',[(-3,0),(-1,0)],0),('line',[(-3,9),(-2,9),(-1,10),(-2,11),(-1,12),(-2,13),(-3,13)],0),
             ('circ',[(-2.5,-4.5),.16],1),('circ',[(2.5,4.5),.16],1),('circ',[(-2.5,12.5),.16],1)]
        if k=='bridge':
            return [('line',[(0,-3),(3,0),(0,3),(-3,0),(0,-3)],0),('text',[(-2.0,0),'~'],0),('text',[(2.0,0),'~'],0),('text',[(0,-1.9),'+'],0),('text',[(0,1.9),'-'],0)]
        if k=='opto':
            return [('rect',[(-w/2,-h/2),(w/2,h/2)],0),('line',[(-2,-1),(-2,1),(-1,0),(-2,-1)],0),('line',[(-1,-1),(-1,1)],0),('line',[(0,-1),(1,-2)],0),('line',[(0,1),(1,0)],0),('line',[(2,-2),(2,2)],0)]
        if k=='dip':
            out=[('rect',[(-w/2,-h/2),(w/2,h/2)],0)]
            for i in range(8):
                y=-7+i*2
                out.append(('line',[(-w/2,y),(w/2-.7,y-.6)],0))
            return out
        if k=='relay':
            return [('rect',[(-w/2,-h/2),(w/2,h/2)],0),('rect',[(-3,-3),(-1,3)],0),('line',[(1,0),(3,-2.5)],0)]
        return [('rect',[(-w/2,-h/2),(w/2,h/2)],0)]

DEFS={}
def adddef(d):DEFS[d.name]=d;return d
for name,kind in [('R','r'),('C','c'),('CP','cp'),('L','l'),('D','d'),('Z','z'),('LED','led'),('Fuse','fuse'),('SW','sw'),('Crystal','xtal')]:
    adddef(Def(name,[Pin('1','1',-2,0,0),Pin('2','2',2,0,180)],2,2,kind))
adddef(Def('SW_JS102011',[Pin('1','THROW1',-2,0,0),Pin('2','COMMON',2,0,180),Pin('3','THROW2',-2,2,0)],2,4,'spdt'))
adddef(Def('NMOS',[Pin('1','G',-3,0,0,'input'),Pin('3','D',1,-3,270),Pin('2','S',1,3,90)],4,4,'nmos'))
adddef(Def('NPN',[Pin('1','B',-3,0,0,'input'),Pin('3','C',1,-3,270),Pin('2','E',1,3,90)],4,4,'npn'))
# Synchronous rectifier: actual eight terminals, no invented three-pin footprint.
adddef(Def('SRT15N110L',[Pin(str(i),'S',-4,-3+i*1,0) for i in (1,2,3)]+[Pin('4','G',-4,3,0,'input')]+[Pin(str(i),'D',4,-3+(i-5)*2,180) for i in (5,6,7,8)],6,9,'ic',source='https://www.power.com/sites/default/files/documents/DER-993_72W_12V6A_90-265VAC_Iso_Flyback_Appliance_InnoSwitch4-QR.pdf'))
adddef(Def('Flyback_DER993',[Pin('6','PRI+',-4,-5,0),Pin('5','PRI_DRAIN',-4,5,0),Pin('2','BIAS+',-4,9,0),Pin('3','BIAS_RTN',-4,13,0),Pin('FL1','SEC+',4,-5,180),Pin('FL2','SEC_SW',4,5,180)],6,18,'transformer'))
adddef(Def('Bridge_Z4DGP408L',[Pin('2','AC',-4,0,0),Pin('3','AC',4,0,180),Pin('1','+',0,-4,270),Pin('4','-',0,4,90)],6,6,'bridge'))
adddef(Def('LTV817',[Pin('1','A',-4,-2,0),Pin('2','K',-4,2,0),Pin('4','C',4,-2,180),Pin('3','E',4,2,180)],6,6,'opto'))
adddef(Def('DIP8',[Pin(str(i+1),str(i+1),-5,-7+i*2,0) for i in range(8)]+[Pin(str(16-i),str(16-i),5,-7+i*2,180) for i in range(8)],8,18,'dip'))
# Omron G5V-1 manufacturer bottom view: coil2/9, common5 AND6, NC1, NO10.
adddef(Def('G5V1',[Pin('2','COIL+',-5,-3,0),Pin('9','COIL-',-5,3,0),Pin('5','COM',5,0,180),Pin('1','NC',5,-3,180),Pin('6','COM',5,1.5,180),Pin('10','NO',5,3,180)],8,10,'relay'))

def ic(name,left,right,top=(),bottom=(),w=12,source='',fp=''):
    n=max(len(left),len(right),1);h=max(6,2*(n-1)+4)
    pins=[]
    for side,items in [('l',left),('r',right)]:
        for i,item in enumerate(items):
            num,nm,*typ=item
            pins.append(Pin(str(num),nm,(-w/2-1) if side=='l' else(w/2+1),-(len(items)-1)+2*i,0 if side=='l' else 180,typ[0] if typ else 'bidirectional'))
    for side,items in [('t',top),('b',bottom)]:
        for i,item in enumerate(items):
            num,nm,*typ=item
            pins.append(Pin(str(num),nm,-(len(items)-1)+2*i,(-h/2-1) if side=='t' else(h/2+1),270 if side=='t' else 90,typ[0] if typ else 'power_in'))
    return adddef(Def(name,pins,w,h,'ic',source,fp))

def conn(name,n,side='l',pitch=2,names=None,fp=''):
    pins=[Pin(str(i+1),names[i] if names else str(i+1),-3 if side=='l' else 3, -(n-1)*pitch/2+i*pitch,0 if side=='l' else 180) for i in range(n)]
    return adddef(Def(name,pins,3, max(4,(n-1)*pitch+2),'conn',fp=fp))
for n in [2,3,4,5,6,8,10,12,16,20]:
    for side in ['l','r']:conn(f'Conn{n}{side}',n,side)
PIMAP={1:'3V3',2:'5V',3:'GPIO2/SDA',4:'5V',5:'GPIO3/SCL',6:'GND',7:'GPIO4',8:'GPIO14/TX',9:'GND',10:'GPIO15/RX',11:'GPIO17',12:'GPIO18/I2S',13:'GPIO27',14:'GND',15:'GPIO22/RXEN',16:'GPIO23/TXEN',17:'3V3',18:'GPIO24',19:'GPIO10/MOSI',20:'GND',21:'GPIO9/MISO',22:'GPIO25',23:'GPIO11/SCK',24:'GPIO8/CE0',25:'GND',26:'GPIO7/CE1',27:'GPIO0/ID_SD',28:'GPIO1/ID_SC',29:'GPIO5/RST',30:'GND',31:'GPIO6/SHDN',32:'GPIO12/RES',33:'GPIO13/RES',34:'GND',35:'GPIO19/I2S',36:'GPIO16/HB',37:'GPIO26',38:'GPIO20/I2S',39:'GND',40:'GPIO21/I2S'}
for side in ['l','r']:conn(f'Pi40{side}',40,side,1.5,[PIMAP[i] for i in range(1,41)])

ic('TPS56637',[(8,'VIN','power_in'),(1,'EN','input'),(10,'MODE','input')],[(7,'BOOT','passive'),(6,'SW','power_out'),(4,'PG','open_collector'),(2,'FB','input'),(5,'NC','no_connect')],bottom=[(3,'AGND'),(9,'PGND')],w=11,source='https://www.ti.com/lit/ds/symlink/tps56637.pdf',fp='Package_DFN_QFN:Texas_RPA0010A')
ic('TPS259474L',[(5,'IN','power_in'),(1,'EN/UVLO','input'),(2,'OVLO','input'),(4,'PGTH','input')],[(6,'OUT','power_out'),(3,'PG','open_collector'),(9,'ILM','passive'),(10,'ITIMER','passive'),(7,'DVDT','passive')],bottom=[(8,'GND')],w=13,source='https://www.ti.com/lit/ds/symlink/tps25947.pdf',fp='Package_DFN_QFN:Texas_RPW0010A')
ic('AP6320x',[(3,'VIN','power_in'),(2,'EN','input')],[(6,'BST','passive'),(5,'SW','power_out'),(1,'FB','input')],bottom=[(4,'GND')],w=10,source='https://www.diodes.com/assets/Datasheets/AP63200-AP63201-AP63203-AP63205.pdf',fp='Package_TO_SOT_SMD:TSOT-23-6')
ic('INA226',[(10,'IN+','input'),(9,'IN-','input'),(8,'VBUS','input'),(2,'A0','input'),(1,'A1','input')],[(4,'SDA','bidirectional'),(5,'SCL','input'),(3,'ALERT','open_collector')],top=[(6,'VS')],bottom=[(7,'GND')],source='https://www.ti.com/lit/ds/symlink/ina226.pdf',fp='Package_SO:VSSOP-10_3x3mm_P0.5mm')
ic('TMP117',[(1,'SCL','input'),(4,'ADD0','input')],[(6,'SDA','bidirectional'),(3,'ALERT','open_collector')],top=[(5,'V+')],bottom=[(2,'GND'),(7,'EP')],w=10,source='https://www.ti.com/lit/ds/symlink/tmp117.pdf',fp='Package_DFN_QFN:WSON-6-1EP_2x2mm_P0.65mm_EP1x1.6mm')
ic('SHT45',[(1,'SDA','bidirectional'),(2,'SCL','input')],[],top=[(4,'VDD')],bottom=[(3,'VSS')],w=8,source='https://sensirion.com/products/catalog/SHT45',fp='Package_DFN_QFN:DFN-4-1EP_1.5x1.5mm_P0.8mm')
ic('ADS1115',[(4,'AIN0','input'),(5,'AIN1','input'),(6,'AIN2','input'),(7,'AIN3','input'),(1,'ADDR','input')],[(9,'SDA','bidirectional'),(10,'SCL','input'),(2,'ALERT/RDY','open_collector')],top=[(8,'VDD')],bottom=[(3,'GND')],source='https://www.ti.com/lit/ds/symlink/ads1115.pdf',fp='Package_SO:VSSOP-10_3x3mm_P0.5mm')
ic('TCA9548A',[(23,'SDA','bidirectional'),(22,'SCL','input'),(3,'nRESET','input'),(1,'A0','input'),(2,'A1','input'),(21,'A2','input')],[(4,'SD0'),(5,'SC0'),(6,'SD1'),(7,'SC1'),(8,'SD2'),(9,'SC2'),(10,'SD3'),(11,'SC3'),(13,'SD4'),(14,'SC4'),(15,'SD5'),(16,'SC5'),(17,'SD6'),(18,'SC6'),(19,'SD7'),(20,'SC7')],top=[(24,'VCC')],bottom=[(12,'GND')],w=14,source='https://www.ti.com/lit/ds/symlink/tca9548a.pdf',fp='Package_SO:TSSOP-24_4.4x7.8mm_P0.65mm')
ic('MCP23017',[(12,'SCL','input'),(13,'SDA'),(18,'nRESET','input'),(15,'A0','input'),(16,'A1','input'),(17,'A2','input'),(20,'INTA','open_collector'),(19,'INTB','open_collector'),(11,'NC','no_connect'),(14,'NC','no_connect')],[(21+i,f'GPA{i}') for i in range(8)]+[(1+i,f'GPB{i}') for i in range(8)],top=[(9,'VDD')],bottom=[(10,'VSS')],w=14,source='https://ww1.microchip.com/downloads/en/DeviceDoc/20001952C.pdf',fp='Package_SO:SSOP-28_5.3x10.2mm_P0.65mm')
ic('STM32F103CB',[(5,'OSC_IN','input'),(6,'OSC_OUT','output'),(7,'nRST','bidirectional'),(44,'BOOT0','input'),(20,'PB2/BOOT1'),(34,'PA13/SWDIO'),(37,'PA14/SWCLK'),(32,'PA11/USB_DM'),(33,'PA12/USB_DP'),(29,'PA8'),(45,'PB8'),(10,'PA0'),(11,'PA1'),(2,'PC13'),(3,'PC14'),(4,'PC15'),(8,'VSSA','power_in')],[(30,'PA9/U1_TX'),(31,'PA10/U1_RX'),(12,'PA2/U2_TX'),(13,'PA3/U2_RX'),(21,'PB10/U3_TX'),(22,'PB11/U3_RX'),(25,'PB12/RS_DE'),(42,'PB6/I2C_SCL'),(43,'PB7/I2C_SDA'),(14,'PA4/SPI_CS'),(15,'PA5/SPI_SCK'),(16,'PA6/SPI_MISO'),(17,'PA7/SPI_MOSI'),(18,'PB0/BL_PWM'),(19,'PB1/LCD_RST'),(26,'PB13/TOUCH_CS'),(27,'PB14/TOUCH_IRQ'),(39,'PB3/FAN_B_TACH'),(40,'PB4/SHDN_B'),(41,'PB5/RF_A'),(38,'PA15/SHDN_A'),(28,'PB15/RF_B'),(46,'PB9/PWR_B')],top=[(1,'VBAT'),(9,'VDDA'),(24,'VDD'),(36,'VDD'),(48,'VDD')],bottom=[(23,'VSS'),(35,'VSS'),(47,'VSS')],w=22,source='https://www.st.com/resource/en/datasheet/stm32f103cb.pdf',fp='Package_QFP:LQFP-48_7x7mm_P0.5mm')
ic('TPS3828',[(3,'nMR','input'),(4,'WDI','input')],[(1,'nRESET','open_collector')],top=[(5,'VDD')],bottom=[(2,'GND')],w=9,source='https://www.ti.com/lit/ds/symlink/tps3823.pdf',fp='Package_TO_SOT_SMD:SOT-23-5')
for nm in ['SN74LVC1G125','SN74LVC1G32','SN74LVC1G08']:
    names=[(1,'nOE','input'),(2,'A','input')] if nm.endswith('125') else[(1,'A','input'),(2,'B','input')]
    ic(nm,names,[(4,'Y','output')],top=[(5,'VCC')],bottom=[(3,'GND')],w=7,source='https://www.ti.com/lit/ds/symlink/'+nm.lower()+'.pdf',fp='Package_TO_SOT_SMD:SOT-23-5')
ic('TSC2046',[(2,'X+','bidirectional'),(3,'Y+','bidirectional'),(4,'X-','bidirectional'),(5,'Y-','bidirectional'),(7,'VBAT','input'),(8,'AUX','input'),(9,'VREF','passive')],[(16,'DCLK','input'),(15,'nCS','input'),(14,'DIN','input'),(12,'DOUT','tri_state'),(13,'BUSY','tri_state'),(11,'nPENIRQ','open_collector')],top=[(1,'VCC'),(10,'IOVDD')],bottom=[(6,'GND')],w=13,source='https://www.ti.com/lit/ds/symlink/tsc2046.pdf',fp='Package_SO:TSSOP-16_4.4x5mm_P0.65mm')
ic('THVD1450',[(1,'RO','output'),(2,'nRE','input'),(3,'DE','input'),(4,'DI','input')],[(6,'A','bidirectional'),(7,'B','bidirectional')],top=[(8,'VCC')],bottom=[(5,'GND')],w=10,source='https://www.ti.com/lit/ds/symlink/thvd1450.pdf',fp='Package_SO:SOIC-8_3.9x4.9mm_P1.27mm')
ic('INN4275C',[(24,'DRAIN','passive'),(13,'V','input'),(14,'BPP','passive'),(15,'HSD','power_in'),(16,'SOURCE','power_in'),(17,'SOURCE','power_in'),(18,'SOURCE','power_in'),(19,'SOURCE','power_in')],[(7,'FWD','input'),(5,'SR','output'),(6,'VOUT','power_in'),(4,'BPS','passive'),(3,'FB','input'),(1,'ISENSE','input'),(2,'SEC_GND','power_in')]+[(i,'NC','no_connect') for i in range(8,13)],w=18,source='https://www.power.com/sites/default/files/documents/innoswitch4-qr_family_data_sheet_20250630.pdf?language=en',fp='Package_SO:PowerIntegrations_InSOP-24D')
# 4-pin common-mode choke with winding polarity marked in symbol.
ic('CMC18mH',[(1,'L_IN'),(3,'N_IN')],[(2,'L_OUT'),(4,'N_OUT')],w=8)

ALLS=[]; ALLC=[]
class Sheet:
 def __init__(self,name,title,paper='A3',notes=()):
    self.name=name;self.title=title;self.id=uid(name);self.paper=paper
    self.size=(165.354,116.929) if paper=='A3' else(233.858,165.354)
    self.comps=[];self.wires=[];self.labels=[];self.ncs=[];self.notes=[];self.junc=[];self.seq=0
    ALLS.append(self)
    self.text(6,8,title,1.8)
    for i,t in enumerate(notes):self.text(6,12+i*1.8,t,.64)
 def text(self,x,y,t,size=.64):self.notes.append((x,y,str(t),max(size,.60)))
 def comp(self,ref,kind,val,x,y,nets,rot=0,mpn='',fp='',source='',note=''):
    assert not any(c.ref==ref for c in ALLC),ref
    d=DEFS[kind]; c=Component(ref,d,val,x,y,nets,rot,mpn,fp or d.fp,source or d.source,note,self)
    self.comps.append(c);ALLC.append(c);return c
 def wire(self,a,b,net=''):
    if a==b:return
    assert a[0]==b[0] or a[1]==b[1],(a,b)
    self.wires.append((a,b,net))
 def chain(self,*pts,net=''):
    for a,b in zip(pts,pts[1:]):self.wire(a,b,net)
 def dot(self,p):
    if p not in self.junc:self.junc.append(p)
 def label(self,p,net,angle=0):
    if not any(z[0]==p and z[1]==net for z in self.labels):self.labels.append((p,net,angle))
 def pin(self,c,n):return c.pos(str(n))
 def stub(self,c,n,net=None,L=3):
    n=str(n);p=c.pos(n);pn=next(pn for pn in c.d.pins if pn.num==n)
    net=c.nets.get(n) if net is None else net
    if net is None:self.ncs.append(p);c.connected.add(n);return p
    ang=(pn.orient+c.rot)%360
    vec={0:(-1,0),90:(0,1),180:(1,0),270:(0,-1)}[ang]
    end=(p[0]+L*vec[0],p[1]+L*vec[1]);self.wire(p,end,net)
    # Labels point left on wires leaving a symbol to the left and right on the right.
    self.label(end,net,180 if vec[0]<0 else 90 if vec[1]<0 else 270 if vec[1]>0 else 0)
    c.connected.add(n);return end
 def auto(self,c,omit=()):
    for p in c.d.pins:
        if p.num not in c.connected and p.num not in omit:self.stub(c,p.num)
 def link(self,c,n,d,m,via=()):
    n=str(n);m=str(m);assert c.nets.get(n)==d.nets.get(m),(c.ref,n,d.ref,m)
    a=c.pos(n);b=d.pos(m);pts=[a]+list(via)+[b]
    if not via and a[0]!=b[0] and a[1]!=b[1]:pts=[a,(b[0],a[1]),b]
    self.chain(*pts,net=c.nets[n]);c.connected.add(n);d.connected.add(m)
 def finish(self):
    for c in self.comps:self.auto(c)
 def sx(self):
    head=[f'(kicad_sch (version 20231120) (generator "netcore_tetra") (uuid {qs(self.id)}) (paper {qs(self.paper)})',
        f'(title_block (title {qs(self.title)}) (date "2026-09-18") (rev "0.2 REVIEW") (company "NetCore-Tetra") (comment 1 "Component-level engineering draft; NO production or mains safety approval"))',
        '(lib_symbols']
    for name in sorted(set(c.d.name for c in self.comps)):head.append(DEFS[name].sx())
    head.append(')')
    for i,(a,b,net) in enumerate(self.wires):
        head.append(f'(wire (pts (xy {f(a[0])} {f(a[1])}) (xy {f(b[0])} {f(b[1])})) (stroke (width 0) (type default)) (uuid {qs(uid(self.name+"wire"+str(i)))}))')
    for i,(p,net,angle) in enumerate(self.labels):
        # Global labels connect independent sheets of this project; labels are real electrical labels.
        head.append(f'(global_label {qs(net)} (shape bidirectional) (at {f(p[0])} {f(p[1])} {angle}) {ef(.37,"left")} (uuid {qs(uid(self.name+"label"+str(i)))}) (property "Intersheetrefs" "${{INTERSHEET_REFS}}" (at {f(p[0])} {f(p[1])} {angle}) (effects (font (size 0.762 0.762)) hide)))')
    for i,p in enumerate(self.ncs):head.append(f'(no_connect (at {f(p[0])} {f(p[1])}) (uuid {qs(uid(self.name+"nc"+str(i)))}))')
    for i,p in enumerate(self.junc):head.append(f'(junction (at {f(p[0])} {f(p[1])}) (diameter 0) (color 0 0 0 0) (uuid {qs(uid(self.name+"j"+str(i)))}))')
    for i,(x,y,t,sz) in enumerate(self.notes):head.append(f'(text {qs(t)} (at {f(x)} {f(y)} 0) {ef(sz,"left")} (uuid {qs(uid(self.name+"text"+str(i)))}))')
    for c in self.comps:head.append(c.sx())
    head.append(')');return '\n'.join(head)

@dataclass
class Component:
 ref:str;d:Def;value:str;x:float;y:float;nets:dict;rot:int;mpn:str;fp:str;source:str;note:str;sheet:Sheet
 connected:set=field(default_factory=set)
 def __post_init__(self):
    self.nets={str(k):v for k,v in self.nets.items()}
    pnums={p.num for p in self.d.pins}
    assert set(self.nets)<=pnums,(self.ref,set(self.nets)-pnums)
    for p in self.d.pins:self.nets.setdefault(p.num,None)
 def xy(self,x,y):
    a=math.radians(self.rot);return(round(self.x+x*math.cos(a)+y*math.sin(a),5),round(self.y-x*math.sin(a)+y*math.cos(a),5))
 def pos(self,n):p=next(p for p in self.d.pins if p.num==str(n));return self.xy(p.x,p.y)
 def fieldpositions(self):
    if self.d.kind in ['r','c','cp','d','z','led','l','fuse','sw','xtal']:
        if self.rot in [90,270]:return(self.x+1.7,self.y-.4,self.x+1.7,self.y+1.1,'left')
        return(self.x,self.y-2.4,self.x,self.y-1.2,'')
    if self.d.kind in ['nmos','npn']:return(self.x+2,self.y-3,self.x+2,self.y-1.7,'left')
    return(self.x,self.y-self.d.h/2-3,self.x,self.y-self.d.h/2-1.7,'')
 def sx(self):
    cid=uid(self.ref);x,y,xx,yy,j=self.fieldpositions()
    out=[f'(symbol (lib_id {qs(LIB+":"+self.d.name)}) (at {f(self.x)} {f(self.y)} {self.rot}) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {qs(cid)})',
     f'(property "Reference" {qs(self.ref)} (at {f(x)} {f(y)} 0) {ef(.43,j)})',
     f'(property "Value" {qs(self.value)} (at {f(xx)} {f(yy)} 0) {ef(.4,j)})']
    for k,v in [('Footprint',self.fp),('Datasheet',self.source),('MPN',self.mpn),('EngineeringNote',self.note)]:out.append(f'(property {qs(k)} {qs(v)} (at {f(self.x)} {f(self.y)} 0) (effects (font (size 1.016 1.016)) hide))')
    for p in self.d.pins:out.append(f'(pin {qs(p.num)} (uuid {qs(uid(self.ref+":"+p.num))}))')
    out.append(f'(instances (project {qs(PROJECT)} (path {qs("/"+ROOTID+"/"+uid(self.sheet.name+"instance"))} (reference {qs(self.ref)}) (unit 1)))))')
    return '\n'.join(out)

# Basic parts carry real electrical values and an explicit package, not unnamed functional blocks.
COUNTS=collections.Counter()
def ref(s,p):COUNTS[(s.name,p)]+=1;return f'{p}{(ALLS.index(s)+1)*100+COUNTS[(s.name,p)]}'
def passive(s,kind,val,x,y,a,b,vertical=False,mpn='',note='',fp=''):
    prefix={'R':'R','C':'C','CP':'C','L':'L','D':'D','Z':'D','LED':'D','Fuse':'F','SW':'SW','Crystal':'Y'}[kind]
    if not fp:
        fp={'R':'Resistor_SMD:R_0603_1608Metric','C':'Capacitor_SMD:C_0603_1608Metric','CP':'Capacitor_THT:CP_Radial_D8.0mm_P3.50mm','L':'Inductor_SMD:L_Coilcraft_XAL5030','D':'Diode_SMD:D_SOD-123','Z':'Diode_SMD:D_SOD-123','LED':'LED_SMD:LED_0603_1608Metric','Fuse':'Fuse:Fuseholder_5x20mm','SW':'Button_Switch_SMD:SW_SPST_TL3342','Crystal':'Crystal:Crystal_SMD_3225-4Pin_3.2x2.5mm'}[kind]
    return s.comp(ref(s,prefix),kind,val,x,y,{'1':a,'2':b},270 if vertical else 0,mpn,fp,note=note)
def R(s,val,x,y,a,b,v=False,**kw):return passive(s,'R',val,x,y,a,b,v,**kw)
def C(s,val,x,y,a,b='GND',v=True,**kw):return passive(s,'C',val,x,y,a,b,v,**kw)
def CP(s,val,x,y,a,b='GND',v=True,**kw):return passive(s,'CP',val,x,y,a,b,v,**kw)
def D(s,val,x,y,a,k,v=False,**kw):return passive(s,'D',val,x,y,a,k,v,**kw)
def Q(s,x,y,g,d,src='GND',val='2N7002',**kw):return s.comp(ref(s,'Q'),'NMOS',val,x,y,{'1':g,'3':d,'2':src},mpn=val,fp='Package_TO_SOT_SMD:SOT-23',**kw)
def J(s,val,x,y,nets,side='l',mpn='',note='',fp=''):
    return s.comp(ref(s,'J'),f'Conn{len(nets)}{side}',val,x,y,{str(i+1):n for i,n in enumerate(nets)},mpn=mpn,fp=fp or f'Connector_PinHeader_2.54mm:PinHeader_1x{len(nets):02d}_P2.54mm_Vertical',note=note)
def U(s,kind,val,x,y,nets,mpn='',note=''):
    prefix={'Flyback_DER993':'T','CMC18mH':'L','Bridge_Z4DGP408L':'BR','G5V1':'K','PNP3906':'Q','SRT15N110L':'Q','SM712':'D'}.get(kind,'U')
    return s.comp(ref(s,prefix),kind,val,x,y,nets,mpn=mpn or val,note=note)
def pull(s,net,x,y,supply='3V3_AON',val='10k 1%'):return R(s,val,x,y,supply,net,True)
def dec(s,x,y,net='3V3_AON',gnd='GND',val='100n 16V X7R'):return C(s,val,x,y,net,gnd)

# Correct physical diode pin numbering: cathode 1, anode 2.
for dn in ('D','Z','LED'):
    DEFS[dn].pins=[Pin('2','A',-2,0,0),Pin('1','K',2,0,180)]
_oldpassive=passive
def passive(s,kind,val,x,y,a,b,vertical=False,mpn='',note='',fp=''):
    c=_oldpassive(s,kind,val,x,y,a,b,vertical,mpn,note,fp)
    if kind in ('D','Z','LED'):c.nets={'2':a,'1':b}
    if kind=='Crystal':c.nets={'1':a,'3':b,'2':'GND','4':'GND'}
    return c
# SHT4x bare IC, not the differently numbered four-wire evaluation cable.
for p in DEFS['SHT45'].pins:
    if p.name=='VDD':p.num='3'
    if p.name=='VSS':p.num='4'
# No unverified footprint references: a package specification is not a CAD footprint.
for dn in ('TPS56637','TPS259474L','INN4275C','SHT45','TMP117'):
    DEFS[dn].extra['package_spec']=DEFS[dn].fp
    DEFS[dn].fp=''

# Transformer intermediate primary termination exists on bobbin pin4, not an external load.
DEFS['Flyback_DER993'].pins += [Pin('4','PRI_MID',-4,0,0),Pin('1','UNUSED',-4,16,0,'no_connect')]
DEFS['Flyback_DER993'].h=34
# Crystal physical pads: 1/3 resonator, 2/4 case ground.
DEFS['Crystal'].pins=[Pin('1','X1',-2,0,0),Pin('3','X2',2,0,180),Pin('2','CASE',0,-3,270),Pin('4','CASE',0,3,90)]
# ---------- Discrete mains converter ----------
s=Sheet('01_ACDC_DISCRETE','01 | 230 VAC -> isolated 12 V / 6 A: discrete flyback','A2',[
 'Engineering reconstruction from PI DER-993 and InnoSwitch4-QR Fig. 9; NOT an electrically validated copy.',
 'DANGER: primary nets MAINS_* / HV_* / PRI_* are live. No PCB, enclosure, insulation or safety release.',
 'T101 is a specified custom magnetic component, not an AC/DC module. See docs/TRANSFORMER_SPEC.md.'])
j=J(s,'MAINS L / N / PE',12,31,['MAINS_L','MAINS_N','PE_CHASSIS'],'r',note='Mains terminal: Phoenix MKDS 1.5/3-7.62; enclosure/chassis bonding independently assessed',fp='')
fuse=passive(s,'Fuse','T3.15A 250VAC',30,29,'MAINS_L','MAINS_L_FUSED',mpn='Bel RST 3.15-BULK',fp='')
s.link(j,1,fuse,1,via=[(24,29)])
cx=C(s,'330n X2 275VAC',39,35,'MAINS_L_FUSED','MAINS_N',mpn='890324024003CS',fp='Capacitor_THT:C_Rect_L18.0mm_W8.0mm_P15.00mm')
r1=R(s,'2M 0.25W',49,32,'MAINS_L_FUSED','X_BLEED_MID',True,mpn='RC1206JR-072ML',fp='Resistor_SMD:R_1206_3216Metric')
r2=R(s,'2M 0.25W',49,40,'X_BLEED_MID','MAINS_N',True,mpn='RC1206JR-072ML',fp='Resistor_SMD:R_1206_3216Metric');s.link(r1,2,r2,1)
cm=U(s,'CMC18mH','Sumida 04291-T231 / 18mH',66,32,{1:'MAINS_L_FUSED',2:'MAINS_L_FILTER',3:'MAINS_N',4:'MAINS_N_FILTER'},note='Custom choke winding/pin polarity must follow manufacturer reference; see magnetics spec')
b1=U(s,'Bridge_Z4DGP408L','Z4DGP408L-HF',85,29,{1:'HV_RAW_P',2:'MAINS_L_FILTER',3:'MAINS_N_FILTER',4:'HV_NEG'},note='Bridge terminal convention 1=+,2/3=AC,4=- needs exact Z4-D footprint check')
b2=U(s,'Bridge_Z4DGP408L','Z4DGP408L-HF',85,47,{1:'HV_RAW_P',2:'MAINS_L_FILTER',3:'MAINS_N_FILTER',4:'HV_NEG'})
c1=CP(s,'68u 400V',99,38,'HV_RAW_P','HV_NEG',mpn='ERK2GM680K30OT13x30',fp='')
l=passive(s,'L','12uH / 5.1A',111,25,'HV_RAW_P','HV_BUS',mpn='RFB1010-120L',fp='')
c2=CP(s,'100u 400V',121,38,'HV_BUS','HV_NEG',mpn='400BXW100MEFR16X30',fp='')
t=U(s,'Flyback_DER993','DER993 T1 / 519uH',148,37,{6:'HV_BUS',5:'PRI_DRAIN',2:'PRI_AUX_AC',3:'HV_NEG','FL1':'SEC_PREL','FL2':'SEC_SW'},mpn='CUSTOM-DER993-T1',note='42:5:8 turns; exact winding, gap and insulation specification in docs; vendor review required')
# R2CD clamp. R4/R5 parallel damping; D1 anode at drain.
dcl=D(s,'S1MLHRVG',134,59,'PRI_DRAIN','CLAMP_DIODE',mpn='S1MLHRVG',fp='')
rr1=R(s,'20R 0.67W',140,66,'CLAMP_DIODE','PRI_CLAMP',True,mpn='ERJ-P08J200V',fp='Resistor_SMD:R_1206_3216Metric')
rr2=R(s,'20R 0.67W',148,66,'CLAMP_DIODE','PRI_CLAMP',True,mpn='ERJ-P08J200V',fp='Resistor_SMD:R_1206_3216Metric')
cr=C(s,'1n 500V',135,79,'PRI_CLAMP','HV_BUS',mpn='CC1206KKX7RBBB102',fp='Capacitor_SMD:C_1206_3216Metric')
rc=R(s,'470k 0.67W',149,79,'PRI_CLAMP','HV_BUS',True,mpn='ERJ-P08J474V',fp='Resistor_SMD:R_1206_3216Metric')
inn=U(s,'INN4275C','INN4275C-H186',140,113,{24:'PRI_DRAIN',13:'PRI_LINE_SENSE',14:'PRI_BPP',15:'HV_NEG',16:'HV_NEG',17:'HV_NEG',18:'HV_NEG',19:'HV_NEG',7:'SEC_FWD',5:'SEC_GATE',6:'AC_12V',4:'SEC_BPS',3:'SEC_FB',1:'SEC_IS',2:'SEC_GND'})
for i,(x,a,b,val) in enumerate([(92,'HV_BUS','LINE_SENSE_1','1M 1%'),(102,'LINE_SENSE_1','LINE_SENSE_2','1.2M 1%'),(112,'LINE_SENSE_2','PRI_LINE_SENSE','1.2M 1%')]):R(s,val,x,102,a,b,mpn=['ERJ-8ENF1004V','ERJ-8ENF1204V','ERJ-8ENF1204V'][i],fp='Resistor_SMD:R_1206_3216Metric')
db=D(s,'S1MLHRVG',48,66,'PRI_AUX_AC','PRI_BIAS',mpn='S1MLHRVG',fp='')
cb=CP(s,'22u 50V',60,78,'PRI_BIAS','HV_NEG',mpn='UPW1H220MDD',fp='')
rp=R(s,'11k 1%',75,66,'PRI_BIAS','PRI_BPP',mpn='ERJ-3EKF1102V')
zd=passive(s,'Z','18V 0.5W',70,87,'PRI_OVP_I','PRI_BIAS',mpn='MMSZ5248B-7-F',fp='Diode_SMD:D_SOD-123')
ro=R(s,'309R 1%',85,87,'PRI_OVP_I','PRI_BPP',mpn='ERJ-3EKF3090V');s.link(zd,2,ro,1,via=[(65,87),(65,95),(80,95),(80,87)])
cbpp=C(s,'4.7u 16V X7R',99,88,'PRI_BPP','HV_NEG',mpn='CL21B475KOFNNNE',fp='Capacitor_SMD:C_0805_2012Metric')
# Secondary low-side synchronous rectification.
for x in (173,190):U(s,'SRT15N110L','SRT15N110L',x,65,{1:'SEC_GND',2:'SEC_GND',3:'SEC_GND',4:'SEC_GATE',5:'SEC_SW',6:'SEC_SW',7:'SEC_SW',8:'SEC_SW'})
cpre=CP(s,'820u 16V polymer',174,39,'SEC_PREL','SEC_GND',mpn='PLG1C821MDO1',fp='')
lo=passive(s,'L','1uH / 10A',193,25,'SEC_PREL','AC_12V',mpn='6000-1R0M-RC',fp='')
co=CP(s,'820u 16V polymer',212,39,'AC_12V','GND',mpn='PLG1C821MDO1',fp='')
J(s,'12V / 6A TEST',224,28,['AC_12V','GND'],mpn='Phoenix MKDS 1.5/2-5.08',fp='',note='Test/output terminals, not a power-supply module')
# RC + diode snubber: diode bypasses resistor while snubber cap charges from positive drain edge.
cs=C(s,'2.2n 200V',204,65,'SEC_SW','SEC_SNUB',mpn='08052C222KAT2A',fp='Capacitor_SMD:C_0805_2012Metric')
rs=R(s,'5.1R 0.125W',212,76,'SEC_SNUB','SEC_GND',True,mpn='ERJ-6GEYJ5R1V',fp='Resistor_SMD:R_0805_2012Metric')
ds=D(s,'UFM13PL-TP',222,76,'SEC_SNUB','SEC_GND',True,mpn='UFM13PL-TP')
r8=R(s,'300R',175,88,'SEC_SW','SEC_FWD',mpn='ERJ-3GEYJ301V')
C(s,'2.2u 25V',173,107,'SEC_BPS','SEC_GND',mpn='C2012X7R1E225K125AB',fp='Capacitor_SMD:C_0805_2012Metric')
R(s,'11m 1W',186,120,'GND','SEC_GND',True,mpn='ERJ-8CWFR011V',fp='Resistor_SMD:R_1206_3216Metric')
R(s,'11m 1W',197,120,'GND','SEC_GND',True,mpn='ERJ-8CWFR011V',fp='Resistor_SMD:R_1206_3216Metric')
R(s,'10R 1%',178,135,'GND','SEC_IS',mpn='ERJ-6ENF10R0V',fp='Resistor_SMD:R_0805_2012Metric')
C(s,'4.7u 10V',166,140,'SEC_IS','SEC_GND',mpn='LMK212B7475KGHT',fp='Capacitor_SMD:C_0805_2012Metric')
R(s,'100k 1%',210,100,'AC_12V','SEC_FB',True,mpn='ERJ-3EKF1003V')
R(s,'11.8k 1%',210,115,'SEC_FB','SEC_GND',True,mpn='ERJ-3EKF1182V')
C(s,'330p C0G',223,115,'SEC_FB','SEC_GND',mpn='C0603C331J5GACAUTO')
C(s,'2.2n safety Y',54,122,'HV_NEG','GND',False,mpn='AY1222M47Y5UC63L0',fp='',note='Use exact safety-rated part and insulation category; never ordinary ceramic')
s.text(9,140,'No metallic connection from HV_NEG to GND or PE. Y capacitor is NOT a protective-earth conductor.',.5)
s.text(9,144,'Primary clamp, SR snubber and winding phase are mandatory comparison points against the original PDF drawing.',.5)
s.text(9,148,'72 W is the reference supply rating, not a demonstrated rating of this new baseboard.',.5)
s.text(9,152,'No PFC added. EMI / leakage / dielectric / abnormal-condition testing must be repeated for the combined board.',.5)

# ---------- DC selection, bus and auxiliary rails ----------
s=Sheet('02_DC_AUX','02 | 12 V source selection, bus monitoring and always-on rails',notes=[
 'Only regulated 12 VDC (nominal +/-5%). Not a direct vehicle supply. AC/DC input paths diode-ORed.',
 'Pi A and Pi B get independent 5 V rails. 3V3_AON is never tied to either Pi 3V3 rail.'])
j=J(s,'12VDC INPUT',10,25,['DC_EXT_P','GND'],'r',mpn='Phoenix MKDS 1.5/2-5.08',fp='')
f1=passive(s,'Fuse','T7.5A DC',26,24,'DC_EXT_P','DC_EXT_F',mpn='Littelfuse 045107.5MRL',fp='Fuse:Fuse_2410_6125Metric');s.link(j,1,f1,1,via=[(18,24)])
D(s,'STPS10L60D',42,24,'DC_EXT_F','BUS_OR',mpn='STPS10L60D',fp='',note='10A Schottky; ST drawing: pin1 cathode, pin2 anode, tab=cathode. Heatsink/thermal verification required.')
D(s,'STPS10L60D',42,39,'AC_12V','BUS_OR',mpn='STPS10L60D',fp='')
passive(s,'Z','SMBJ13A',58,37,'GND','BUS_OR',True,mpn='SMBJ13A',fp='Diode_SMD:D_SMB')
CP(s,'470u 25V low ESR',72,37,'BUS_OR',mpn='Panasonic EEU-FR1E471',fp='')
sh=R(s,'2m 1% 2W',84,24,'BUS_OR','BUS_12V',mpn='WSLP2512R0020FEA',fp='Resistor_SMD:R_2512_6332Metric',note='Kelvin sense route at resistor lands')
ina=U(s,'INA226','INA226AIDGSR / 0x40',112,36,{10:'BUS_SENSE_P',9:'BUS_SENSE_N',8:'BUS_12V',2:'GND',1:'GND',4:'SYS_SDA',5:'SYS_SCL',3:'BUS_ALERT_N',6:'3V3_AON',7:'GND'})
R(s,'10R 1%',87,44,'BUS_OR','BUS_SENSE_P');R(s,'10R 1%',87,54,'BUS_12V','BUS_SENSE_N')
C(s,'100n 16V',98,65,'BUS_SENSE_P','BUS_SENSE_N');dec(s,136,30);pull(s,'BUS_ALERT_N',144,43)
# Exact fixed-voltage buck ICs and every external power component, not regulator modules.
for rail,x in [('3V3_AON',36),('5V_AUX',115)]:
    typ='AP63203WU-7' if rail=='3V3_AON' else'AP63205WU-7'
    pre=rail+'_SW';boot=rail+'_BST'
    u=U(s,'AP6320x',typ,x,86,{3:'BUS_12V',2:'BUS_12V',6:boot,5:pre,1:rail,4:'GND'})
    dec(s,x-20,88,'BUS_12V',val='10u 50V X7R');dec(s,x-30,88,'BUS_12V')
    cb=C(s,'100n 16V',x+13,74,boot,pre,False)
    ind=passive(s,'L','4.7uH / 3A',x+22,86,pre,rail,mpn='SRN5040TA-4R7M',fp='')
    c1=C(s,'22u 16V X7R',x+34,90,rail,fp='Capacitor_SMD:C_1210_3225Metric')
    c2=C(s,'22u 16V X7R',x+43,90,rail,fp='Capacitor_SMD:C_1210_3225Metric')
    s.link(u,5,ind,1)
    s.chain(ind.pos('2'),(x+34,86),c1.pos('1'),net=rail);ind.connected.add('2');c1.connected.add('1')
    s.chain((x+34,86),(x+43,86),c2.pos('1'),net=rail);c2.connected.add('1');s.dot((x+34,86))
s.text(7,107,'Auxiliary rail budget: TFT backlight <=125 mA at 5 V; supervisor/sensors <=500 mA at 3.3 V (design allocation).')

# ---------- One completely populated supply per node ----------
def node_power(node):
 s=Sheet(f'03_POWER_{node}',f'03{node} | Node {node}: 5.15 V buck, eFuse and Kelvin measurement',notes=[
  'TPS56637 6 A converter; TPS259474L circuit-breaker switch. Operating target <=4.5 A continuous per complete Pi/SDR stack.',
  '5.15 V nominal before protection drop. Actual Pi voltage, startup/inrush and thermal margins must be measured.'])
 pre=f'{node}_5V_REG';sw=f'{node}_BUCK_SW';bt=f'{node}_BOOT';fb=f'{node}_FB';en=f'{node}_PWR_EN'
 u=U(s,'TPS56637','TPS56637RPAR',36,38,{8:'BUS_12V',1:'BUCK_EN_12',10:None,7:bt,6:sw,4:f'{node}_BUCK_PG',2:fb,5:None,3:'GND',9:'GND'})
 # Common enable is derived locally, no MCU dependency for regulation; power switch controls the Pi.
 R(s,'100k 1%',13,31,'BUS_12V',f'{node}_BUCK_EN',True)
 R(s,'33k 1%',13,44,f'{node}_BUCK_EN','GND',True)
 u.nets['1']=f'{node}_BUCK_EN'
 dec(s,23,28,'BUS_12V',val='10u 50V X7R');dec(s,23,51,'BUS_12V',val='10u 50V X7R');dec(s,12,57,'BUS_12V')
 cb=C(s,'100n 16V',53,25,bt,sw,False)
 l=passive(s,'L','3.3uH Isat>=10A',63,36,sw,pre,mpn='Coilcraft XAL5030-332MEC',fp='')
 s.link(u,6,l,1,via=[(52,36)])
 c1=C(s,'22u 16V X7R',73,45,pre,fp='Capacitor_SMD:C_1210_3225Metric')
 c2=C(s,'22u 16V X7R',83,45,pre,fp='Capacitor_SMD:C_1210_3225Metric')
 s.chain(l.pos('2'),(73,36),c1.pos('1'),net=pre);l.connected.add('2');c1.connected.add('1')
 s.chain((73,36),(83,36),c2.pos('1'),net=pre);c2.connected.add('1');s.dot((73,36))
 R(s,'49.9R 1%',55,51,pre,f'{node}_FB_TOP')
 R(s,'75.8k 0.1%',62,61,f'{node}_FB_TOP',fb,True)
 R(s,'10k 0.1%',62,73,fb,'GND',True)
 R(s,'20k 1%',81,59,f'{node}_FB_TOP',f'{node}_FF',True)
 C(s,'100p C0G',81,71,f'{node}_FF',fb)
 pull(s,f'{node}_BUCK_PG',42,64)
 # Switch controls startup; current threshold approx 5.52 A nominal, lower tolerance ~4.97 A.
 efu=U(s,'TPS259474L','TPS259474LRPWR',115,39,{5:pre,1:en,2:f'{node}_OVLO',4:f'{node}_PGTH',6:f'{node}_5V_EF',3:f'{node}_5V_PG',9:f'{node}_ILM',10:f'{node}_ITIMER',7:f'{node}_DVDT',8:'GND'})
 R(s,'100k',95,26,en,'GND',True)
 R(s,'34.8k 0.1%',96,45,pre,f'{node}_OVLO',True);R(s,'10k 0.1%',96,56,f'{node}_OVLO','GND',True)
 R(s,'28.7k 0.1%',108,69,f'{node}_5V_EF',f'{node}_PGTH',True);R(s,'10k 0.1%',108,82,f'{node}_PGTH','GND',True)
 R(s,'604R 1%',137,50,f'{node}_ILM','GND',True)
 C(s,'10n 50V X7R',148,61,f'{node}_DVDT');C(s,'10n 16V X7R',135,72,f'{node}_ITIMER')
 pull(s,f'{node}_5V_PG',147,30)
 sh=R(s,'2m 1% 2W',137,20,f'{node}_5V_EF',f'{node}_5V',mpn='WSLP2512R0020FEA',fp='Resistor_SMD:R_2512_6332Metric')
 CP(s,'220u 10V low ESR',150,87,f'{node}_5V',mpn='EEU-FR1A221',fp='')
 R(s,'1k 0.125W',137,88,f'{node}_5V','GND',True)
 # measurement block moved to dedicated lower-left zone
 ina=U(s,'INA226',f'INA226AIDGSR / {node} 0x40',32,89,{10:f'{node}_SENSE_P',9:f'{node}_SENSE_N',8:f'{node}_5V',2:'GND',1:'GND',4:f'SENS_{node}_SDA',5:f'SENS_{node}_SCL',3:f'{node}_CURRENT_ALERT_N',6:'3V3_AON',7:'GND'})
 R(s,'10R',10,83,f'{node}_5V_EF',f'{node}_SENSE_P');R(s,'10R',10,93,f'{node}_5V',f'{node}_SENSE_N')
 C(s,'100n',54,93,f'{node}_SENSE_P',f'{node}_SENSE_N');dec(s,42,78)
 pull(s,f'{node}_CURRENT_ALERT_N',68,92)
 s.text(7,107,'MODE open = FCCM. OVLO nominal ~5.38 V; this is fault cutoff, NOT a precision 5.25 V clamp. USB-C must not also power the Pi.')
 return s
node_power('A');node_power('B')

# ---------- 40 actual pass-through wires, plus separate supervisor interface ----------
PI_CONNS={}
def pi_node(node):
 s=Sheet(f'04_PI_{node}',f'04{node} | Pi {node} <-> SXceiver {node}: physical 40-pin wiring','A2',[
 'Assumption: SXceiver HW v1.2. BCM numbering shown; both A/B headers use the same physical pin mapping.',
 'Signals are NOT shared between the Pis. All pass-through conductors stay local; header orientation must match stack mechanics.',
 'GPIO5/reset is an intentional exception: OR with supervisor inhibit, active HIGH. MCU absent -> SDR held in reset.'])
 nets={}
 for p,desc in PIMAP.items():
    if desc=='GND':nets[p]='GND'
    elif desc=='3V3':nets[p]=f'{node}_3V3_PI'
    elif desc=='5V':nets[p]=f'{node}_5V'
    else:nets[p]=f'{node}_GPIO'+re.search(r'GPIO(\d+)',desc).group(1)
 left=s.comp(ref(s,'J'),'Pi40r',f'PI_{node}: 2x20 SOCKET',21,62,nets,mpn='Samtec SSQ-120-03-G-D',fp='',note='2x20 2.54 mm bottom socket; current rating and stack height must be checked for assembled use')
 sn=dict(nets);sn[29]=f'{node}_SDR_RESET'
 right=s.comp(ref(s,'J'),'Pi40l',f'SXCEIVER_{node}: 2x20 HEADER',104,62,sn,mpn='Samtec TSW-120-07-G-D',fp='Connector_PinHeader_2.54mm:PinHeader_2x20_P2.54mm_Vertical')
 PI_CONNS[node]=(left,right)
 for p in range(1,41):
    a=left.pos(p);b=right.pos(p)
    if p==29:
       s.stub(left,p,L=7);s.stub(right,p,L=7)
    else:
       s.wire(a,b,nets[p]);left.connected.add(str(p));right.connected.add(str(p))
       # One real named connection point per pass-through wire for off-sheet taps.
       s.label((54,a[1]),nets[p],0)
 # GPIO breakouts, each exported conductor has a real series resistor and ESD part.
 s.text(134,22,'Free / assigned GPIO breakouts (3.3 V only)',.65)
 free=[4,17,27,24,25,7,26]
 jg=J(s,f'{node} GPIO terminals',215,43,[f'{node}_EXT_GPIO{g}' for g in free]+['GND'],mpn='Phoenix MKDS 1.5/8-3.5',fp='')
 for i,g in enumerate(free):
    y=26+5*i
    r=R(s,'220R',163,y,f'{node}_GPIO{g}',f'{node}_EXT_GPIO{g}')
    end=jg.pos(i+1);s.chain(r.pos('2'),(200,y),(200,end[1]),end,net=f'{node}_EXT_GPIO{g}');r.connected.add('2');jg.connected.add(str(i+1))
    # ESD parts shown separately lower down, electrically bound to connector-side nets.
    passive(s,'Z','PESD3V3U1UL',146+10*i,57,'GND',f'{node}_EXT_GPIO{g}',True,mpn='PESD3V3U1UL',fp='Diode_SMD:D_SOD-882')
 s.text(134,65,'ESD protection is not 12/24 V input protection. GPIO12/13 reserved for HW-version compatibility.',.43)
 # Pi I2C bus is separate from supervisor mux bus, entirely powered from that Pi.
 ji=J(s,f'{node} local I2C',213,79,[f'{node}_3V3_PI','GND',f'{node}_GPIO2',f'{node}_GPIO3'],mpn='JST B4B-PH-K-S',fp='Connector_JST:JST_PH_B4B-PH-K_1x04_P2.00mm_Vertical')
 s.text(136,76,'Local I2C: existing Pi pull-ups, no AON pull-up / no second master.',.45)
 # UART AON -> switched Pi is buffered with powered-off isolation.
 ub=U(s,'SN74LVC1G125','SN74LVC1G125DBVR',144,98,{1:'GND',2:f'MCU_TX_{node}',3:'GND',4:f'{node}_RX_BUFFER',5:f'{node}_3V3_PI'})
 rr=R(s,'100R',163,98,f'{node}_RX_BUFFER',f'{node}_GPIO15');s.link(ub,4,rr,1)
 R(s,'1k',178,97,f'{node}_GPIO14',f'MCU_RX_{node}')
 R(s,'100k',191,108,f'MCU_RX_{node}','GND',True)
 dec(s,145,86,f'{node}_3V3_PI')
 R(s,'1k',180,121,f'{node}_GPIO16',f'HB_{node}')
 R(s,'100k',194,126,f'HB_{node}','GND',True)
 # Shutdown is open drain, so it cannot back-power the switched Pi.
 q=Q(s,148,125,f'SHDN_{node}',f'{node}_GPIO6')
 R(s,'100k',137,139,f'SHDN_{node}','GND',True)
 pull(s,f'{node}_GPIO6',157,119,f'{node}_3V3_PI')
 # Reset arbitration. Force input has switched-side pull-up; only an explicit healthy MCU releases it.
 uor=U(s,'SN74LVC1G32','SN74LVC1G32DBVR',47,115,{1:f'{node}_GPIO5',2:f'{node}_FORCE_RESET',3:'GND',4:f'{node}_SDR_RESET',5:f'{node}_3V3_PI'})
 q=Q(s,72,127,f'{node}_RF_GATE',f'{node}_FORCE_RESET')
 pull(s,f'{node}_FORCE_RESET',77,111,f'{node}_3V3_PI')
 R(s,'100k',61,139,f'{node}_RF_GATE','GND',True)
 uand=U(s,'SN74LVC1G08','SN74LVC1G08DBVR',30,141,{1:f'RF_ALLOW_{node}',2:f'{node}_RF_DIP_ALLOW',3:'GND',4:f'{node}_RF_GATE',5:'3V3_AON'})
 dec(s,47,102,f'{node}_3V3_PI');dec(s,16,138);R(s,'100k',16,151,f'RF_ALLOW_{node}','GND',True)
 s.text(90,147,'No independent USB-C power on either Pi during controlled operation.',.52)
 s.text(90,151,'40-pin current delivery, header temperature and cable backfeeding need a real assembled test.',.47)
 return s
pi_node('A');pi_node('B')

# ---------- Bare supervisor, watchdog, boot and service ----------
# Safety-critical outputs deliberately avoid the default JTAG pins.
for p in DEFS['STM32F103CB'].pins:
    p.name={18:'PB0/BL_PWM',29:'PA8/TACH_A',39:'PB3/TACH_B',40:'PB4/SHDN_B',38:'PA15/SHDN_A',45:'PB8/PWR_A',46:'PB9/PWR_B',28:'PB15/RF_B'}.get(int(p.num),p.name)
ic('PNP3906',[(1,'B','input')],[(3,'C')],top=[(2,'E','passive')],w=5)
conn('USBMicro',5,'l',2,['VBUS','D-','D+','ID','GND'])
s=Sheet('05_SUPERVISOR','05 | Bare STM32 supervisor, watchdog, clock, USB and SWD','A2',[
 'Bare STM32F103CBT6; no MCU module, no external boot flash. USB device application / power policy firmware is NOT supplied.',
 'Power and RF allow are low by passive default. External watchdog is hardware; heartbeat policy is firmware.',
 'Disable JTAG while retaining SWD before using PB3/PB4/PA15. The two Pi power outputs are on PB8/PB9.'])
mn={1:'3V3_AON',9:'VDDA_MCU',24:'3V3_AON',36:'3V3_AON',48:'3V3_AON',23:'GND',35:'GND',47:'GND',8:'GND',
5:'OSC_IN',6:'OSC_OUT',7:'MCU_RESET_N',44:'BOOT0',20:'MUX_RESET_N',34:'SWDIO',37:'SWCLK',32:'USB_DM_MCU',33:'USB_DP_MCU',
30:'MCU_TX_A',31:'MCU_RX_A',12:'MCU_TX_B',13:'MCU_RX_B',21:'RS_TX',22:'RS_RX',25:'RS_DE',42:'MGMT_SCL',43:'MGMT_SDA',
14:'LCD_CS_N',15:'LCD_SCK_RAW',16:'LCD_MISO',17:'LCD_MOSI_RAW',18:'LCD_BL_PWM',19:'LCD_RESET_N',26:'TOUCH_CS_N',27:'TOUCH_IRQ_N',
29:'FAN_A_TACH',39:'FAN_B_TACH',10:'FAN_A_PWM',11:'FAN_B_PWM',2:'WDI_MCU',3:'HB_A',4:'HB_B',
45:'A_PWR_EN',46:'B_PWR_EN',41:'RF_ALLOW_A',28:'RF_ALLOW_B',38:'SHDN_A',40:'SHDN_B'}
u=U(s,'STM32F103CB','STM32F103CBT6',94,82,mn)
# A separate capacitor at every supply group, plus local bulk and filtered analogue supply.
for x in (60,74,88,102):dec(s,x,30)
C(s,'4.7u 16V X7R',116,30,'3V3_AON',fp='Capacitor_SMD:C_0805_2012Metric')
R(s,'10R',42,29,'3V3_AON','VDDA_MCU');C(s,'1u 16V X7R',28,41,'VDDA_MCU');dec(s,42,41,'VDDA_MCU')
# HSE crystal. Load capacitance is explicit but board stray capacitance remains a measured quantity.
y=passive(s,'Crystal','8MHz CL=12pF',40,60,'OSC_IN','OSC_OUT',mpn='ABM3B-8.000MHZ-B2-T',fp='',note='Use 18pF per side, approx 3pF parasitic target; verify crystal startup')
C(s,'18p C0G',30,72,'OSC_IN');C(s,'18p C0G',48,72,'OSC_OUT')
R(s,'10k',16,86,'BOOT0','GND',True);J(s,'BOOT strap',28,88,['BOOT0','3V3_AON'],note='Short only for ROM USART bootloader; default open. This is a physical jumper, not a missing part.')
R(s,'10k',17,103,'MUX_RESET_N','GND',True)
pull(s,'MCU_RESET_N',46,88);C(s,'100n',45,103,'MCU_RESET_N');passive(s,'SW','RESET',29,116,'MCU_RESET_N','GND')
# Watchdog open-drain reset can be wire-ORed with reset switch and SWD adapter.
wd=U(s,'TPS3828','TPS3828-33DBVR',164,40,{1:'MCU_RESET_N',2:'GND',3:'WD_MR_N',4:'WDI',5:'3V3_AON'})
pull(s,'WD_MR_N',181,35);dec(s,154,26)
wb=U(s,'SN74LVC1G125','SN74LVC1G125DBVR',198,43,{1:'GND',2:'WDI_MCU',3:'GND',4:'WDI',5:'3V3_AON'})
R(s,'1k',216,48,'WDI','GND',True);R(s,'100k',187,61,'WDI_MCU','GND',True);dec(s,216,28)
s.text(139,68,'WDI: hardware buffer permits 1k pulldown without overloading PC13.',.48)
s.text(139,71,'Feed falling edges <1.6 s nominal; enter safe outputs before starting a Pi.',.48)
J(s,'SWD service',197,84,['3V3_AON','SWDIO','GND','SWCLK','MCU_RESET_N','GND'],mpn='Samtec TSW-103-07-G-D',fp='',note='Custom keyed service pin assignment, not assumed ARM standard cable pinout')
# USB VBUS does not power the board. It only enables the D+ attach pull-up via transistors.
ju=s.comp(ref(s,'J'),'USBMicro','USB micro-B service',25,138,{1:'USB_VBUS',2:'USB_DM_CONN',3:'USB_DP_CONN',4:None,5:'GND'},mpn='10118194-0001LF',fp='')
R(s,'22R',48,135,'USB_DM_CONN','USB_DM_MCU');R(s,'22R',48,142,'USB_DP_CONN','USB_DP_MCU')
passive(s,'Z','PESD3V3U1UL',64,140,'GND','USB_DM_CONN',True,mpn='PESD3V3U1UL',fp='Diode_SMD:D_SOD-882')
passive(s,'Z','PESD3V3U1UL',78,141,'GND','USB_DP_CONN',True,mpn='PESD3V3U1UL',fp='Diode_SMD:D_SOD-882')
R(s,'100k',101,137,'USB_VBUS','USB_DETECT_B');R(s,'100k',109,148,'USB_DETECT_B','GND',True)
nq=s.comp(ref(s,'Q'),'NPN','MMBT3904',124,137,{1:'USB_DETECT_B',3:'USB_PULL_DOWN',2:'GND'},mpn='MMBT3904',fp='Package_TO_SOT_SMD:SOT-23')
R(s,'10k',140,131,'USB_PULL_DOWN','USB_PNP_B')
pull(s,'USB_PNP_B',153,119)
pq=U(s,'PNP3906','MMBT3906',166,130,{1:'USB_PNP_B',2:'3V3_AON',3:'USB_ATTACH_3V3'})
R(s,'1.5k 1%',191,130,'USB_ATTACH_3V3','USB_DP_CONN')
s.text(139,148,'USB is self-powered: no VBUS -> 5 V / 3.3 V power path. D+ attach only while VBUS is present.',.46)
s.text(139,152,'USB ROM boot is not assumed on STM32F103; SWD or USART loader programs the initial application.',.46)

# ---------- Sensor hub and shared sensors ----------
s=Sheet('06_I2C_HUB','06 | Always-on I2C mux, shared sensor and test ports',notes=[
 'MGMT = sole master STM32. TCA9548A channels isolate duplicate device addresses; select only one sensor bank at once.',
 'This is NOT an electrical connection of the two Pi I2C masters. Pis obtain central telemetry through their UART protocol.'])
tc=U(s,'TCA9548A','TCA9548APWR / 0x70',43,55,{23:'MGMT_SDA',22:'MGMT_SCL',3:'MUX_RESET_N',1:'GND',2:'GND',21:'GND',24:'3V3_AON',12:'GND',
4:'SENS_A_SDA',5:'SENS_A_SCL',6:'SENS_B_SDA',7:'SENS_B_SCL',8:'SYS_SDA',9:'SYS_SCL',10:'EXT_I2C_SDA',11:'EXT_I2C_SCL',13:'OLED_SDA',14:'OLED_SCL',15:None,16:None,17:None,18:None,19:None,20:None})
pull(s,'MGMT_SDA',13,31,val='2.2k');pull(s,'MGMT_SCL',23,31,val='2.2k');dec(s,37,27)
for i,(sda,scl) in enumerate([('SENS_A_SDA','SENS_A_SCL'),('SENS_B_SDA','SENS_B_SCL'),('SYS_SDA','SYS_SCL'),('EXT_I2C_SDA','EXT_I2C_SCL'),('OLED_SDA','OLED_SCL')]):
    x=78+i*17
    pull(s,sda,x,28,val='4.7k');pull(s,scl,x+7,40,val='4.7k')
# No pullup on RESET_N here: boot1 pull-down on MCU is intentional; MCU drives it high after startup.
tmp=U(s,'TMP117','TMP117AIDRVR / SYS 0x48',95,68,{1:'SYS_SCL',4:'GND',6:'SYS_SDA',3:'SYS_TEMP_ALERT_N',5:'3V3_AON',2:'GND',7:'GND'})
dec(s,112,57);pull(s,'SYS_TEMP_ALERT_N',123,67)
J(s,'EXT I2C / 3V3',144,91,['3V3_AON','GND','EXT_I2C_SDA','EXT_I2C_SCL'],mpn='JST B4B-PH-K-S',fp='Connector_JST:JST_PH_B4B-PH-K_1x04_P2.00mm_Vertical',note='Short in-enclosure cable only; not an industrial field bus')
J(s,'MGMT test',34,93,['3V3_AON','GND','MGMT_SDA','MGMT_SCL'],note='Observe only; do not attach a second I2C master without arbitration')
s.text(76,99,'SYS bus also carries INA226 0x40 and field MCP23017 0x21.',.48)
s.text(76,102,'Address plan in docs/INTERFACES.md. Channels 5..7 pins intentionally unused, not placeholder devices.',.44)

# ---------- Fully populated sensors for each node ----------
def sensors(node):
 s=Sheet(f'07_SENSORS_{node}',f'07{node} | Node {node}: temperature, humidity, NTC and ADC inputs',notes=[
  'All sensors are powered from 3V3_AON so they remain readable when the corresponding Pi is off.',
  'TMP117 = 0x48, ADS1115 ADDR=VDD = 0x49, SHT45 = 0x44, INA226 = 0x40, node GPIO expander = 0x20.'])
 sda=f'SENS_{node}_SDA';scl=f'SENS_{node}_SCL'
 t=U(s,'TMP117',f'TMP117AIDRVR / {node}',32,33,{1:scl,4:'GND',6:sda,3:None,5:'3V3_AON',2:'GND',7:'GND'})
 dec(s,14,23);dec(s,47,23,val='1u 16V X7R')
 sh=U(s,'SHT45','SHT45-AD1B-R2',104,32,{1:sda,2:scl,3:'3V3_AON',4:'GND'})
 dec(s,88,22)
 s.text(12,45,'TMP117 near the SDR: this is board temperature, not the Pi CPU junction temperature.',.43)
 s.text(81,44,'SHT45 near a vent, thermally separated from converters / heatsinks.',.43)
 adc=U(s,'ADS1115',f'ADS1115IDGSR / {node}',40,76,{4:f'{node}_ADC_NTC',5:f'{node}_ADC_FWD',6:f'{node}_ADC_REV',7:f'{node}_ADC_EXT',1:'3V3_AON',9:sda,10:scl,2:None,8:'3V3_AON',3:'GND'})
 dec(s,55,61);dec(s,66,61,val='1u 16V X7R')
 # Board NTC and test terminals. A second parallel remote NTC would change calibration: connector is sense/test only.
 R(s,'10k 0.1%',13,57,'3V3_AON',f'{node}_NTC_NODE',True)
 R(s,'NTC 10k B25/50=3380K',13,72,f'{node}_NTC_NODE','GND',True,mpn='NTCG163JF103FT1',note='TDK NTCG163JF103FT1: R25=10k +/-1%; B25/50=3380K, B25/85=3435K. Use manufacturer RT table.')
 R(s,'1k',23,86,f'{node}_NTC_NODE',f'{node}_ADC_NTC');C(s,'100n',13,97,f'{node}_ADC_NTC')
 # ADC frontends: values and protection are present; RF detector itself is external, not a fake on-board RF monitor.
 for i,(tag,hi,lo,range_text) in enumerate([('FWD','10k 0.1%','10k 0.1%','0..5V DC detector'),('REV','10k 0.1%','10k 0.1%','0..5V DC detector'),('EXT','39k 0.1%','10k 0.1%','0..12V DC')]):
    x=86+26*i;inn=f'{node}_{tag}_IN';mid=f'{node}_{tag}_DIV';an=f'{node}_ADC_{tag}'
    J(s,range_text,x,57,[inn,'GND'],mpn='JST B2B-PH-K-S',fp='Connector_JST:JST_PH_B2B-PH-K_1x02_P2.00mm_Vertical')
    r=R(s,hi,x,70,inn,mid,True);rl=R(s,lo,x,84,mid,'GND',True)
    sr=R(s,'1k',x+11,77,mid,an);cf=C(s,'100n',x+11,94,an)
    s.chain(r.pos('2'),(x,77),rl.pos('1'),net=mid);r.connected.add('2');rl.connected.add('1')
    s.chain((x,77),sr.pos('1'),net=mid);sr.connected.add('1');s.dot((x,77))
    passive(s,'Z','PESD3V3U1UL',x+1,98,'GND',an,True,mpn='PESD3V3U1UL',fp='Diode_SMD:D_SOD-882')
 s.text(7,108,'No RF power coupler or detector IC is included. These are explicitly DC detector-voltage inputs; do not connect an antenna/RF cable.')
 return s
sensors('A');sensors('B')

# ---------- DIP / LEDs / local service inputs ----------
def node_ui(node):
 s=Sheet(f'08_UI_{node}',f'08{node} | Node {node}: eight mode switches, LEDs and service key',notes=[
  'DIP bits 0..1 mode, bit2 CLOSED = hardware RF inhibit, bit3 config lock, bits4..7 node ID.',
  'GPA pins are inputs. GPB0..3 sink the four LEDs; GPB7 is input (also suitable for restricted newer MCP23017 silicon).'])
 dn=[f'{node}_MODE0',f'{node}_MODE1',f'{node}_RF_DIP_ALLOW',f'{node}_CFG_LOCK',*[f'{node}_ID{i}' for i in range(4)]]
 nets={12:f'SENS_{node}_SCL',13:f'SENS_{node}_SDA',18:'MCU_RESET_N',15:'GND',16:'GND',17:'GND',20:None,19:None,11:None,14:None,9:'3V3_AON',10:'GND'}
 nets.update({21+i:dn[i] for i in range(8)})
 for i,name in enumerate(['POWER','RF','FAULT','SERVICE']):nets[i+1]=f'{node}_LED_{name}_N'
 nets.update({5:f'{node}_SERVICE_KEY_N',6:f'{node}_CURRENT_ALERT_N',7:f'{node}_5V_PG',8:f'{node}_BUCK_PG'})
 m=U(s,'MCP23017',f'MCP23017-E/SS / {node} 0x20',54,58,nets)
 d=s.comp(ref(s,'SW'),'DIP8','CTS 219-8MST',104,32,{**{i+1:dn[i] for i in range(8)},**{16-i:'GND' for i in range(8)}},mpn='219-8MST',fp='Button_Switch_SMD:SW_DIP_SPSTx08_Slide_9.78x22.66mm_W8.61mm_P2.54mm')
 for i,net in enumerate(dn):
    pull(s,net,136,21+i*9,val='10k')
    # Long lines are actual connections from expander pins to each corresponding switch.
    pp=m.pos(21+i);dp=d.pos(i+1);xc=77+i*2
    s.chain(pp,(xc,pp[1]),(xc,dp[1]),dp,net=net);m.connected.add(str(21+i));d.connected.add(str(i+1))
 dec(s,32,33);C(s,'1u 16V',22,33,'3V3_AON')
 for i,name in enumerate(['POWER','RF','FAULT','SERVICE']):
    yy=65+i*9
    r=R(s,'1k 1%',93,yy,'3V3_AON',f'{node}_LED_{name}_A')
    led=passive(s,'LED',name,108,yy,f'{node}_LED_{name}_A',f'{node}_LED_{name}_N',mpn='LTST-C190KGKT' if name=='POWER' else'LTST-C190KFKT' if name=='FAULT' else'LTST-C190TBKT',fp='LED_SMD:LED_0603_1608Metric')
    s.link(r,2,led,2)
 pull(s,f'{node}_SERVICE_KEY_N',22,78)
 passive(s,'SW','SERVICE / SHUTDOWN REQUEST',24,95,f'{node}_SERVICE_KEY_N','GND',mpn='TL3342F160QG')
 s.text(7,107,'Mode meanings and shutdown request are firmware policy. RF inhibit additionally gates SDR reset in hardware even without I2C polling.')
 return s
node_ui('A');node_ui('B')

# ---------- Bare TFT panel connector and actual touch controller ----------
s=Sheet('09_DISPLAY','09 | Concrete 2.4-inch TFT + resistive touch + backlight driver','A2',[
 'Selected external bare panel: Newhaven NHD-2.4-240320CF-BSXV-FT (ST7789VI). No unspecified TFT module.',
 'Panel interface: 20-pin 1.0 mm FFC, Molex 52271-2069. TFT SPI is on STM32, not on the SXceiver SPI bus.',
 'LCD D/C is field-expander GPB6; write it before SPI transfers. Backlight uses STM32 PB0 PWM.'])
# FFC connector has native panel signal names for review.
conn('NHD20',20,'l',2,['GND','YD','XL','YU','XR','VDD','IOVDD','MOSI','MISO','SCLK','DC','nCS','nRES','IM0','IM1','LEDK1','LEDK2','LEDK3','LEDK4','LEDA'])
ffc=s.comp(ref(s,'J'),'NHD20','Molex 52271-2069',184,65,{1:'GND',2:'TOUCH_YM',3:'TOUCH_XM',4:'TOUCH_YP',5:'TOUCH_XP',6:'3V3_AON',7:'3V3_AON',8:'LCD_MOSI',9:'LCD_MISO',10:'LCD_SCK',11:'LCD_DC',12:'LCD_CS_N',13:'LCD_RESET_N',14:'GND',15:'3V3_AON',16:'LED_K1',17:'LED_K2',18:'LED_K3',19:'LED_K4',20:'5V_AUX'},mpn='52271-2069',fp='',note='Connector contact side / insertion direction must match NHD panel FPC drawing. Pin20 is LED anode, not logic supply.')
R(s,'33R',67,38,'LCD_SCK_RAW','LCD_SCK');R(s,'33R',67,49,'LCD_MOSI_RAW','LCD_MOSI')
pull(s,'LCD_CS_N',101,35);pull(s,'LCD_RESET_N',115,47)
C(s,'4.7u 16V X7R',149,26,'3V3_AON',fp='Capacitor_SMD:C_0805_2012Metric');dec(s,135,26)
# A 2.4-inch panel is an external assembly; its FPC connector and electronics are wired here.
tu=U(s,'TSC2046','TSC2046IPWR',91,86,{1:'3V3_AON',10:'3V3_AON',6:'GND',2:'TOUCH_XP',3:'TOUCH_YP',4:'TOUCH_XM',5:'TOUCH_YM',7:'GND',8:'GND',9:'TOUCH_VREF',16:'LCD_SCK',15:'TOUCH_CS_N',14:'LCD_MOSI',12:'LCD_MISO',13:None,11:'TOUCH_IRQ_N'})
dec(s,58,71);dec(s,71,66);C(s,'1u 16V',58,101,'TOUCH_VREF');pull(s,'TOUCH_IRQ_N',127,87);pull(s,'TOUCH_CS_N',135,103)
# Explicit electrode connections, not floating touch-module labels.
for mp,cp in [(2,5),(3,4),(4,3),(5,2)]:
    net=tu.nets[str(mp)];s.label(tu.pos(mp),net) # Remaining long runs represented by real global labels (same named electrode).
# Four separate limiting resistors: not one resistor feeding four parallel LEDs.
for i,x in enumerate((151,167,183,199)):
    R(s,'82R 1% 0.25W',x,115,f'LED_K{i+1}','BACKLIGHT_SINK',True,fp='Resistor_SMD:R_1206_3216Metric')
qb=Q(s,133,131,'BL_GATE','BACKLIGHT_SINK',val='AO3400A')
R(s,'100R',112,131,'LCD_BL_PWM','BL_GATE');R(s,'100k',119,145,'BL_GATE','GND',True)
CP(s,'47u 10V',210,121,'5V_AUX',mpn='EEU-FR1A470',fp='')
J(s,'OLED expansion (3V3)',29,93,['3V3_AON','GND','OLED_SDA','OLED_SCL'],mpn='JST B4B-PH-K-S',fp='Connector_JST:JST_PH_B4B-PH-K_1x04_P2.00mm_Vertical',note='Optional external I2C display connector. Not an unspecified on-board display controller.')
s.text(11,136,'Backlight: 4 x 82R; calculated worst case <125mA total with 5V rail +/-5% and LED Vf >=2.8V.',.48)
s.text(11,141,'Resistive touch inputs go to TSC2046; the MCU SPI master must apply separate chip selects.',.48)
s.text(11,146,'Panel power is 3.3V. 5V_AUX connects ONLY to the LED anode through the selected panel.',.48)
s.text(11,151,'SPI clock during touch conversion must respect TSC2046 timing (do not reuse the fast TFT clock blindly).',.48)

# ---------- Field I/O expander and two real fan circuits ----------
s=Sheet('10_FANS_CONTROL','10 | Fan PWM/tachometer circuits and central field expander',notes=[
 'Two 12V four-wire fans. PWM outputs are open-drain; default released. Select fans with default full-speed when PWM is open.',
 'Fan power is always on while the bus is present. Tach inputs assume open-collector fans, not push-pull 12V outputs.'])
for i,node in enumerate(['A','B']):
    x=30+i*83
    j=J(s,f'FAN {node} / 4-WIRE',x,35,['GND',f'FAN_{node}_12V',f'FAN_{node}_TACH_CONN',f'FAN_{node}_PWM_OD'],mpn='Molex 47053-1000',fp='')
    passive(s,'Fuse','F1A / 32VDC',x-14,21,'BUS_12V',f'FAN_{node}_12V',mpn='Littelfuse 0451001MRL',fp='Fuse:Fuse_2410_6125Metric')
    CP(s,'47u 25V',x-12,46,f'FAN_{node}_12V',mpn='EEU-FR1E470',fp='')
    q=Q(s,x+24,44,f'FAN_{node}_GATE',f'FAN_{node}_PWM_OD')
    R(s,'100R',x+5,44,f'FAN_{node}_PWM',f'FAN_{node}_GATE');R(s,'100k',x+13,58,f'FAN_{node}_GATE','GND',True)
    pull(s,f'FAN_{node}_TACH_CONN',x-12,59)
    R(s,'1k',x+9,65,f'FAN_{node}_TACH_CONN',f'FAN_{node}_TACH');C(s,'1n',x+24,61,f'FAN_{node}_TACH')
    passive(s,'Z','PESD3V3U1UL',x+37,59,'GND',f'FAN_{node}_TACH',True,mpn='PESD3V3U1UL',fp='Diode_SMD:D_SOD-882')
# Separate central MCP on SYS channel, address1. It retains every field function, no pseudo GPIO module.
nets={12:'SYS_SCL',13:'SYS_SDA',18:'MCU_RESET_N',15:'3V3_AON',16:'GND',17:'GND',20:None,19:None,11:None,14:None,9:'3V3_AON',10:'GND'}
nets.update({21+i:f'DIN{i+1}_N' for i in range(4)});nets.update({25:'BUS_ALERT_N',26:'SYS_TEMP_ALERT_N',27:'FRONT_KEY_N',28:'INTERLOCK_N'})
nets.update({1:'DOUT1',2:'DOUT2',3:'DOUT3',4:'DOUT4',5:'ALARM_RELAY',6:'BUZZER',7:'LCD_DC',8:None})
m=U(s,'MCP23017','MCP23017-E/SS / SYS 0x21',75,90,nets)
dec(s,40,83);pull(s,'FRONT_KEY_N',14,84);pull(s,'INTERLOCK_N',23,92)
passive(s,'SW','FRONT SERVICE',13,104,'FRONT_KEY_N','GND',mpn='TL3342F160QG')
J(s,'DRY INTERLOCK',134,87,['INTERLOCK_N','GND'],note='Dry contact input, firmware interpretation only; not a safety-rated emergency stop')
s.text(103,106,'Fan RPM = pulse frequency / pulses-per-revolution; actual fan pole count belongs in firmware configuration.',.41)

# ---------- Four complete 12..24 V opto input circuits ----------
s=Sheet('11_INPUTS','11 | Four optocoupled 12..24 V field inputs',notes=[
 'Input range is 12..24VDC (not a guaranteed 5V input). Two 1k / 0.5W series resistors per LED.',
 'Each field input has its own return; no galvanic field-return connection to Pi ground. Functional isolation only until PCB review.'])
for i in range(4):
 x=40+(i%2)*79;y=34+(i//2)*42;n=i+1
 j=J(s,f'DIN{n} + / -',x-27,y,[f'DIN{n}_P',f'DIN{n}_M'],'r',mpn='Phoenix MKDS 1.5/2-3.5',fp='')
 r1=R(s,'1k 0.5W',x-16,y-1,f'DIN{n}_P',f'DIN{n}_SER',fp='Resistor_SMD:R_1206_3216Metric')
 r2=R(s,'1k 0.5W',x-6,y-1,f'DIN{n}_SER',f'DIN{n}_LED',fp='Resistor_SMD:R_1206_3216Metric')
 op=U(s,'LTV817','LTV-817C',x+7,y+1,{1:f'DIN{n}_LED',2:f'DIN{n}_M',4:f'DIN{n}_N',3:'GND'})
 s.link(j,1,r1,1);s.link(r1,2,r2,1);s.link(r2,2,op,1)
 di=D(s,'1N4148W',x-1,y+13,f'DIN{n}_M',f'DIN{n}_LED',mpn='1N4148W',fp='Diode_SMD:D_SOD-123')
 pull(s,f'DIN{n}_N',x+27,y-1)
 C(s,'10n',x+27,y+15,f'DIN{n}_N')
 s.text(x-25,y+27,f'DIN{n}: logical LOW while field voltage is present. Maximum resistor dissipation ~0.14W each at 24V.',.42)
s.text(7,108,'External field wiring must remain SELV/PELV; these inputs are NOT mains input terminals.')

# ---------- Four MOSFET actuator outputs + PA permits ----------
s=Sheet('12_OUTPUTS','12 | Four protected low-side outputs and two PA permit contacts',notes=[
 'DOUT1..4: 12V inductive loads, <=0.5A allocated per channel; shared 2A branch fuse. Not suitable for AC/mains loads.',
 'PA outputs are logic/open-drain permits, not two power-amplifier supplies. PA power must come from a separately budgeted supply.'])
passive(s,'Fuse','F2A / 32VDC',17,22,'BUS_12V','ACT_12V',mpn='Littelfuse 0451002MRL',fp='Fuse:Fuse_2410_6125Metric')
CP(s,'100u 25V',40,24,'ACT_12V',mpn='EEU-FR1E101',fp='')
for i in range(4):
 x=23+i*39;y=52;n=i+1
 j=J(s,f'LOAD {n}',x+3,y-16,['ACT_12V',f'OUT{n}_D','GND'],mpn='Phoenix MKDS 1.5/3-3.5',fp='')
 q=Q(s,x,y,f'OUT{n}_G',f'OUT{n}_D',val='AO3400A')
 R(s,'100R',x-10,y,f'DOUT{n}',f'OUT{n}_G');R(s,'100k',x-10,y+13,f'OUT{n}_G','GND',True)
 D(s,'SS14 / flyback',x+13,y+12,f'OUT{n}_D','ACT_12V',True,mpn='SS14',fp='Diode_SMD:D_SMA')
for i,node in enumerate(['A','B']):
 x=35+i*77
 q=Q(s,x,88,f'{node}_RF_GATE',f'PA_{node}_PERMIT_N')
 J(s,f'PA {node} PERMIT',x+27,85,[f'PA_{node}_PERMIT_N','GND'],mpn='JST B2B-PH-K-S',fp='Connector_JST:JST_PH_B2B-PH-K_1x02_P2.00mm_Vertical',note='Active-low permit sink. External PA controller must treat open circuit as inhibit; max 12V/10mA.')
s.text(7,107,'PA_PERMIT_N is asserted only with RF_ALLOW and local inhibit DIP in permit state. It is not a functional-safety certified interlock.')

# ---------- RS485, relay, buzzer ----------
ic('SM712',[(1,'A'),(2,'B')],[],bottom=[(3,'GND','passive')],w=7)
s=Sheet('13_RS485_ALARM','13 | RS-485 transceiver, alarm relay and buzzer',notes=[
 'RS-485 is non-isolated and shares secondary GND. Only one bias point per bus; enable termination only at a bus end.',
 'Relay contact rating restricted by this design to SELV 24V / 0.5A. No mains switching on these terminals.'])
u=U(s,'THVD1450','THVD1450DR',37,40,{1:'RS_RX',2:'RS_DE',3:'RS_DE',4:'RS_TX',6:'RS_A',7:'RS_B',8:'3V3_AON',5:'GND'})
dec(s,20,23);R(s,'100k',18,49,'RS_DE','GND',True)
J(s,'RS485 A / B / GND',138,31,['RS_A','RS_B','GND'],mpn='Phoenix MKDS 1.5/3-3.5',fp='')
R(s,'120R 1% 0.25W',80,30,'RS_A','RS_TERM',True,fp='Resistor_SMD:R_1206_3216Metric')
s.comp(ref(s,'SW'),'SW_JS102011','TERM ON',80,44,{'1':'RS_TERM','2':'RS_B','3':None},mpn='C&K JS102011SAQN',note='SPDT center terminal 2 is common; throw 3 intentionally not connected')
# THVD1450 has built-in receiver failsafe; no redundant fixed bus bias chain is installed.
U(s,'SM712','SM712-02HTG',111,52,{1:'RS_A',2:'RS_B',3:'GND'},note='Verify exact SOT23 transient-array pinout against Littelfuse drawing before footprint assignment')
# Relay coil and anti-parallel flyback diode.
k=U(s,'G5V1','G5V-1-DC12',65,85,{2:'BUS_12V',9:'RELAY_COIL_N',5:'ALARM_COM',6:'ALARM_COM',1:'ALARM_NC',10:'ALARM_NO'})
q=Q(s,37,86,'RELAY_G','RELAY_COIL_N')
R(s,'100R',22,86,'ALARM_RELAY','RELAY_G');R(s,'100k',23,99,'RELAY_G','GND',True)
D(s,'1N4148W',43,69,'RELAY_COIL_N','BUS_12V',mpn='1N4148W')
J(s,'ALARM COM/NC/NO',92,84,['ALARM_COM','ALARM_NC','ALARM_NO'],mpn='Phoenix MKDS 1.5/3-3.5',fp='')
# Concrete active buzzer, no AC audio amplifier block.
conn('Buzzer2',2,'l',4,['+','-'])
s.comp(ref(s,'BZ'),'Buzzer2','AI-1223-TWT-3V-2-R',143,81,{1:'3V3_AON',2:'BUZZER_N'},mpn='AI-1223-TWT-3V-2-R',fp='',source='https://puiaudio.com/file/specs-AI-1223-TWT-3V-2-R.pdf',note='Internally driven magnetic indicator, 2..4VDC, 30mA nominal. Pins + and - as case marking.')
q=Q(s,120,92,'BUZZER_G','BUZZER_N');R(s,'100R',106,92,'BUZZER','BUZZER_G');R(s,'100k',107,103,'BUZZER_G','GND',True)
D(s,'1N4148W',145,96,'BUZZER_N','3V3_AON',True,mpn='1N4148W')
s.text(7,108,'THVD1450 internal failsafe is used. Cable surge levels, common-mode voltage and shield/earth strategy must be specified separately.')

# ---------- Drawing and local-wire completion ----------
def onsegment(p,a,b):
 return (abs(a[0]-b[0])<1e-6 and abs(p[0]-a[0])<1e-6 and min(a[1],b[1])-1e-6<=p[1]<=max(a[1],b[1])+1e-6) or (abs(a[1]-b[1])<1e-6 and abs(p[1]-a[1])<1e-6 and min(a[0],b[0])-1e-6<=p[0]<=max(a[0],b[0])+1e-6)

def local_wires(s):
 # Connect short local component chains explicitly. Long off-sheet buses remain named electrical nets.
 # Do not reroute the carefully drawn parallel 40-pin conductors.
 if s.name.startswith('04_PI'):s.finish();return
 pins=[(c,p.num,c.pos(p.num),c.nets.get(p.num)) for c in s.comps for p in c.d.pins]
 boxes=[]
 for c in s.comps:
    corners=[c.xy(x,y) for x in [-c.d.w/2,c.d.w/2] for y in [-c.d.h/2,c.d.h/2]]
    boxes.append((min(p[0] for p in corners),min(p[1] for p in corners),max(p[0] for p in corners),max(p[1] for p in corners)))
 def intersects_body(a,b):
    for x0,y0,x1,y1 in boxes:
      x0+=.06;x1-=.06;y0+=.06;y1-=.06
      if a[0]==b[0] and x0<a[0]<x1 and max(min(a[1],b[1]),y0)<min(max(a[1],b[1]),y1):return True
      if a[1]==b[1] and y0<a[1]<y1 and max(min(a[0],b[0]),x0)<min(max(a[0],b[0]),x1):return True
    return False
 def okay(path,net):
    for a,b in zip(path,path[1:]):
      if a==b:continue
      if intersects_body(a,b):return False
      for c,pn,p,n in pins:
        if n!=net and onsegment(p,a,b):return False
      for aa,bb,nn in s.wires:
        if nn==net:continue
        if onsegment(a,aa,bb) or onsegment(b,aa,bb) or onsegment(aa,a,b) or onsegment(bb,a,b):return False
    return True
 groups=collections.defaultdict(list)
 for cp in pins:
    if cp[3] is not None:groups[cp[3]].append(cp)
 # Do not attempt long all-board power-ground trees: those use electrical net labels, as in ordinary schematics.
 for net,ends in groups.items():
    if net in ('GND','HV_NEG','SEC_GND','3V3_AON','BUS_12V','5V_AUX','MCU_RESET_N') or len(ends)>8:continue
    edges=[]
    for i,e in enumerate(ends):
      for f2 in ends[i+1:]:
       if e[0] is f2[0]:continue
       dist=abs(e[2][0]-f2[2][0])+abs(e[2][1]-f2[2][1])
       if dist<=29:edges.append((dist,e,f2))
    for dist,e,f2 in sorted(edges,key=lambda z:z[0]):
      c,n,a,_=e;d,m,b,_=f2
      if n in c.connected or m in d.connected:continue
      candidates=[]
      if a[0]==b[0] or a[1]==b[1]:candidates.append([a,b])
      candidates += [[a,(a[0],b[1]),b],[a,(b[0],a[1]),b]]
      for off in (-3,3,-6,6):
        xx=round((a[0]+b[0])/2*2)/2+off;yy=round((a[1]+b[1])/2*2)/2+off
        candidates += [[a,(xx,a[1]),(xx,b[1]),b],[a,(a[0],yy),(b[0],yy),b]]
      for path in candidates:
        if okay(path,net):
          s.chain(*path,net=net);c.connected.add(n);d.connected.add(m)
          # The named net is attached to an interior point rather than obscuring a component pin.
          for aa,bb in zip(path,path[1:]):
             if abs(aa[0]-bb[0])+abs(aa[1]-bb[1])>=4:
               p=((aa[0]+bb[0])/2,(aa[1]+bb[1])/2)
               s.label(p,net,0 if aa[1]==bb[1] else 90);break
          else:s.label(a,net,0)
          break
 s.finish()

for sh in ALLS:local_wires(sh)

# Detect accidental zero-resistance aliasing of differently named wires before writing files.
# Any collision is corrected by replacing the offending schematic connection with two named stubs,
# NEVER by changing a component's intended electrical net.
def geometric_conflicts(s):
  objects=[]
  for c in s.comps:
    for p in c.d.pins:
      net=c.nets.get(p.num)
      if net is not None:objects.append((c.pos(p.num),net,'pin',c.ref,p.num))
  for p,n,ang in s.labels:objects.append((p,n,'label','',''))
  for a,b,n in s.wires:
    if n:objects.extend([(a,n,'end','',''),(b,n,'end','','')])
  errors=[]
  for wi,(a,b,net) in enumerate(s.wires):
    if not net:continue
    for p,n,kind,ref0,pn in objects:
      if n!=net and onsegment(p,a,b):errors.append((wi,net,n,p,kind,ref0,pn))
  return errors

# Root sheet really references the individual component-level sheets; no functional block is used as an electronic component.
def root_sx():
 out=[f'(kicad_sch (version 20231120) (generator "netcore_tetra") (uuid {qs(ROOTID)}) (paper "A3")',
 '(title_block (title "NetCore-Tetra Dual Baseboard") (date "2026-09-18") (rev "0.2 REVIEW")) (lib_symbols)',
 f'(text "NETCORE-TETRA / DUAL BASEBOARD / COMPONENT SCHEMATICS" (at 15.24 20.32 0) {ef(.8,"left")} (uuid {qs(uid("root_title"))}))',
 f'(text "Each sheet below contains real parts and electrical wiring. See README before any fabrication or mains work." (at 15.24 29.21 0) {ef(.45,"left")} (uuid {qs(uid("root_note"))}))']
 for i,s in enumerate(ALLS):
    x=7+(i%3)*51;y=18+(i//3)*14.5;w=46;h=10
    inst=uid(s.name+'instance')
    out.append(f'(sheet (at {f(x)} {f(y)}) (size {f(w)} {f(h)}) (stroke (width 0.1524) (type default)) (fill (color 0 0 0 0)) (uuid {qs(inst)}) (property "Sheetname" {qs(s.title[:58])} (at {f(x)} {f(y-1)} 0) {ef(.38,"left")}) (property "Sheetfile" {qs(s.name+".kicad_sch")} (at {f(x)} {f(y+h+1)} 0) {ef(.34,"left")}) (instances (project {qs(PROJECT)} (path {qs("/"+ROOTID)} (page {qs(i+2)})))))')
 out+=['(sheet_instances (path "/" (page "1")))',')'];return '\n'.join(out)

# Custom preview of the *same* symbol/wire model. This is not falsely labelled a KiCad renderer.
def render_pdf(path):
 c=canvas.Canvas(str(path),pagesize=(420*mm,297*mm));c.setTitle('NetCore-Tetra component schematic revision 0.2 (engineering review)')
 def setup(W,H,number,title):
  c.setPageSize((W*mm,H*mm));c.setStrokeColorRGB(.25,.25,.25);c.setLineWidth(.35)
  c.rect(5*mm,5*mm,(W-10)*mm,(H-10)*mm)
  c.setFont('Helvetica',7);c.drawString(9*mm,8*mm,'NetCore-Tetra  |  2026-09-18  |  v0.2 REVIEW  |  Custom vector preview, NOT KiCad ERC/render')
  c.drawRightString((W-9)*mm,8*mm,f'{number} / {len(ALLS)+1}')
 setup(420,297,1,'Contents')
 c.setFont('Helvetica-Bold',23);c.drawString(18*mm,269*mm,'NETCORE-TETRA')
 c.setFont('Helvetica',16);c.drawString(18*mm,258*mm,'Dual baseboard | component-level schematic set')
 c.setFont('Helvetica-Bold',10);c.drawString(18*mm,247*mm,'REVIEW DRAFT - NOT FOR MANUFACTURE / DO NOT ENERGIZE MAINS SECTION')
 c.setFont('Helvetica',10)
 for i,s in enumerate(ALLS):c.drawString(20*mm,(234-i*10.0)*mm,f'{i+2:02d}   {s.title}')
 c.setFont('Helvetica',9);c.drawString(20*mm,34*mm,'Package / footprint completion, native KiCad validation, electrical measurements and firmware remain separate work.')
 c.drawString(20*mm,28*mm,'The 72 W reference rating and <=300 mm width are design constraints, not demonstrated properties of a new PCB.')
 c.showPage()
 for sn,s in enumerate(ALLS,2):
  W,H=(420,297) if s.paper=='A3' else(594,420);setup(W,H,sn,s.title)
  def pt(x,y):return(x*2.54*mm,(H-y*2.54)*mm)
  def line(a,b,width=.35):c.setLineWidth(width);c.line(*pt(*a),*pt(*b))
  c.setStrokeColorRGB(0,.32,.2)
  for a,b,n in s.wires:line(a,b)
  for p in s.junc:c.setFillColorRGB(0,.32,.2);c.circle(*pt(*p),.20*mm,stroke=0,fill=1)
  c.setStrokeColorRGB(.15,.15,.15);c.setFillColorRGB(.1,.1,.1)
  for cc in s.comps:
   # Clear underlying wiring within symbol body for readability, mirroring background fill.
   for kind,points,opts in cc.d.graphic():
    if kind=='rect':
      (x,y),(xx,yy)=points;a=cc.xy(x,y);b=cc.xy(xx,yy);xa,ya=pt(*a);xb,yb=pt(*b)
      c.setFillColorRGB(1,1,1);c.setStrokeColorRGB(.13,.13,.13);c.rect(min(xa,xb),min(ya,yb),abs(xa-xb),abs(ya-yb),stroke=1,fill=1);c.setFillColorRGB(.1,.1,.1)
    elif kind=='line':
      for a,b in zip(points,points[1:]):line(cc.xy(*a),cc.xy(*b),.42)
    elif kind=='circ':
      (x,y),r=points;c.circle(*pt(*cc.xy(x,y)),r*2.54*mm,stroke=1,fill=1 if opts else 0)
    elif kind=='text':
      (x,y),t=points;c.setFont('Helvetica',6.5);c.drawCentredString(*pt(*cc.xy(x,y)),str(t))
   for p in cc.d.pins:
    xy=cc.pos(p.num);length=1 if cc.d.kind not in ('conn','header') else 1.5
    a=math.radians(p.orient+cc.rot);inner=(xy[0]+length*math.cos(a),xy[1]-length*math.sin(a))
    c.setStrokeColorRGB(.12,.12,.12);line(xy,inner,.42)
    c.setFont('Helvetica',5.2);xp,yp=pt(*xy);c.setFillColorRGB(.35,.15,.1)
    # Actual physical pin numbers rendered near pin, signal names inside IC / connector.
    if cc.d.kind in ('ic','conn','opto','dip','relay'):
      orientation=(p.orient+cc.rot)%360
      if orientation==0:
       c.drawString(xp+1,yp+2,p.num);c.setFillColorRGB(.08,.08,.08);c.drawString(*pt(inner[0]+.25,inner[1]+.16),p.name)
      elif orientation==180:
       c.drawRightString(xp-1,yp+2,p.num);c.setFillColorRGB(.08,.08,.08);c.drawRightString(*pt(inner[0]-.25,inner[1]+.16),p.name)
      else:
       c.drawString(xp+1,yp,p.num);c.saveState();c.translate(*pt(*inner));c.rotate(90);c.setFillColorRGB(.08,.08,.08);c.drawCentredString(0,2,p.name);c.restoreState()
   x,y,xx,yy,j=cc.fieldpositions();c.setFillColorRGB(.15,.05,.05);c.setFont('Helvetica-Bold',7.1)
   if j=='left':c.drawString(*pt(x,y),cc.ref)
   else:c.drawCentredString(*pt(x,y),cc.ref)
   c.setFont('Helvetica',6.3)
   # Fit long part names in the schematic value field without losing the full value in CAD/BOM.
   text=cc.value
   if j=='left':c.drawString(*pt(xx,yy),text)
   else:c.drawCentredString(*pt(xx,yy),text)
  # Labels above wires, not concealed by bodies.
  for p,net,ang in s.labels:
   c.setFont('Helvetica',6.1);c.setFillColorRGB(0,.25,.15);xp,yp=pt(*p)
   if ang==180:c.drawRightString(xp-.7,yp+1.7,net)
   elif ang in (90,270):
      c.saveState();c.translate(xp-1.4,yp);c.rotate(90);c.drawString(0,0,net);c.restoreState()
   else:c.drawString(xp+.7,yp+1.7,net)
  for p in s.ncs:
   c.setStrokeColorRGB(.15,.15,.6);line((p[0]-.25,p[1]-.25),(p[0]+.25,p[1]+.25));line((p[0]-.25,p[1]+.25),(p[0]+.25,p[1]-.25))
  c.setFillColorRGB(.08,.08,.08)
  for x,y,t,sz in s.notes:
   c.setFont('Helvetica-Bold' if sz>.6 else'Helvetica',sz*2.54*mm)
   c.drawString(*pt(x,y),t)
  c.showPage()
 c.save()

# ---------- Full local net wiring (orthogonal, crossing-aware) ----------
import heapq
ROUTE_LOG=[]
def fully_wire(s):
 ispi=s.name.startswith('04_PI')
 saved_comps=list(s.comps)
 keep=[];keep_labels=[];keep_ncs=[]
 if ispi:
  # Preserve the true 40 parallel pin-to-pin conductors. Route all other circuits fully.
  keep=[w for w in s.wires if max(w[0][0],w[1][0])<=104 and min(w[0][1],w[1][1])>=32 and max(w[0][1],w[1][1])<=92]
  keep_labels=[l for l in s.labels if any(onsegment(l[0],a,b) and l[1]==n for a,b,n in keep)]
  s.comps=[c for c in s.comps if not c.d.name.startswith('Pi40')]
 # Existing drawings are layout seeds only; rebuild every electrical wire from physical symbol pins.
 s.wires=[];s.labels=[];s.ncs=[];s.junc=[]
 for c in s.comps:c.connected=set()
 scale=4 if ispi else 2
 def grid(p):return (round(p[0]*scale),round(p[1]*scale))
 def point(p):return(p[0]/scale,p[1]/scale)
 blocks=set(); reserved={};by_net=collections.defaultdict(list)
 W=round(s.size[0]*scale)-8;H=round(s.size[1]*scale)-12
 for c in s.comps:
  pts=[c.xy(x,y) for x in [-c.d.w/2,c.d.w/2] for y in [-c.d.h/2,c.d.h/2]]
  x0,y0,x1,y1=min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts)
  for gx in range(math.ceil(x0*scale),math.floor(x1*scale)+1):
   for gy in range(math.ceil(y0*scale),math.floor(y1*scale)+1):blocks.add((gx,gy))
  for p in c.d.pins:
   pos=c.pos(p.num);gn=grid(pos);net=c.nets[p.num]
   if gn in reserved and reserved[gn]!=net:raise ValueError(('pin collision',s.name,c.ref,p.num,pos,reserved[gn],net))
   reserved[gn]=net if net else'NC:'+c.ref+':'+p.num
   if net is None:s.ncs.append(pos);c.connected.add(p.num)
   else:by_net[net].append((c,p,gn))
 # Grid occupancy: net + local directions. Foreign straight segments can be crossed but never touched or turned on.
 occ=collections.defaultdict(lambda:collections.defaultdict(set));special=set(reserved)
 def cells(a,b):
  if a[0]==b[0]:return [(a[0],y) for y in range(min(a[1],b[1]),max(a[1],b[1])+1)]
  return[(x,a[1]) for x in range(min(a[0],b[0]),max(a[0],b[0])+1)]
 def register_path(path,net,draw=True):
  compressed=[path[0]]
  for i in range(1,len(path)-1):
   if (path[i-1][0]==path[i][0]) != (path[i][0]==path[i+1][0]):compressed.append(path[i])
  compressed.append(path[-1])
  for a,b in zip(compressed,compressed[1:]):
   if a==b:continue
   axis=0 if a[1]==b[1] else 1
   for g in cells(a,b):occ[g][net].add(axis)
   special.add(a);special.add(b)
   if draw:s.wire(point(a),point(b),net)
  return set(path)
 # Existing 40-wire nets are obstacles, not new abstract components.
 for a,b,n in keep:register_path(cells(grid(a),grid(b)),n)
 s.labels.extend(keep_labels)
 anchors={}
 # Allocate short outward wire at each terminal, preventing other nets from reaching a pin accidentally.
 for net,ends in by_net.items():
  anchors[net]=[]
  for c,p,g in ends:
   a=(p.orient+c.rot)%360;dx,dy={0:(-1,0),90:(0,1),180:(1,0),270:(0,-1)}[a]
   dest=(g[0]+dx,g[1]+dy)
   if dest in blocks or (dest in reserved and reserved[dest]!=net):dest=g
   if dest!=g:register_path([g,dest],net)
   special.add(dest);anchors[net].append(dest);c.connected.add(p.num)
   if net in ('GND','HV_NEG','SEC_GND'):
    # Ordinary electrical ground labels; no pointless full-page ground spaghetti.
    s.label(point(dest),net,180 if dx<0 else 90 if dy<0 else 270 if dy>0 else 0)
 def astar(a,b,net):
  if a==b:return[a]
  xlo=max(5,min(a[0],b[0])-25);xhi=min(W,max(a[0],b[0])+25)
  ylo=max(32,min(a[1],b[1])-25);yhi=min(H,max(a[1],b[1])+25)
  def run(loX,hiX,loY,hiY,limit):
   h=lambda p:abs(p[0]-b[0])+abs(p[1]-b[1])
   init=(a[0],a[1],2);heap=[(h(a),0,init)];prev={};best={init:0};visited=0
   while heap:
    _,cost,st=heapq.heappop(heap)
    if cost!=best.get(st):continue
    g=(st[0],st[1]);oldaxis=st[2];visited+=1
    if g==b:
     out=[g]
     while st in prev:st=prev[st];out.append((st[0],st[1]))
     return list(reversed(out))
    if visited>limit:break
    current_foreign=[ax for nn,ax in occ.get(g,{}).items() if nn!=net]
    for dx,dy,axis in [(1,0,0),(-1,0,0),(0,1,1),(0,-1,1)]:
     v=(g[0]+dx,g[1]+dy)
     if not(loX<=v[0]<=hiX and loY<=v[1]<=hiY):continue
     if v in blocks and v not in (a,b):continue
     if v in reserved and reserved[v]!=net:continue
     if current_foreign and axis!=oldaxis:continue
     foreign=[ax for nn,ax in occ.get(v,{}).items() if nn!=net]
     if foreign:
      if v in special:continue
      if any(len(ax)!=1 or axis in ax for ax in foreign):continue
     step=1+(1.8 if oldaxis!=2 and oldaxis!=axis else 0)+(7 if foreign else 0)
     # prefer merging with own already-routed copper instead of doubling the drawing
     if net in occ.get(v,{}):step*=.65
     co=cost+step;nxt=(v[0],v[1],axis)
     if co<best.get(nxt,float('inf')):
      best[nxt]=co;prev[nxt]=st;heapq.heappush(heap,(co+.6*h(v),co,nxt))
   return None
  return run(xlo,xhi,ylo,yhi,25000) or run(5,W,32,H,50000)
 # Short low fan-out nets first, power nets last. This produces readable, genuine component chains.
 nets=sorted((n for n in by_net if n not in ('GND','HV_NEG','SEC_GND')),key=lambda n:(len(anchors[n])>6,len(anchors[n])))
 for net in nets:
  ends=list(dict.fromkeys(anchors[net]));tree={ends[0]};remaining=ends[1:]
  s.label(point(ends[0]),net,0)
  while remaining:
   b,a=min(((b,a) for b in remaining for a in tree if all(nn==net for nn in occ.get(a,{}))),key=lambda p:abs(p[0][0]-p[1][0])+abs(p[0][1]-p[1][1]))
   path=astar(b,a,net)
   remaining.remove(b)
   if path:
    tree.update(register_path(path,net));ROUTE_LOG.append((s.name,net,'wire',len(path)))
   else:
    tree.add(b);s.label(point(b),net,0);ROUTE_LOG.append((s.name,net,'named-net-fallback',0))
  # Name one endpoint; names are electrical, not decorative text.
 s.comps=saved_comps
 # Explicit junction dots wherever three or four same-net wire branches meet.
 for g,ns in occ.items():
  for net,axes in ns.items():
   dirs=0
   for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
    if net in occ.get((g[0]+dx,g[1]+dy),{}):dirs+=1
   if dirs>=3 and len(ns)==1:s.dot(point(g))

for sh in ALLS:fully_wire(sh)

for c in ALLC:
 if c.ref.startswith(('J','SW','F','BZ')) or c.d.name=='CP':c.fp=''

# Diagnostic outputs first; the final package is generated only after these checks are inspected.
CONFLICTS={s.name:geometric_conflicts(s) for s in ALLS}
(ROOT/'docs'/'geometry_check.json').write_text(json.dumps({k:v for k,v in CONFLICTS.items() if v},indent=2))
assert not any(CONFLICTS.values()), {k:v for k,v in CONFLICTS.items() if v}
(ROOT/'docs'/'routing_report.json').write_text(json.dumps({'wire_routes':sum(x[2]=='wire' for x in ROUTE_LOG),'named_net_fallbacks':[x for x in ROUTE_LOG if x[2]!='wire']},indent=2))
for s in ALLS:(ROOT/(s.name+'.kicad_sch')).write_text(s.sx(),encoding='utf-8')
(ROOT/(PROJECT+'.kicad_sch')).write_text(root_sx(),encoding='utf-8')
(ROOT/(LIB+'.kicad_sym')).write_text('(kicad_symbol_lib (version 20231120) (generator "netcore_tetra")\n'+'\n'.join(DEFS[n].sx().replace(qs(LIB+':'+n),qs(n),1) for n in sorted({c.d.name for c in ALLC}))+')',encoding='utf-8')
(ROOT/'sym-lib-table').write_text(f'(sym_lib_table (version 7) (lib (name "{LIB}") (type "KiCad") (uri "${{KIPRJMOD}}/{LIB}.kicad_sym") (options "") (descr "Component-level project symbols")))')
pro={'meta':{'filename':PROJECT+'.kicad_pro','version':1},'schematic':{'legacy_lib_dir':'','legacy_lib_list':[]},'board':{},'erc':{'erc_exclusions':[],'meta':{'version':0}},'libraries':{'pinned_footprint_libs':[],'pinned_symbol_libs':[LIB]},'sheets':[[uid(s.name+'instance'),s.title] for s in ALLS]}
(ROOT/(PROJECT+'.kicad_pro')).write_text(json.dumps(pro,indent=2))
model={'project':PROJECT,'revision':'0.2 REVIEW','sheets':[],'components':[]}
for s in ALLS:model['sheets'].append({'file':s.name+'.kicad_sch','title':s.title,'uuid':s.id,'wires':len(s.wires),'labels':len(s.labels)})
for c in ALLC:model['components'].append({'reference':c.ref,'value':c.value,'symbol':c.d.name,'sheet':c.sheet.name+'.kicad_sch','mpn':c.mpn,'footprint':c.fp,'source':c.source,'note':c.note,'pins':c.nets})
(ROOT/'docs'/'design_netlist.json').write_text(json.dumps(model,indent=2))
with (ROOT/'BOM.csv').open('w',newline='',encoding='utf-8-sig') as h:
 w=csv.writer(h);w.writerow(['Reference','Value','MPN','Symbol','Footprint','Sheet','Datasheet','Engineering note'])
 for c in ALLC:w.writerow([c.ref,c.value,c.mpn,c.d.name,c.fp,c.sheet.name,c.source,c.note])
render_pdf(ROOT/'NetCore-Tetra-Schematic-v0.2.pdf')
print('Sheets:',len(ALLS)+1,'Components:',len(ALLC),'Wires:',sum(len(s.wires) for s in ALLS),'Labels:',sum(len(s.labels) for s in ALLS))
print('Conflicts:',{s:len(e) for s,e in CONFLICTS.items() if e})
