#!/usr/bin/env python3
"""Independent static parser + wire connectivity checker for this generated project.
Reads written .kicad_sch files (not the generator's in-memory drawing).
This is NOT the KiCad parser, ERC, simulation, insulation or manufacturing validation.
"""
from __future__ import annotations
import collections, json, math, re, sys
from pathlib import Path

TOKEN = re.compile(r'\s*(\(|\)|"(?:[^"\\]|\\.)*"|[^\s()]+)',re.S)
def parse(path:Path):
    text=path.read_text(encoding='utf-8');stack=[];root=None;pos=0
    while pos<len(text):
        if not text[pos:].strip():break
        m=TOKEN.match(text,pos)
        if not m:raise ValueError(f'{path.name}: token at offset {pos}')
        pos=m.end();t=m.group(1)
        if t=='(':
            n=[]
            if stack:stack[-1].append(n)
            elif root is not None:raise ValueError('multiple roots')
            else:root=n
            stack.append(n)
        elif t==')':
            if not stack:raise ValueError('extra closing parenthesis')
            stack.pop()
        else:
            if not stack:raise ValueError('atom outside root')
            stack[-1].append(json.loads(t) if t.startswith('"') else t)
    if stack:raise ValueError('missing closing parenthesis')
    return root

def kids(x,key):return [y for y in x if isinstance(y,list) and y and y[0]==key]
def kid(x,key):
    a=kids(x,key)
    if not a:raise ValueError(f'missing {key} in {x[0]}')
    return a[0]
def val(x,key):return kid(x,key)[1]
def props(x):return {y[1]:y[2] for y in kids(x,'property')}
def xyz(x):return tuple(float(z) for z in kid(x,'at')[1:4])
def pt(x,y):return(round(x*100000),round(y*100000))
def on(p,a,b):
    return (a[0]==b[0]==p[0] and min(a[1],b[1])<=p[1]<=max(a[1],b[1])) or (a[1]==b[1]==p[1] and min(a[0],b[0])<=p[0]<=max(a[0],b[0]))
class DSU:
    def __init__(self):self.p={}
    def find(self,x):
        self.p.setdefault(x,x)
        if self.p[x]!=x:self.p[x]=self.find(self.p[x])
        return self.p[x]
    def union(self,a,b):self.p[self.find(a)]=self.find(b)

def main(root:Path):
    spec=json.loads((root/'docs/design_netlist.json').read_text())
    expected={c['reference']:c for c in spec['components']}
    errors=[];checks=[];pin_nodes={};pin_details=[];global_labels=collections.defaultdict(list)
    allrefs={};uuids={};uf=DSU();sheets=[];wirecount=labelcount=nc_count=0
    files=[root/(spec['project']+'.kicad_sch')]+[root/s['file'] for s in spec['sheets']]
    for path in files:
        doc=parse(path)
        if doc[0]!='kicad_sch':errors.append(f'{path.name}: wrong document type')
        if val(doc,'version')!='20231120':errors.append(f'{path.name}: unexpected format version')
        def getuuids(node):
            if node[0]=='uuid':
                u=node[1]
                if u in uuids:errors.append(f'Duplicate UUID {u} in {path.name} / {uuids[u]}')
                uuids[u]=path.name
            for y in node:
                if isinstance(y,list):getuuids(y)
        getuuids(doc)
        for sub in kids(doc,'sheet'):
            fn=props(sub)['Sheetfile']
            if not (root/fn).is_file():errors.append('Missing subsheet '+fn)
        libs={s[1]:s for s in kids(kid(doc,'lib_symbols'),'symbol')}
        points=set();endpoints=[];pins=[];wires=[];labels=[];nc=set()
        for w in kids(doc,'wire'):
            xy=kids(kid(w,'pts'),'xy');a,b=[pt(float(t[1]),float(t[2])) for t in xy]
            if a==b or (a[0]!=b[0] and a[1]!=b[1]):errors.append(f'{path.name}: invalid zero/diagonal wire')
            wires.append((a,b));points.update((a,b));endpoints.extend((a,b))
        for j in kids(doc,'junction'):
            x,y,_=(*kid(j,'at')[1:3],0);points.add(pt(float(x),float(y)))
        for n in kids(doc,'no_connect'):
            pp=pt(*map(float,kid(n,'at')[1:3]));nc.add(pp);points.add(pp)
        for l in kids(doc,'global_label'):
            if val(l,'shape') not in ['input','output','bidirectional','tri_state','passive']:errors.append('Bad label type '+str(l[:4]))
            x,y,r=xyz(l);pp=pt(x,y);points.add(pp);labels.append((pp,l[1]));global_labels[l[1]].append((path.name,pp))
        for sym in kids(doc,'symbol'):
            pr=props(sym);ref=pr['Reference'];lib=val(sym,'lib_id');x,y,rot=xyz(sym)
            if ref in allrefs:errors.append('Duplicate reference '+ref)
            allrefs[ref]=path.name
            if ref not in expected:errors.append('Unexpected component '+ref);continue
            ex=expected[ref]
            if ex['value']!=pr['Value']:errors.append('Wrong value '+ref)
            libsym=libs[lib];ps=[]
            for unit in kids(libsym,'symbol'):ps+=kids(unit,'pin')
            numbers=[val(p,'number') for p in ps]
            if len(numbers)!=len(set(numbers)):errors.append('Duplicate physical pin in '+lib)
            if set(numbers)!=set(ex['pins']):errors.append('Pin list differs '+ref)
            r=math.radians(rot)
            for p in ps:
                no=val(p,'number');xx,yy,_=xyz(p)
                px=x+xx*math.cos(r)-yy*math.sin(r)
                py=y-xx*math.sin(r)-yy*math.cos(r)
                pp=pt(px,py);node=(path.name,pp);points.add(pp);pins.append((ref,no,pp));pin_nodes[(ref,no)]=node
                pin_details.append((ref,no,node,ex['pins'][no]))
                if ex['pins'][no] is None:
                    if pp not in nc:errors.append(f'Missing NC marker {ref}.{no}')
                elif pp in nc:errors.append(f'Connected pin marked NC {ref}.{no}')
            inst=kid(sym,'instances');projects=kids(inst,'project')
            if len(projects)!=1 or projects[0][1]!=spec['project']:errors.append('Wrong instance project '+ref)
            paths=kids(projects[0],'path')
            if len(paths)!=1 or val(paths[0],'reference')!=ref:errors.append('Wrong instance path reference '+ref)
        for pp in points:uf.find((path.name,pp))
        for a,b in wires:
            nodes=[pp for pp in points if on(pp,a,b)]
            for pp in nodes:uf.union((path.name,a),(path.name,pp))
        for ref,no,p in pins:
            ex=expected[ref]['pins'][no]
            touching=sum(on(p,a,b) for a,b in wires)
            if ex is not None and touching==0:errors.append(f'No wire at physical pin {ref}.{no}')
            if ex is None and touching:errors.append(f'NC pin touches wire {ref}.{no}')
        wirecount+=len(wires);labelcount+=len(labels);nc_count+=len(nc)
        sheets.append({'file':path.name,'components':len(pins) and len(kids(doc,'symbol')) or 0,'wires':len(wires),'labels':len(labels)})
    for name,nodes in global_labels.items():
        for n in nodes[1:]:uf.union(nodes[0],n)
    labels_at=collections.defaultdict(set)
    for name,nodes in global_labels.items():
        for n in nodes:labels_at[uf.find(n)].add(name)
    for ref,no,node,net in pin_details:
        got=labels_at[uf.find(node)]
        if net is not None and got!={net}:errors.append(f'Connectivity {ref}.{no}: intended={net}, actual={sorted(got)}')
    for component,names in labels_at.items():
        if len(names)>1:errors.append('Wire/label SHORT: '+', '.join(sorted(names)))
    if set(allrefs)!=set(expected):errors.append('Missing expected component references')
    parse(root/'NetCore_Components.kicad_sym');parse(root/'sym-lib-table')
    # Important board-level invariants, checked against labels extracted from saved schematics.
    nets=['HV_NEG','SEC_GND','GND','A_5V','B_5V','A_3V3_PI','B_3V3_PI','3V3_AON']
    for n in nets:
        if n not in global_labels:errors.append('Missing expected power rail '+n)
    netroots={n:uf.find(global_labels[n][0]) for n in nets if n in global_labels}
    for i,n in enumerate(nets):
        for m in nets[i+1:]:
            if n in netroots and m in netroots and netroots[n]==netroots[m]:errors.append('Power rail alias '+n+' / '+m)
    checks += ['All S-expressions parsed independently','All referenced child sheets and embedded symbols present',
    'Unique instance UUIDs and component references','Physical pin list matches declared design netlist',
    'Wire endpoints, pin coordinates, label positions and junctions reconstructed from saved files',
    'Every assigned pin reaches only its intended named net','No unintended named-net shorts',
    'Every unused physical pin has an NC marker and no wire','Selected primary/secondary and A/B rail separation checked at wire level only']
    # Raw connector continuity validation, not just a circuit intent declaration.
    pairs=[]
    for n in ['A','B']:
        cc=[c for c in expected.values() if c['sheet']==f'04_PI_{n}.kicad_sch' and c['symbol'].startswith('Pi40')]
        if len(cc)!=2:errors.append(f'Expected two Pi40 connectors for node {n}');continue
        for p in range(1,41):
            a,b=(cc[0]['reference'],str(p)),(cc[1]['reference'],str(p))
            same=uf.find(pin_nodes[a])==uf.find(pin_nodes[b])
            if same!=(p!=29):errors.append(f'{n} Pi/SDR conductor {p} wrong direct connection')
        pairs.append({'node':n,'direct_conductors':39,'pin29':'through active-high reset OR gate, intentionally not a wire'})
    checks.append('Both Pi/SXceiver pairs: 39 direct matching conductors and separate reset pin29')
    report={'status':'PASS_STATIC_ONLY' if not errors else 'FAIL','native_KiCad_parser': 'NOT_RUN',
    'ERC':'NOT_RUN','DRC':'NOT_APPLICABLE_NO_PCB','electrical_function':'NOT_VALIDATED',
    'mains_safety':'NOT_VALIDATED_DO_NOT_ENERGIZE','production_release':False,
    'sheets':sheets,'component_count':len(allrefs),'physical_pin_count':len(pin_details),
    'wire_count':wirecount,'global_label_count':labelcount,'unique_named_nets':len(global_labels),
    'no_connect_count':nc_count,'checks':checks,'Pi_passthrough':pairs,
    'missing_footprint_references':[c['reference'] for c in expected.values() if not c['footprint']],
    'limits':['This test can prove consistency with the design netlist, not correctness of that design.',
    'Part pinout, ratings, thermal behavior, EMC, isolation and firmware require separate review.',
    'KiCad itself was not installed in the generation environment.'], 'errors':errors}
    (root/'VALIDATION_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(report['status'],len(allrefs),'parts,',len(pin_details),'pins,',wirecount,'wires;',len(errors),'errors')
    for e in errors[:30]:print(e)
    return 1 if errors else 0
if __name__=='__main__':
    root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
    sys.exit(main(root))
