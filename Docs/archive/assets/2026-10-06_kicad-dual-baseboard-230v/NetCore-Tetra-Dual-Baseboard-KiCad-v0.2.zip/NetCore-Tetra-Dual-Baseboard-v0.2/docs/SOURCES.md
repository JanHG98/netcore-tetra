# Quellen und Nachvollziehbarkeit

Die Unterlagen liefern Referenzschaltungen, Datenblätter oder Pin-Zuordnungen. Die Umsetzung in diesem Projekt ist eine eigene Entwurfsarbeit; ein korrektes Hersteller-Referenzdesign validiert nicht automatisch die Übertragung.

## Primärquellen

- Power Integrations DER-993: https://www.power.com/design-support/design-examples/der-993-72-w-ultra-compact-power-supply-appliances-using-powigan-based-innoswitch4-qr
- DER-PDF (Rev.1, 19.05.2024): https://www.power.com/sites/default/files/documents/DER-993_72W_12V6A_90-265VAC_Iso_Flyback_Appliance_InnoSwitch4-QR.pdf
- InnoSwitch4-QR Familie, Applikationsschaltung: https://www.power.com/sites/default/files/documents/innoswitch4-qr_family_data_sheet_20250630.pdf?language=en
- TI TPS56637: https://www.ti.com/lit/ds/symlink/tps56637.pdf
- TI TPS25947 Familie: https://www.ti.com/lit/ds/symlink/tps25947.pdf
- Diodes AP63200/01/03/05: https://www.diodes.com/assets/Datasheets/AP63200-AP63201-AP63203-AP63205.pdf
- TI INA226: https://www.ti.com/lit/ds/symlink/ina226.pdf
- TI TMP117: https://www.ti.com/lit/ds/symlink/tmp117.pdf
- TI ADS1115: https://www.ti.com/lit/ds/symlink/ads1115.pdf
- TI TCA9548A: https://www.ti.com/lit/ds/symlink/tca9548a.pdf
- Sensirion SHT45: https://sensirion.com/products/catalog/SHT45
- Microchip MCP23017: https://ww1.microchip.com/downloads/en/DeviceDoc/20001952C.pdf
- ST STM32F103CB: https://www.st.com/resource/en/datasheet/stm32f103cb.pdf
- TI TPS3828 innerhalb TPS382x: https://www.ti.com/lit/ds/symlink/tps3823.pdf
- TI SN74LVC1G125: https://www.ti.com/lit/ds/symlink/sn74lvc1g125.pdf
- TI TSC2046: https://www.ti.com/lit/ds/symlink/tsc2046.pdf
- Newhaven NHD-2.4-240320CF-BSXV-FT: https://newhavendisplay.com/content/specs/NHD-2.4-240320CF-BSXV-FT.pdf
- TI THVD1450: https://www.ti.com/lit/ds/symlink/thvd1450.pdf
- ST STPS10L60: https://www.st.com/resource/en/datasheet/stps10l60.pdf
- Omron G5V-1, Bottom-View-Terminalbild, Seite4: https://omronfs.omron.com/en_US/ecb/products/pdf/en-g5v_1.pdf
- PUI AI-1223-TWT-3V-2-R: https://puiaudio.com/file/specs-AI-1223-TWT-3V-2-R.pdf
- TDK NTCG163JF103FT1: https://product.tdk.com/en/search/sensor/ntc/chip-ntc-thermistor/info?part_no=NTCG163JF103FT1
- SoapySX geprüfter Softwarestand: https://github.com/tejeez/sxxcvr/blob/9705147dd8c189625071f3f163ea56119bda4a05/SoapySX/SoapySX.cpp
- KiCad Schaltplanformat: https://dev-docs.kicad.org/en/file-formats/sexpr-schematic/

## Kontrollierte Detailkorrekturen

G5V-1: Spule2/9, Common5 **und**6, NC1, NO10; das offizielle Bottom-View-Bild wurde betrachtet. TDK-NTC: B25/50=3380K statt einer erfundenen3950K-Zuordnung. Der frühere passive Piezo-Vorschlag ist durch den konkret intern getriebenen PUI-Summer ersetzt. Der SHT45 hat die Bare-IC-Pins1=SDA,2=SCL,3=VDD,4=VSS; das Kabelpinout eines Evaluationsboards ist dafür nicht geeignet.

## Nicht als geprüft behauptet

Nicht alle Herstellerzeichnung-Bilder waren im Werkzeug verfügbar. Besonders die DER-Netzteilzeichnung konnte nicht visuell gegengeprüft werden; der Netzteilentwurf bleibt deswegen ein gesperrter Reviewstand. Für sämtliche Sonder-Footprints gilt zusätzlich die offene Prüfpflicht im Review-Dokument.
