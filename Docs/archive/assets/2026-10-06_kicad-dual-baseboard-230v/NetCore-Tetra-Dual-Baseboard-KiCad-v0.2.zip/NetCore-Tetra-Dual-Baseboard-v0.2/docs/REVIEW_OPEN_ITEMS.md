# Noch offene Reviews – keine versteckten Freigaben

1. **AC/DC-Schaltung:** ursprüngliche Herstellerzeichnung visuell/netzlistenbasiert gegentesten; Übertrager einschließlich Phasen, Schirm, Isolationsdaten und Beschaffbarkeit freigeben; Brücken-Pinout; Schutz-/Snubber-/Bias-Details. Keine Netzeinspeisung vor unabhängiger Freigabe.
2. **EDA:** echten KiCad-Ladetest durchführen; Hierarchie und globale Netzlabels prüfen; Netzliste und ERC kontrollieren. Der unabhängige Python-Test ersetzt den KiCad-Parser nicht. Beim Drucken kann der KiCad-Standard-Zeichnungsrahmen größere Bereiche belegen als die beigelegte eigene PDF-Vorschau.
3. **Bauteile:** alle realen Pin-/Gehäuse-/Footprint-Zuordnungen gegen die bestellte Variante abgleichen. Die Symbole sind projektspezifisch, keine herstellerzertifizierte Bibliothek. Kontakte mit mehrfachen mechanischen Lötfahnen und Steckerspiegelungen besonders prüfen. SM712-Packagezuordnung und alle Quarz-/Schalterpads gehören dazu.
4. **Strom/Mechanik:** exaktes Pi-Modell, SXceiver-Revision, Steckhöhe/-orientierung, Strom über 2x20-Leisten, USB-/Displayrückspeisung, Induktorsättigung, Inrush, Schutzschwellen und thermische Reserven prüfen. 300 mm Breite ist eine Anforderung, kein nachgewiesenes Layoutmaß.
5. **Firmware:** STM32-Boot, USB-Anwendung, I²C-Adressen/Busrecovery, Watchdog, zeitlicher Startup/Shutdown-Ablauf, Lüfterkurven, RF-Inhibit, Fehlerverriegelung, Kalibrierung und Linux-Gegenstelle fehlen. Ohne Software laufen die vorgesehenen Managementfunktionen nicht.
6. **Endgerät:** Layout, EMV, HF-Einkopplung, Kühlung, mechanischer Berührungsschutz, Erdung, Last-/Fehlerprüfung und Isolationskoordination fehlen. Keine Gerber/Bestückfreigabe ausgeben.

Die offene Liste ist kein Auffüllen mit erfundenen Teilen. Sie benennt, was die vorliegende Schaltung noch nicht nachweist.
