# T101 und L101 – Magnetik ist ein echtes Bauteil, keine Blackbox-Platine

## T101: Beschaffung als spezifisch gefertigter Übertrager

Bezeichnung im Projekt: **CUSTOM-DER993-T1**. Das ist unsere Zeichnungsreferenz, **keine behauptete Katalog-Bestellnummer**. Grundlage: Power Integrations DER-993, Rev. 1, 19.05.2024, Abschnitt 7, Seiten 12–18. Die originale Wickelzeichnung und der Isolationsaufbau sind gegenüber dieser Zusammenfassung maßgeblich.

| Merkmal | Referenzangabe |
|---|---|
| Kern | PQ2620, Material PC95 |
| Spulenkörper | passender PQ2628-Sechs-Pin-Spulenkörper gemäß Referenz |
| Primär 1 | Pin 6 nach 4, 21 Windungen, AWG27 / ca. 0,41 mm |
| Primär 2 | Pin 4 nach 5, 21 Windungen, AWG27; 42 insgesamt |
| Bias | Pin 2 nach 3, 8 Windungen, 4 parallele AWG36 / ca. 0,15 mm |
| Sekundär | Zwei parallele Wicklungen FL1 nach FL2; je 5 Windungen aus zwei parallelen AWG23, dreifach isoliert |
| Primärinduktivität | 519 uH +/-5%, 100 kHz / 1 Vpp, Pin 6–5, übrige Wicklungen offen |
| Streuinduktivität | maximal 11 uH nach Messanordnung des Referenzdokuments |
| Zusätzliche Schirmwicklungen | 8 Windungen 4xAWG36 und 11 Windungen 4xAWG34; jeweils an Pin 3, anderes Ende isoliert frei |
| Wickelreihenfolge | P1; Bias/Schirm1; Sekundär1; Sekundär2; Schirm2; P2 nach Originalzeichnung |

Isolierband, Wicklungsabstände, dreifach isolierter Draht, Kernschirm, Anschlussdrähte, Verguss/Tränkung und Prüfungen sind **nicht austauschbar nach Gefühl**. Die Referenz nennt u.a. Polyesterband und Tränklack; die Freigabe muss der ausführende Magnetikhersteller anhand der Originalunterlagen und der Endgeräteanforderungen vornehmen. Eine selbst erfundene Luftspaltgröße wird hier nicht angegeben: sie muss die vorgegebene Induktivität und die spezifizierten Betriebsbedingungen erfüllen.

Im Schaltbild sind Primäranschluss 6, Mittelanschluss 4, Drainanschluss 5, Bias 2/3 und Sekundär FL1/FL2 dargestellt. Pin 4 ist außerhalb des Übertragers unbeschaltet, nicht eine fehlende Primärhälfte. Pin 1 bleibt unbenutzt. Die dargestellten Wicklungspunkte sind Teil der zu bestätigenden Rekonstruktion.

## L101

Gleichtaktdrossel Sumida **04291-T231 / 18 mH**, aus der Referenz-Stückliste. Das konkrete Bauteil einschließlich Stromfreigabe, Isolationsdaten und Pin-/Wicklungszuordnung ist zu beschaffen bzw. mit Sumida abzuklären. Die Zeichnung ersetzt diese Herstellerinformationen nicht.

## Sperrpunkte für den Netzteilteil

Die Original-PDF-Zeichnung ließ sich im verfügbaren Browser nicht als lesbares Bild abrufen. Deshalb sind insbesondere Primärklemme, Bias/OVP, SR-Snubber, Rückleitung über die Stromshunts und Wicklungsphasen **nicht als 1:1 geprüft bestätigt**. Ebenso muss das echte Z4-D-Gehäuse-Pinout der zwei Brücken abgeglichen werden. Im Schaltplan stehen konkrete Werte/Anschlüsse, aber solange diese Prüfungen offen sind, ist der Netzteilteil ausdrücklich **nicht einschaltbereit**.

Die PDF-Rekonstruktion beweist weder ausreichende Isolationskoordination noch die Sicherheit einer späteren Leiterplatte. Prüfspannungen und Kriech-/Luftstrecken werden erst nach Festlegung von Gehäuse, Erdung, Überspannungskategorie, Verschmutzungsgrad, Materialgruppe, Höhe und einschlägiger Endgerätenorm dimensioniert – nicht pauschal aus einer Skizze übernommen.
