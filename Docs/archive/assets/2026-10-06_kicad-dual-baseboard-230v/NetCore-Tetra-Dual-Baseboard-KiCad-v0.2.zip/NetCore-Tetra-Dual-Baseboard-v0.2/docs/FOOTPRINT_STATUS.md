# Footprint-Status – keine Layoutfreigabe

Diese Ausgabe enthält den Schaltplan, kein PCB. Die Zuordnung zwischen allen Pin-Nummern und den realen Lötpads muss vor einem Layout separat kontrolliert werden.

Insbesondere Stecker, Sicherungen, Taster, Elkos, Magnetik und mehrere Sondergehäuse haben absichtlich **keinen** Footprint statt eines erfundenen oder mechanisch unpassenden Footprints. Auch vorhandene Standard-Footprint-Referenzen sind noch nicht in einer installierten KiCad-Bibliothek geprüft. Der statische Bericht listet die fehlenden Zuordnungen.

Das sind offene Layoutaufgaben; die elektrischen Bauteile selbst sind mit Anschlüssen, Werten und Netzen gezeichnet. Es gibt keine elektronischen Funktionsblöcke, die im PCB als Ersatz für einen vollständigen Spannungswandler bestückt werden sollen.

Die Maximum-Breite bleibt **300 mm**. Die bisher genannten 280 x 100 mm sind mit diskretem Netzteil und realer Mechanik NICHT bestätigt. Vor der Flächenoptimierung sind Isolationskonzept, Verluste, Wärmesenken, Luftführung, Abstände und Stapelmechanik festzulegen. Keine Kriechstrecke darf zugunsten einer gewünschten Abmessung unterschritten werden.
