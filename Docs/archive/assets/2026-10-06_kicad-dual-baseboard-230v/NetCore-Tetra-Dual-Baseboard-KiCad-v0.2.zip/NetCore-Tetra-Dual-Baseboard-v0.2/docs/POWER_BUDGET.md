# Leistungsbudget und Schutz – Rechenannahmen, keine Messwerte

## Quellen

Hersteller-Referenz DER-993: 12 V / 6 A, 72 W. Diese Referenzleistung gilt nicht automatisch für die neu gezeichnete Kombination. Quellen-ORing mit STPS10L60D verursacht weitere Verluste. Die externe Quelle muss geregelt 12 V +/-5% liefern. Automotive-Transienten, Load-Dump und Batterieladung sind nicht abgedeckt.

## Arbeitsbudget

| Verbraucher | Ansatz |
|---|---:|
| Pi + SXceiver A | 5,15 V x 4,5 A = 23,18 W |
| Pi + SXceiver B | 5,15 V x 4,5 A = 23,18 W |
| Beide Zweige bei angenommenen 90% Wirkungsgrad | 51,5 W aus 12 V |
| Supervisor, Anzeigen, Sensorik | vorläufig 3 W |
| Zwei Lüfter | vorläufig zusammen 6 W |
| Summe ohne weitere Lasten und ohne ORing-/Reserveverluste | 60,5 W |

90% ist eine Budgetannahme, keine zugesicherte Effizienz. Die restliche nominelle Leistung ist nicht frei für vier maximal belastete Aktorausgänge plus zwei PA. **Nicht alle Anschluss-Maxima dürfen gleichzeitig ausgenutzt werden.** Eine thermisch belastbare Endauslegung kann ein größeres Netzteil verlangen.

## Zweig A/B

TPS56637: 6-A-Klasse-Abwärtswandler, Soll-Ausgang etwa 5,15 V. Ausgang nach eFuse, Shunt und Steckverbindern ist lastabhängig niedriger. Layout, Kapazitäts-Derating und Induktorsättigung sind entscheidend.

TPS259474L: R_ILM = 604 Ohm, nominal ungefähr 3334/604 = 5,52 A, mit Bauteiltoleranzen. Das ist **nicht** eine zugesicherte dauerhafte 5,5-A-Pi-Versorgung. Stromuntergrenze/Toleranz, Einschaltladung, Timer und Erwärmung müssen geprüft werden. 4,5 A ist der hier begrenzte Entwurfs-Lastansatz.

OVLO: 34,8 k / 10 k, nominal 1,2 V x (1+3,48) = 5,376 V. **Keine präzise 5,25-V-Klemme.** Für einen nachgewiesenen Maximalschutz am konkreten Pi ist die Fehlerspannung samt Schaltzeit und Toleranzen separat zu verifizieren. Vorläufig eingestellte dV/dt-/Timer-Werte sind reale Werte im Plan, aber noch nicht durch Einschaltmessungen bestätigt.

Zwei 2-mOhm-Pi-Shunts und ein 2-mOhm-Bus-Shunt: Kelvin-Abgriffe direkt an den Lötflächen. Kalibrierregister der INA226 müssen zum jeweiligen Shunt passen; Firmware hierfür wird nicht mitgeliefert.

## Nicht enthalten

Keine USB-C-PD-Aushandlung, kein Akku, keine Netzausfall-Überbrückung, kein belegter SELV-Sicherheitsnachweis des Endgerätes, keine Zertifizierung, keine Lastfreigabe durch die statische Dateiprüfung.
