# NetCore-Tetra Dual Baseboard – v0.2 REVIEW
**Bauteilbezogener Schaltplanentwurf · 18 Seiten einschließlich Übersicht · Stand 18.09.2026**

## Zuerst lesen

Dies ist eine substanzielle Neuzeichnung des bisherigen Blockkonzepts, aber **keine fertige, elektrisch validierte oder fertigbare Leiterplatte**. Die 230-V-Schaltung ist eine komponentenweise Rekonstruktion aus einem Hersteller-Referenzdesign. Ihre kritischen Verbindungen konnten nicht vollständig mit einer lesbaren Originalzeichnung gegengeprüft werden. **Nicht an Netzspannung anschließen.**

Der mitgelieferte PASS_STATIC_ONLY ist ausschließlich das Ergebnis des beschriebenen Datei- und Verdrahtungschecks. KiCad selbst wurde hier nicht ausgeführt. Ein echter KiCad-Ladetest, ERC, Bauteilmodell-Simulation, Layout/DRC, Isolationsprüfung, EMV- und Temperaturprüfung fehlen. Die Firmware fehlt ebenfalls. Diese Grenzen betreffen das Ergebnis, nicht lediglich seine Dokumentation.

## Öffnen

Alles in einen neuen Ordner entpacken. `NetCore-Tetra-Dual-Baseboard.kicad_pro` oder direkt die gleichnamige `.kicad_sch` öffnen. Die Hauptseite verweist auf die 17 Detailblätter. Alle Symbole sind zusätzlich direkt in den Schaltplänen eingebettet; die Projektbibliothek liegt bei. Es sind moderne S-Expression-Dateien mit Formatversion 20231120, nicht mehr Legacy-`.sch`-Dateien.

`NetCore-Tetra-Schematic-v0.2.pdf` ist eine Vektorvorschau aus demselben Datenmodell – kein Screenshot eines erfolgreichen KiCad-Imports. Englischsprachige kurze Netz-/Bauteilbezeichnungen erleichtern den Abgleich mit Datenblättern; die Begleitdokumentation ist deutsch.

## Was tatsächlich gezeichnet ist

- Diskretes AC/DC-Netzteil mit Sicherung, X-Kondensator und Entladung, Gleichtaktdrossel, Brückengleichrichtern, HV-Elkos, Primärklemme, INN4275C, Hilfswicklung/Bias, spezifiertem Übertrager, zwei synchronen Gleichrichter-MOSFETs, Snubber, Ausgangsfilter, Strommessung und Sicherheits-Y-Kondensator.
- 12-V-Eingang und Quellenentkopplung, Gesamtstrommessung, zwei bestückte Hilfsspannungswandler mit ihren externen Induktivitäten und Kondensatoren.
- Zwei getrennte Pi-Versorgungen: TPS56637 mit kompletter Außenbeschaltung, TPS259474L mit Einstellnetzwerken und INA226 mit Kelvin-Abgriffen.
- Je zwei echte 40-polige Anschlussleisten: 39 direkte Leiterzüge zwischen Pi und SXceiver; Reset/GPIO5 wird ausdrücklich über eine aktive-HIGH-ODER-Verknüpfung geführt. GPIO-Klemmen mit Serienwiderständen und ESD-Dioden, I²C, UART-Puffer, Heartbeat und Open-Drain-Abschaltung.
- Ein **nackter STM32F103CBT6** mit Quarz, Abblockung, Boot-Netzwerk, USB-Gerätebeschaltung, SWD und externem TPS3828-33-Watchdog statt eines RP2040-Fertigmoduls.
- TCA9548A mit Pull-ups und Adressbelegung; TMP117, SHT45, ADS1115 und NTC pro Node; drei MCP23017 mit Anschluss aller verwendeten Pins.
- DIP-Schalter, Vorwiderstände, LEDs, Taster; ein konkret zugeordnetes Newhaven-TFT-FPC mit TSC2046 und vier getrennten Backlight-Vorwiderständen.
- Zwei 4-Draht-Lüfter mit Open-Drain-PWM und Tachoeingängen; vier 12–24-V-Optoeingänge, vier MOSFET-Ausgänge, zwei PA-Freigabekontakte, THVD1450/Terminierung/TVS, Alarmrelais und aktiver Summer.

Über Seiten hinweg verbinden globale **elektrische** Netzlabels die Schaltung. Sie sind keine Modul-Platzhalter. Innerhalb der Detailblätter sind lokale Bauteilketten überwiegend als durchgehende Leitungen gezeichnet. Masse und wenige lange Verbindungen bleiben benannte Netze, wie in einem normalen mehrseitigen Schaltplan.

## Wichtige Änderungen gegenüber v0.1.1

Die alte Behauptung zweier 10-A-Klasse-Versorgungen wird nicht übernommen. Der Referenz-AC/DC-Wandler liefert nominell 12 V / 6 A = 72 W; diese Leistung wurde für das neue Board nicht nachgewiesen. Pro Pi+SDR-Zweig ist hier **höchstens 4,5 A Dauerlast als Entwurfsbudget** angesetzt. Siehe `docs/POWER_BUDGET.md`. Zwei zusätzliche HF-Leistungsverstärker können daraus nicht ohne Weiteres versorgt werden. Die PA-Anschlüsse sind Freigabesignale, keine PA-Leistungsausgänge.

Das TFT ist das konkret zugeordnete `NHD-2.4-240320CF-BSXV-FT` mit 20-poligem 1-mm-FPC. Ein anderes TFT darf nicht allein wegen desselben Steckertyps angeschlossen werden. Ein optionaler OLED-Anschluss ist nur ein 3,3-V-I²C-Port. Eine blanke OLED-Matrix samt Treiber ist nicht zusätzlich auf dem Board aufgebaut.

Die RF-Forward-/Reflected-Anschlüsse am ADS1115 erwarten bereits gleichgerichtete **0–5-V-Messspannungen**. Ein HF-Richtkoppler oder RF-Detektor ist nicht Bestandteil dieser Ausgabe. Es sind ausdrücklich keine direkt messenden HF-Eingänge.

Ein 1-Wire-Gerät kann später an einem geeignet konfigurierten freien GPIO angeschlossen werden; eine komplette DS18B20-Schnittstelle mit eigenem Pull-up/Sensor ist in dieser Ausgabe nicht ergänzt. Eine RTC oder USV wurde nicht stillschweigend hinzuerfunden.

## Anschlüsse und Betriebsgrenzen

Pi-Modell und Steckmechanik sind noch nicht vom Nutzer bestätigt; die verwendete SXceiver-Belegung setzt **HW v1.2** voraus. GPIO-Nummern sind BCM-Nummern, die Zahlen an den 40-poligen Steckern sind physische Pinnummern. `A_3V3_PI`, `B_3V3_PI` und `3V3_AON` sind getrennt. Die beiden Pi-I²C-Busse werden weder untereinander noch mit dem Supervisor-I²C-Bus verbunden.

Die Pi-Einspeisung ist über Pins 2/4 und sämtliche vorgesehenen GND-Verbindungen geplant. Keine gleichzeitige unabhängige USB-C-Stromversorgung. Header-Strombelastbarkeit, Versorgungsschutz des konkreten Pi, USB-Rückspeisung und Spannung am Pi müssen am realen Aufbau geprüft werden. Eine USB-C-PD-Quelle mit 5-A-Aushandlung ist nicht eingezeichnet.

Alle externen GPIO sind 3,3-V-Logik. Optoeingänge: **12–24 V**, nicht 5 V. Last-Ausgänge: 12 V, Entwurfsbudget 0,5 A je Kanal, gemeinsame 2-A-Sicherung. RS-485 ist nicht galvanisch isoliert. Alarmkontakt nur SELV 24 V / 0,5 A in diesem Projekt, keine Netzlast.

Der Supervisor muss vor Benutzung programmiert werden. Ohne laufende Firmware bleiben Pi-Leistung und RF-Freigabe im passiv festgelegten AUS-/INHIBIT-Zustand. Ein Supervisor-Reset kann beide Nodes abschalten: getrennte Rails sind keine vollständig redundanten unabhängigen Controller. Geordnetes Shutdown bei Netzausfall ohne Energiespeicher wird nicht versprochen.

## Inhalt und Prüfungen

`BOM.csv` listet jede Position mit Wert, gegebenenfalls MPN, Quelle und Anmerkung. Nicht jeder Standardwiderstand hat eine festgelegte Bestellnummer. Das ist keine automatisch bestellfertige Beschaffungsliste. Footprints siehe `docs/FOOTPRINT_STATUS.md`.

`tools/validate_schematic.py` liest die tatsächlich geschriebenen Dateien unabhängig vom Generator, rekonstruiert Pins/Leitungen/Labels und vergleicht sie mit `docs/design_netlist.json`. Aufruf: `python tools/validate_schematic.py`. Es weist Konsistenz zur Schaltungsabsicht nach, aber nicht die Richtigkeit dieser Absicht.

Der Generator liegt als `tools/generate_schematic.py` bei und benötigt Python 3.10+ und ReportLab. Er schreibt absichtlich nur in einen ausdrücklich angegebenen Ausgabeordner: `python tools/generate_schematic.py /pfad/zum/neuen_ordner`. Quelländerungen sind erneut zu prüfen.

Es gibt bewusst keine Gerber, kein Pseudo-PCB und keine Fertigungsfreigabe. Der nächste technische Freigabeschritt ist ein unabhängiges Schaltungsreview und ein echter KiCad-Import/Netzlisten-/ERC-Lauf, nicht die Bestellung.
