Custom vector render from the same schematic model. NOT a KiCad screenshot or proof of a successful Eeschema load.
